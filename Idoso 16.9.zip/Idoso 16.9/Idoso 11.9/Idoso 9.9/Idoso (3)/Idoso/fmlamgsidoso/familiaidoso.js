document.addEventListener("DOMContentLoaded", function () {

    // APAGA A MEMÓRIA ANTIGA SALVA NO NAVEGADOR
    localStorage.removeItem("zelo_contatos");

    // BANCO DE DADOS LOCAL (Inicia totalmente vazio)
    function obterContatos() {
        const salvos = localStorage.getItem("zelo_contatos");
        if (!salvos) {
            localStorage.setItem("zelo_contatos", JSON.stringify([]));
            return [];
        }
        return JSON.parse(salvos);
    }

    function salvarContatos(lista) {
        localStorage.setItem("zelo_contatos", JSON.stringify(lista));
    }

    // =====================================================
    // REFERÊNCIAS DO DOM
    // =====================================================
    const contactsGrid = document.getElementById("contacts-grid");
    
    // Modais
    const modalContato = document.getElementById("modal-contato");
    const modalMensagem = document.getElementById("modal-mensagem");
    const modalCadastro = document.getElementById("modal-cadastro");

    // Elementos do Modal de Ação
    const nomeContatoModal = document.getElementById("nome-contato");
    const relacaoContatoModal = document.getElementById("relacao-contato");
    const botaoLigar = document.getElementById("botao-ligar");
    const botaoMensagem = document.getElementById("botao-mensagem");
    const botaoExcluir = document.getElementById("botao-excluir");

    // Elementos do Modal de Mensagem
    const mensagemNome = document.getElementById("mensagem-nome");
    const campoMensagem = document.getElementById("campo-mensagem");
    const enviarMensagem = document.getElementById("enviar-mensagem");

    // Form de Cadastro
    const btnAbrirCadastro = document.getElementById("btn-abrir-cadastro");
    const formNovoContato = document.getElementById("form-novo-contato");

    // Botão emergência familiar
    const btnFamiliarEmergencia = document.getElementById("botao-familiar-emergencia");

    let contatoAtual = null;

    // =====================================================
    // RENDERIZAR CONTATOS NA TELA
    // =====================================================
    function renderizarContatos() {
        const contatos = obterContatos();
        contactsGrid.innerHTML = "";

        if (contatos.length === 0) {
            if (btnFamiliarEmergencia) {
                btnFamiliarEmergencia.href = "#";
            }
            return;
        }

        contatos.forEach(contato => {
            const itemDiv = document.createElement("div");
            itemDiv.className = "contact-item";
            itemDiv.innerHTML = `
                <button class="avatar-link" type="button" aria-label="Falar com ${contato.nome}">
                    <div class="avatar-wrapper">
                        <img src="iconeusuario.png" alt="${contato.nome}" class="avatar-img">
                    </div>
                </button>
                <div class="contact-info">
                    <p class="contact-name">${contato.nome}</p>
                    <p class="contact-relation">(${contato.relacao})</p>
                </div>
            `;

            itemDiv.querySelector(".avatar-link").addEventListener("click", () => {
                abrirModalContato(contato);
            });

            contactsGrid.appendChild(itemDiv);
        });

        if (btnFamiliarEmergencia && contatos.length > 0) {
            btnFamiliarEmergencia.href = `tel:${contatos[0].telefone}`;
        }
    }

    // =====================================================
    // LÓGICA DE MODAIS E AÇÕES
    // =====================================================
    function abrirModalContato(contato) {
        contatoAtual = contato;
        nomeContatoModal.textContent = contato.nome;
        relacaoContatoModal.textContent = `(${contato.relacao})`;
        modalContato.classList.add("aberto");
        modalContato.setAttribute("aria-hidden", "false");
    }

    function fecharModais() {
        modalContato.classList.remove("aberto");
        modalMensagem.classList.remove("aberto");
        modalCadastro.classList.remove("aberto");
        modalContato.setAttribute("aria-hidden", "true");
        modalMensagem.setAttribute("aria-hidden", "true");
        modalCadastro.setAttribute("aria-hidden", "true");
    }

    botaoLigar.addEventListener("click", function () {
        if (!contatoAtual || !contatoAtual.telefone) {
            alert("Número não cadastrado.");
            return;
        }
        window.location.href = `tel:${contatoAtual.telefone}`;
    });

    botaoMensagem.addEventListener("click", function () {
        if (!contatoAtual) return;
        modalContato.classList.remove("aberto");
        mensagemNome.textContent = contatoAtual.nome;
        campoMensagem.value = "";
        modalMensagem.classList.add("aberto");
        modalMensagem.setAttribute("aria-hidden", "false");
    });

    enviarMensagem.addEventListener("click", function () {
        const texto = campoMensagem.value.trim();
        if (!texto) {
            alert("Por favor, digite uma mensagem.");
            return;
        }

        const numLimpo = contatoAtual.telefone.replace(/\D/g, "");
        const linkWhatsapp = `https://api.whatsapp.com/send?phone=${numLimpo}&text=${encodeURIComponent(texto)}`;
        
        window.open(linkWhatsapp, "_blank");
        fecharModais();
    });

    botaoExcluir.addEventListener("click", function () {
        if (!contatoAtual) return;
        if (confirm(`Deseja mesmo apagar o contato de ${contatoAtual.nome}?`)) {
            let contatos = obterContatos();
            contatos = contatos.filter(c => c.id !== contatoAtual.id);
            salvarContatos(contatos);
            fecharModais();
            renderizarContatos();
        }
    });

    btnAbrirCadastro.addEventListener("click", function () {
        formNovoContato.reset();
        modalCadastro.classList.add("aberto");
        modalCadastro.setAttribute("aria-hidden", "false");
    });

    formNovoContato.addEventListener("submit", function (e) {
        e.preventDefault();

        const nome = document.getElementById("novo-nome").value.trim().toUpperCase();
        const relacao = document.getElementById("novo-parentesco").value.trim().toUpperCase();
        const telefone = document.getElementById("novo-telefone").value.trim();

        const novoContato = {
            id: Date.now().toString(),
            nome: nome,
            relacao: relacao,
            telefone: telefone
        };

        const contatos = obterContatos();
        contatos.push(novoContato);
        salvarContatos(contatos);

        fecharModais();
        renderizarContatos();
        alert("Contato salvo com sucesso! 💚");
    });

    document.getElementById("fechar-modal").addEventListener("click", fecharModais);
    document.getElementById("fechar-mensagem").addEventListener("click", fecharModais);
    document.getElementById("fechar-cadastro").addEventListener("click", fecharModais);
    document.getElementById("cancelar-cadastro").addEventListener("click", fecharModais);
    document.getElementById("cancelar-mensagem").addEventListener("click", () => {
        modalMensagem.classList.remove("aberto");
        modalContato.classList.add("aberto");
    });

    renderizarContatos();
});