package com.auth.simpleauth.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@Configuration
public class CorsConfig implements WebMvcConfigurer {

    @Override
    public void addCorsMappings(CorsRegistry registry) {
        registry.addMapping("/**")
                // Sub-stitui allowedOrigins por allowedOriginPatterns para aceitar qualquer porta/origem com suporte a credentials
                .allowedOriginPatterns(
                        "http://127.0.0.1:[*]",
                        "http://localhost:[*]",
                        "https://*.ngrok-free.app",
                        "*"
                )
                .allowedMethods("GET", "POST", "PUT", "DELETE", "PATCH", "OPTIONS")
                .allowedHeaders("*")
                .allowCredentials(true); // Permite o envio dos cookies de sessão (JSESSIONID)
    }
}