package com.auth.simpleauth.dto;

public class AtualizarTelefoneDto {

    private String telefone;

    public AtualizarTelefoneDto() {
    }

    public String getTelefone() {
        return telefone;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }
}