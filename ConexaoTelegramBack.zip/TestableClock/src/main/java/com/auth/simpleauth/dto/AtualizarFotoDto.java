package com.auth.simpleauth.dto;

public class AtualizarFotoDto {

    private String imagemUrl;

    public AtualizarFotoDto() {
    }

    public String getImagemUrl() {
        return imagemUrl;
    }

    public void setImagemUrl(String imagemUrl) {
        this.imagemUrl = imagemUrl;
    }
}