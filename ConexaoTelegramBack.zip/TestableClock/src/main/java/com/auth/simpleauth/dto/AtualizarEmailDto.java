package com.auth.simpleauth.dto;

public class AtualizarEmailDto {

    private String email;

    public AtualizarEmailDto() {
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }
}