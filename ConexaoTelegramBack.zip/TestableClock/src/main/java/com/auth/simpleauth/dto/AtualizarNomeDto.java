package com.auth.simpleauth.dto;

public class AtualizarNomeDto {

    private String nome;

    public AtualizarNomeDto() {
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }
}