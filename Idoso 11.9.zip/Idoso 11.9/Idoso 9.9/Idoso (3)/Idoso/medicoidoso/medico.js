document.addEventListener("DOMContentLoaded", () => {
    // ELEMENTOS DE MENSAGEM
    const sintomasInput = document.getElementById("sintomas-input");
    const btnEnviarTexto = document.getElementById("btn-enviar-texto");

    // ELEMENTOS DE GRAVAÇÃO
    const btnMic = document.getElementById("btn-mic-recorder");
    const micStatusText = document.getElementById("mic-status-text");

    // MODAIS DE SUCESSO E EMERGÊNCIA
    const modalSucesso = document.getElementById("modal-sucesso");
    const modalEmergencia = document.getElementById("modal-emergencia");
    const btnEstouBem = document.getElementById("btn-estou-bem");
    const btnPedirAjuda = document.getElementById("btn-pedir-ajuda");
    const btnFecharEmergencia = document.getElementById("btn-fechar-emergencia");

    let mediaRecorder;
    let audioChunks = [];
    let isRecording = false;

    // 1. ENVIO DE TEXTO
    if (btnEnviarTexto) {
        btnEnviarTexto.addEventListener("click", () => {
            const texto = sintomasInput.value.trim();
            if (texto === "") {
                alert("⚠️ Por favor, escreva o que está sentindo antes de enviar.");
                return;
            }

            sintomasInput.value = "";
            exibirSucesso();
        });
    }

    // 2. GRAVAÇÃO E ENVIO DIRETO DE ÁUDIO
    if (btnMic) {
        btnMic.addEventListener("click", async () => {
            if (isRecording) {
                // Para a gravação e envia
                mediaRecorder.stop();
                return;
            }

            try {
                const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
                mediaRecorder = new MediaRecorder(stream);
                audioChunks = [];

                mediaRecorder.ondataavailable = (event) => {
                    audioChunks.push(event.data);
                };

                mediaRecorder.onstart = () => {
                    isRecording = true;
                    btnMic.classList.add("recording");
                    micStatusText.innerHTML = "🔴 <strong>GRAVANDO...</strong><br>Aperte o botão novamente para parar e enviar ao médico.";
                };

                mediaRecorder.onstop = () => {
                    isRecording = false;
                    btnMic.classList.remove("recording");
                    micStatusText.innerHTML = "🎙️ CLIQUE NO BOTÃO ABAIXO PARA COMEÇAR A GRAVAR SEU ÁUDIO";

                    // Encerra a captura do microfone
                    stream.getTracks().forEach(track => track.stop());

                    // Exibe a tela de confirmação e pergunta de ajuda
                    exibirSucesso();
                };

                mediaRecorder.start();

            } catch (err) {
                alert("⚠️ Não conseguimos acessar o seu microfone. Por favor, libere a permissão no seu navegador.");
                console.error("Erro no microfone:", err);
            }
        });
    }

    // 3. CONTROLE DOS MODAIS
    function exibirSucesso() {
        modalSucesso.style.display = "flex";
    }

    btnEstouBem.addEventListener("click", () => {
        modalSucesso.style.display = "none";
    });

    btnPedirAjuda.addEventListener("click", () => {
        modalSucesso.style.display = "none";
        modalEmergencia.style.display = "flex";
    });

    btnFecharEmergencia.addEventListener("click", () => {
        modalEmergencia.style.display = "none";
    });
});