document.addEventListener("DOMContentLoaded", function () {


    /* =====================================================
       ELEMENTOS DO MODAL DE EMERGÊNCIA
    ====================================================== */

    const botaoAjuda =
        document.getElementById("botao-ajuda");

    const modalEmergencia =
        document.getElementById("modal-emergencia");

    const fecharEmergencia =
        document.getElementById("fechar-emergencia");


    /* =====================================================
       ABRIR MENU DE EMERGÊNCIA
    ====================================================== */

    if (botaoAjuda && modalEmergencia) {

        botaoAjuda.addEventListener("click", function () {

            modalEmergencia.classList.add("aberto");

            modalEmergencia.setAttribute(
                "aria-hidden",
                "false"
            );

            /*
             * Coloca o foco no botão de fechar.
             * Isso ajuda quem utiliza teclado ou
             * recursos de acessibilidade.
             */

            if (fecharEmergencia) {

                fecharEmergencia.focus();

            }

        });

    }


    /* =====================================================
       FECHAR MENU DE EMERGÊNCIA
    ====================================================== */

    if (fecharEmergencia && modalEmergencia) {

        fecharEmergencia.addEventListener(
            "click",
            function () {

                fecharModalEmergencia();

            }
        );

    }


    /* =====================================================
       FUNÇÃO PARA FECHAR O MODAL
    ====================================================== */

    function fecharModalEmergencia() {

        if (!modalEmergencia) {
            return;
        }

        modalEmergencia.classList.remove("aberto");

        modalEmergencia.setAttribute(
            "aria-hidden",
            "true"
        );


        /*
         * Devolve o foco para o botão de emergência.
         */

        if (botaoAjuda) {

            botaoAjuda.focus();

        }

    }


    /* =====================================================
       CLICAR FORA DO MODAL
    ====================================================== */

    if (modalEmergencia) {

        modalEmergencia.addEventListener(
            "click",
            function (event) {

                /*
                 * Se o usuário clicar no fundo escuro,
                 * o modal será fechado.
                 */

                if (event.target === modalEmergencia) {

                    fecharModalEmergencia();

                }

            }
        );

    }


    /* =====================================================
       TECLA ESC
    ====================================================== */

    document.addEventListener(
        "keydown",
        function (event) {

            if (event.key !== "Escape") {

                return;

            }


            if (
                modalEmergencia &&
                modalEmergencia.classList.contains("aberto")
            ) {

                fecharModalEmergencia();

            }

        }
    );


});
