document.addEventListener("DOMContentLoaded", function () {

    // =====================================================
    // CONTATOS
    // =====================================================

    const contatos = {

        jose: {
            nome: "José",
            relacao: "Filho",
            telefone: "5511987654321"
        },

        clara: {
            nome: "Clara",
            relacao: "Neta",
            telefone: "5511987654322"
        },

        rosemary: {
            nome: "Rosemary",
            relacao: "Vizinha",
            telefone: "5511987654323"
        },

        claudia: {
            nome: "Claudia",
            relacao: "Vizinha",
            telefone: "5511987654324"
        },

        miqueias: {
            nome: "Miqueias",
            relacao: "Amigo",
            telefone: "5511987654325"
        },

        joaquim: {
            nome: "Joaquim",
            relacao: "Irmão",
            telefone: "5511987654326"
        }
    };


    // =====================================================
    // ELEMENTOS DOS MODAIS DE CONTATO
    // =====================================================

    const modalContato = document.getElementById("modal-contato");
    const modalMensagem = document.getElementById("modal-mensagem");

    const nomeContato = document.getElementById("nome-contato");
    const relacaoContato = document.getElementById("relacao-contato");

    const mensagemNome = document.getElementById("mensagem-nome");
    const campoMensagem = document.getElementById("campo-mensagem");

    const botaoLigar = document.getElementById("botao-ligar");
    const botaoMensagem = document.getElementById("botao-mensagem");
    const enviarMensagem = document.getElementById("enviar-mensagem");

    const fecharModal = document.getElementById("fechar-modal");
    const fecharMensagem = document.getElementById("fechar-mensagem");
    const cancelarMensagem = document.getElementById("cancelar-mensagem");


    // =====================================================
    // CONTATO SELECIONADO
    // =====================================================

    let contatoAtual = null;


    // =====================================================
    // ABRIR CONTATO
    // =====================================================

    function abrirContato(contato) {

        contatoAtual = contato;

        nomeContato.textContent = contato.nome;
        relacaoContato.textContent = contato.relacao;
        mensagemNome.textContent = contato.nome;

        modalContato.classList.add("aberto");
        modalContato.setAttribute("aria-hidden", "false");
    }


    // =====================================================
    // FECHAR MODAL DE CONTATO
    // =====================================================

    function fecharModalContato() {

        modalContato.classList.remove("aberto");
        modalContato.setAttribute("aria-hidden", "true");
    }


    // =====================================================
    // CLICAR NOS AVATARES
    // =====================================================

    const botoesContatos = document.querySelectorAll(".avatar-link");

    botoesContatos.forEach(function (botao) {

        botao.addEventListener("click", function () {

            const id = botao.getAttribute("data-contact");
            const contato = contatos[id];

            if (!contato) {

                console.error("Contato não encontrado:", id);

                return;
            }

            abrirContato(contato);
        });
    });


    // =====================================================
    // LIGAR PARA CONTATO
    // =====================================================

    botaoLigar.addEventListener("click", function () {

        if (!contatoAtual) {
            return;
        }

        const numero = contatoAtual.telefone;

        if (!numero || numero.trim() === "") {

            alert(
                "O número de telefone deste contato ainda não foi cadastrado."
            );

            return;
        }

        fecharModalContato();

        window.location.href = "tel:+" + numero;
    });


    // =====================================================
    // ABRIR MENSAGEM
    // =====================================================

    botaoMensagem.addEventListener("click", function () {

        if (!contatoAtual) {
            return;
        }

        modalContato.classList.remove("aberto");

        mensagemNome.textContent = contatoAtual.nome;

        campoMensagem.value = "";

        modalMensagem.classList.add("aberto");
        modalMensagem.setAttribute("aria-hidden", "false");

        setTimeout(function () {

            campoMensagem.focus();

        }, 150);
    });


    // =====================================================
    // ENVIAR MENSAGEM
    // =====================================================

    enviarMensagem.addEventListener("click", function () {

        if (!contatoAtual) {
            return;
        }

        const mensagem = campoMensagem.value.trim();

        if (mensagem === "") {

            alert(
                "Por favor, escreva uma mensagem antes de enviar."
            );

            campoMensagem.focus();

            return;
        }

        alert("Mensagem enviada com sucesso! 💬");

        campoMensagem.value = "";

        fecharModalMensagem();
    });


    // =====================================================
    // FECHAR MODAL DE CONTATO
    // =====================================================

    fecharModal.addEventListener("click", function () {

        fecharModalContato();

    });


    // =====================================================
    // FECHAR MODAL DE MENSAGEM
    // =====================================================

    function fecharModalMensagem() {

        modalMensagem.classList.remove("aberto");

        modalMensagem.setAttribute("aria-hidden", "true");
    }


    fecharMensagem.addEventListener("click", function () {

        fecharModalMensagem();

    });


    // =====================================================
    // BOTÃO VOLTAR DA MENSAGEM
    // =====================================================

    cancelarMensagem.addEventListener("click", function () {

        fecharModalMensagem();

        if (contatoAtual) {

            modalContato.classList.add("aberto");

            modalContato.setAttribute("aria-hidden", "false");
        }
    });


    // =====================================================
    // CLICAR FORA DO MODAL DE CONTATO
    // =====================================================

    modalContato.addEventListener("click", function (event) {

        if (event.target === modalContato) {

            fecharModalContato();

        }
    });


    // =====================================================
    // CLICAR FORA DO MODAL DE MENSAGEM
    // =====================================================

    modalMensagem.addEventListener("click", function (event) {

        if (event.target === modalMensagem) {

            fecharModalMensagem();

        }
    });


    // =====================================================
    // MENU DE EMERGÊNCIA
    // =====================================================

    const botaoAjuda = document.getElementById("botao-ajuda");

    const modalEmergencia =
        document.getElementById("modal-emergencia");

    const fecharEmergencia =
        document.getElementById("fechar-emergencia");


    // =====================================================
    // ABRIR MENU DE EMERGÊNCIA
    // =====================================================

    if (botaoAjuda && modalEmergencia) {

        botaoAjuda.addEventListener("click", function () {

            modalEmergencia.classList.add("aberto");

            modalEmergencia.setAttribute(
                "aria-hidden",
                "false"
            );

        });
    }


    // =====================================================
    // FECHAR MENU DE EMERGÊNCIA
    // =====================================================

    if (fecharEmergencia && modalEmergencia) {

        fecharEmergencia.addEventListener("click", function () {

            modalEmergencia.classList.remove("aberto");

            modalEmergencia.setAttribute(
                "aria-hidden",
                "true"
            );

        });
    }


    // =====================================================
    // CLICAR FORA DO MENU DE EMERGÊNCIA
    // =====================================================

    if (modalEmergencia) {

        modalEmergencia.addEventListener("click", function (event) {

            if (event.target === modalEmergencia) {

                modalEmergencia.classList.remove("aberto");

                modalEmergencia.setAttribute(
                    "aria-hidden",
                    "true"
                );
            }

        });
    }


    // =====================================================
    // FAMILIAR DE EMERGÊNCIA - BACKEND
    // =====================================================

    const botaoFamiliarEmergencia =
        document.getElementById("botao-familiar-emergencia");


    if (botaoFamiliarEmergencia) {

        botaoFamiliarEmergencia.addEventListener(
            "click",
            function (event) {

                event.preventDefault();

                fetch("http://localhost:8080/familiares/emergencia")
                    .then(function (response) {

                        if (!response.ok) {

                            throw new Error(
                                "Não foi possível buscar o familiar."
                            );
                        }

                        return response.json();
                    })
                    .then(function (familiar) {

                        if (
                            !familiar.telefone ||
                            familiar.telefone.trim() === ""
                        ) {

                            alert(
                                "O telefone do familiar não foi cadastrado."
                            );

                            return;
                        }

                        window.location.href =
                            "tel:+" + familiar.telefone;

                    })
                    .catch(function (error) {

                        console.error(
                            "Erro ao buscar familiar:",
                            error
                        );

                        alert(
                            "Não foi possível localizar o familiar de emergência."
                        );
                    });
            }
        );
    }


    // =====================================================
    // TECLA ESC
    // =====================================================

    document.addEventListener("keydown", function (event) {

        if (event.key === "Escape") {

            fecharModalContato();

            fecharModalMensagem();

            if (modalEmergencia) {

                modalEmergencia.classList.remove("aberto");

                modalEmergencia.setAttribute(
                    "aria-hidden",
                    "true"
                );
            }
        }
    });

});