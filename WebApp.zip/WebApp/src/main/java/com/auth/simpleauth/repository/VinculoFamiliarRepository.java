package com.auth.simpleauth.repository;

import com.auth.simpleauth.entity.VinculoFamiliarIdoso;
import com.auth.simpleauth.enums.StatusVinculo;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface VinculoFamiliarRepository extends JpaRepository<VinculoFamiliarIdoso, Long> {

    // Busca o vínculo independente do status para reaproveitá-lo se necessário
    Optional<VinculoFamiliarIdoso> findByFamiliarIdAndIdosoId(Long familiarId, Long idosoId);

    // Métodos necessários para buscar vínculos por status específico (ex: PENDENTE ou ACEITO)
    List<VinculoFamiliarIdoso> findByIdosoIdAndStatus(Long idosoId, StatusVinculo status);

    List<VinculoFamiliarIdoso> findByFamiliarIdAndStatus(Long familiarId, StatusVinculo status);

    // Validação de existência considerando apenas vínculos aceitos
    boolean existsByFamiliarIdAndIdosoIdAndStatus(Long familiarId, Long idosoId, StatusVinculo status);
}