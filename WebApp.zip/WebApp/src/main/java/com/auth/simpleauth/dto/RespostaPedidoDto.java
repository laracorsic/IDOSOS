package com.auth.simpleauth.dto;

public class RespostaPedidoDto {
    private Long vinculoId;
    private boolean aceito;

    public Long getVinculoId() { return vinculoId; }
    public void setVinculoId(Long vinculoId) { this.vinculoId = vinculoId; }

    public boolean isAceito() { return aceito; }
    public void setAceito(boolean aceito) { this.aceito = aceito; }
}