package com.auth.simpleauth.telegram;

import com.auth.simpleauth.enums.StatusDose;
import com.auth.simpleauth.repository.DoseRepository;
import com.auth.simpleauth.repository.FamiliarRepository;
import com.auth.simpleauth.repository.IdosoRepository;
import com.auth.simpleauth.service.DoseService;
import com.auth.simpleauth.service.TelegramNotificationGateway;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.telegram.telegrambots.bots.TelegramLongPollingBot;
import org.telegram.telegrambots.meta.api.methods.AnswerCallbackQuery;
import org.telegram.telegrambots.meta.api.methods.send.SendMessage;
import org.telegram.telegrambots.meta.api.objects.CallbackQuery;
import org.telegram.telegrambots.meta.api.objects.Update;
import org.telegram.telegrambots.meta.api.objects.replykeyboard.InlineKeyboardMarkup;
import org.telegram.telegrambots.meta.api.objects.replykeyboard.buttons.InlineKeyboardButton;
import org.telegram.telegrambots.meta.api.objects.webapp.WebAppInfo;
import org.telegram.telegrambots.meta.exceptions.TelegramApiException;

import java.util.ArrayList;
import java.util.List;

@Component
public class ConnectHubBot extends TelegramLongPollingBot {

    @Value("${telegram.bot.hub.token:}")
    private String botToken;

    @Value("${telegram.bot.hub.username:ConnectHubCentralBot}")
    private String botUsername;

    @Value("${app.frontend.url:https://seusistema.com}")
    private String frontendUrl;

    private final DoseRepository doseRepository;
    private final IdosoRepository idosoRepository;
    private final FamiliarRepository familiarRepository;
    private final TelegramNotificationGateway notificationGateway;
    private final DoseService doseService;

    public ConnectHubBot(DoseRepository doseRepository,
                         IdosoRepository idosoRepository,
                         FamiliarRepository familiarRepository,
                         TelegramNotificationGateway notificationGateway,
                         DoseService doseService) {
        this.doseRepository = doseRepository;
        this.idosoRepository = idosoRepository;
        this.familiarRepository = familiarRepository;
        this.notificationGateway = notificationGateway;
        this.doseService = doseService;
    }

    @Override
    public String getBotUsername() {
        return botUsername;
    }

    @Override
    public String getBotToken() {
        return botToken;
    }

    @Override
    public void onUpdateReceived(Update update) {
        if (update.hasCallbackQuery()) {
            processarCallback(update.getCallbackQuery());
        } else if (update.hasMessage() && update.getMessage().hasText()) {
            String texto = update.getMessage().getText();
            String chatId = String.valueOf(update.getMessage().getChatId());
            processarComandoStart(texto, chatId);
        }
    }

    private void processarComandoStart(String texto, String chatId) {
        if (texto.startsWith("/start")) {
            String[] partes = texto.split(" ");
            if (partes.length > 1) {
                String token = partes[1];
                try {
                    if (token.startsWith("IDOSO_")) {
                        Long idosoId = Long.parseLong(token.replace("IDOSO_", ""));
                        idosoRepository.findById(idosoId).ifPresentOrElse(
                                idoso -> {
                                    idoso.setTelegramChatId(chatId);
                                    idosoRepository.save(idoso);
                                    enviarBotoesCentral(chatId, idoso.getNome(), token);
                                },
                                () -> enviarMensagemSimples(chatId, String.format("⚠️ Idoso com ID %d não foi encontrado.", idosoId))
                        );
                    } else if (token.startsWith("FAMILIAR_")) {
                        Long familiarId = Long.parseLong(token.replace("FAMILIAR_", ""));
                        familiarRepository.findById(familiarId).ifPresentOrElse(
                                familiar -> {
                                    familiar.setTelegramChatId(chatId);
                                    familiarRepository.save(familiar);
                                    enviarBotoesCentral(chatId, familiar.getNome(), token);
                                },
                                () -> enviarMensagemSimples(chatId, String.format("⚠️ Familiar com ID %d não foi encontrado.", familiarId))
                        );
                    }
                } catch (Exception e) {
                    enviarMensagemSimples(chatId, "⚠️ Código de vinculação inválido.");
                }
            } else {
                enviarMensagemSimples(chatId, "👋 Bem-vindo ao **ConnectHub Central**!\nPara conectar sua conta, clique no botão de acesso via sistema web.");
            }
        }
    }

    private void enviarBotoesCentral(String chatId, String nomeUsuario, String token) {
        SendMessage message = new SendMessage();
        message.setChatId(chatId);
        message.setParseMode("HTML");
        message.setText(String.format(
                "✅ Olá, <b>%s</b>! Sua conta foi conectada com sucesso ao <b>ConnectHub Central</b>.\n\n" +
                        "Clique em uma das opções abaixo para abrir o serviço desejado sem sair desta conversa:",
                nomeUsuario
        ));

        InlineKeyboardMarkup markup = new InlineKeyboardMarkup();
        List<List<InlineKeyboardButton>> rows = new ArrayList<>();

        // 1. Botão do Bot de Medicamentos e Saúde
        List<InlineKeyboardButton> row1 = new ArrayList<>();
        InlineKeyboardButton btnMed = new InlineKeyboardButton();
        btnMed.setText("💊 Painel de Remédios e Saúde");
        String urlMed = String.format("%s/webapp/medicamentos.html?token=%s", frontendUrl, token);
        btnMed.setWebApp(new WebAppInfo(urlMed));
        row1.add(btnMed);

        // 2. Botão do Bot de Eventos e Compromissos
        List<InlineKeyboardButton> row2 = new ArrayList<>();
        InlineKeyboardButton btnEvento = new InlineKeyboardButton();
        btnEvento.setText("📅 Painel de Eventos e Compromissos");
        String urlEvento = String.format("%s/webapp/eventos.html?token=%s", frontendUrl, token);
        btnEvento.setWebApp(new WebAppInfo(urlEvento));
        row2.add(btnEvento);

        // 3. Botão do Bot de Lista de Compras
        List<InlineKeyboardButton> row3 = new ArrayList<>();
        InlineKeyboardButton btnCompra = new InlineKeyboardButton();
        btnCompra.setText("🛒 Lista de Compras");
        String urlCompra = String.format("%s/webapp/compras.html?token=%s", frontendUrl, token);
        btnCompra.setWebApp(new WebAppInfo(urlCompra));
        row3.add(btnCompra);

        rows.add(row1);
        rows.add(row2);
        rows.add(row3);

        markup.setKeyboard(rows);
        message.setReplyMarkup(markup);

        try {
            execute(message);
        } catch (TelegramApiException e) {
            e.printStackTrace();
        }
    }

    private void processarCallback(CallbackQuery callbackQuery) {
        String data = callbackQuery.getData();
        if (data != null && data.startsWith("TOMAR_DOSE:")) {
            Long idDose = Long.parseLong(data.split(":")[1]);
            processarConfirmacaoDose(idDose);

            AnswerCallbackQuery answer = new AnswerCallbackQuery();
            answer.setCallbackQueryId(callbackQuery.getId());
            answer.setText("Dose registrada com sucesso!");
            try {
                execute(answer);
            } catch (TelegramApiException ignored) {}
        }
    }

    private void processarConfirmacaoDose(Long idDose) {
        doseRepository.findById(idDose).ifPresent(dose -> {
            if (dose.getStatus() != StatusDose.TOMADO) {
                doseService.confirmarDose(idDose);
                String chatIdIdoso = dose.getMedicamento().getIdoso().getTelegramChatId();
                if (chatIdIdoso != null) {
                    notificationGateway.notificarMedicamento(chatIdIdoso, "🎉 Parabéns! Sua dose foi confirmada com sucesso.");
                }
                var familiar = dose.getMedicamento().getIdoso().getFamiliar();
                if (familiar != null && familiar.getTelegramChatId() != null) {
                    String msgFamiliar = String.format(
                            "✅ O idoso <b>%s</b> confirmou a tomada do medicamento '<b>%s</b>'!",
                            dose.getMedicamento().getIdoso().getNome(),
                            dose.getMedicamento().getNome()
                    );
                    notificationGateway.notificarMedicamento(familiar.getTelegramChatId(), msgFamiliar);
                }
            }
        });
    }

    private void enviarMensagemSimples(String chatId, String texto) {
        SendMessage msg = new SendMessage(chatId, texto);
        try {
            execute(msg);
        } catch (TelegramApiException e) {
            e.printStackTrace();
        }
    }
}