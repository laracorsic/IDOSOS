package com.auth.simpleauth.enums;

public enum UnidadeTempoDuracao {
    DIAS,
    MESES,
    ANOS,
    ILIMITADO
}