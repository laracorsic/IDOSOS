package com.auth.simpleauth.dto;

public class VinculoFamiliarDto {
    private Long idFamiliar;
    private Long idIdoso;

    public Long getIdFamiliar() { return idFamiliar; }
    public void setIdFamiliar(Long idFamiliar) { this.idFamiliar = idFamiliar; }

    public Long getIdIdoso() { return idIdoso; }
    public void setIdIdoso(Long idIdoso) { this.idIdoso = idIdoso; }
}