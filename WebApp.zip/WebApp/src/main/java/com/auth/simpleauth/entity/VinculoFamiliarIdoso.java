package com.auth.simpleauth.entity;

import com.auth.simpleauth.enums.StatusVinculo;
import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import java.time.LocalDateTime;

@Entity
@Table(name = "tbl_vinculo_familiar_idoso")
public class VinculoFamiliarIdoso {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotNull
    @ManyToOne
    @JoinColumn(name = "familiar_id", nullable = false)
    private Familiar familiar;

    @NotNull
    @ManyToOne
    @JoinColumn(name = "idoso_id", nullable = false)
    private Idoso idoso;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private StatusVinculo status = StatusVinculo.PENDENTE;

    @Column(name = "data_criacao", nullable = false)
    private LocalDateTime dataCriacao = LocalDateTime.now();

    public VinculoFamiliarIdoso() {}

    public VinculoFamiliarIdoso(Familiar familiar, Idoso idoso) {
        this.familiar = familiar;
        this.idoso = idoso;
        this.status = StatusVinculo.PENDENTE;
        this.dataCriacao = LocalDateTime.now();
    }

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public Familiar getFamiliar() { return familiar; }
    public void setFamiliar(Familiar familiar) { this.familiar = familiar; }

    public Idoso getIdoso() { return idoso; }
    public void setIdoso(Idoso idoso) { this.idoso = idoso; }

    public StatusVinculo getStatus() { return status; }
    public void setStatus(StatusVinculo status) { this.status = status; }

    public LocalDateTime getDataCriacao() { return dataCriacao; }
    public void setDataCriacao(LocalDateTime dataCriacao) { this.dataCriacao = dataCriacao; }
}