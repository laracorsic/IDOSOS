package com.auth.simpleauth.dto;

public class VinculoDetalhadoResponseDto {
    private String nomeFamiliar;
    private String nomeIdoso;
    private long totalIdososDoFamiliar;
    private long totalFamiliaresDoIdoso;

    public VinculoDetalhadoResponseDto(String nomeFamiliar, String nomeIdoso, long totalIdososDoFamiliar, long totalFamiliaresDoIdoso) {
        this.nomeFamiliar = nomeFamiliar;
        this.nomeIdoso = nomeIdoso;
        this.totalIdososDoFamiliar = totalIdososDoFamiliar;
        this.totalFamiliaresDoIdoso = totalFamiliaresDoIdoso;
    }

    public String getNomeFamiliar() { return nomeFamiliar; }
    public String getNomeIdoso() { return nomeIdoso; }
    public long getTotalIdososDoFamiliar() { return totalIdososDoFamiliar; }
    public long getTotalFamiliaresDoIdoso() { return totalFamiliaresDoIdoso; }
}