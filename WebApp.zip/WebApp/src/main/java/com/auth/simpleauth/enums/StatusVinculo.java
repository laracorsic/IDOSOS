package com.auth.simpleauth.enums;

public enum StatusVinculo {
    PENDENTE,
    ACEITO,
    RECUSADO
}