package com.auth.simpleauth.enums;

public enum TipoTratamento {
    CONTINUO,
    TEMPORARIO
}