package com.auth.simpleauth.dto;

public class UsuarioVinculadoDto {
    private Long id;
    private String nome;
    private String email;
    private String fotoUrl;

    public UsuarioVinculadoDto(Long id, String nome, String email, String fotoUrl) {
        this.id = id;
        this.nome = nome;
        this.email = email;
        this.fotoUrl = fotoUrl;
    }

    public Long getId() { return id; }
    public String getNome() { return nome; }
    public String getEmail() { return email; }
    public String getFotoUrl() { return fotoUrl; }
}