package com.auth.simpleauth.dto;

import java.time.LocalDateTime;

public class PedidoVinculoDto {
    private Long vinculoId;
    private Long familiarId;
    private String nomeFamiliar;
    private String emailFamiliar;
    private String fotoFamiliarUrl; // Foto do familiar para a tela do idoso
    private LocalDateTime dataSolicitacao;

    public PedidoVinculoDto(Long vinculoId, Long familiarId, String nomeFamiliar, String emailFamiliar, String fotoFamiliarUrl, LocalDateTime dataSolicitacao) {
        this.vinculoId = vinculoId;
        this.familiarId = familiarId;
        this.nomeFamiliar = nomeFamiliar;
        this.emailFamiliar = emailFamiliar;
        this.fotoFamiliarUrl = fotoFamiliarUrl;
        this.dataSolicitacao = dataSolicitacao;
    }

    public Long getVinculoId() { return vinculoId; }
    public Long getFamiliarId() { return familiarId; }
    public String getNomeFamiliar() { return nomeFamiliar; }
    public String getEmailFamiliar() { return emailFamiliar; }
    public String getFotoFamiliarUrl() { return fotoFamiliarUrl; }
    public LocalDateTime getDataSolicitacao() { return dataSolicitacao; }
}