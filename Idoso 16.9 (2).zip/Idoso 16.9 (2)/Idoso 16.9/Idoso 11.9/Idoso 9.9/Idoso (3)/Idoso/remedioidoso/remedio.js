document.addEventListener("DOMContentLoaded", () => {
    const btnNotify = document.getElementById("btn-notify");
    const statusBadge = document.getElementById("status-badge");

    if (btnNotify && statusBadge) {
        btnNotify.addEventListener("click", () => {
            alert("✅ Notificação enviada para o seu familiar com sucesso!");

            statusBadge.classList.remove("status-not-taken");
            statusBadge.classList.add("status-taken");
            statusBadge.innerHTML = "✅ O REMÉDIO FOI TOMADO!";

            btnNotify.classList.remove("action-notify");
            btnNotify.classList.add("action-sent");
            btnNotify.innerHTML = "NOTIFICAÇÃO DE REMÉDIO TOMADO FOI ENVIADA AO FAMILIAR COM SUCESSO!";

            btnNotify.disabled = true;
        });
    }
});