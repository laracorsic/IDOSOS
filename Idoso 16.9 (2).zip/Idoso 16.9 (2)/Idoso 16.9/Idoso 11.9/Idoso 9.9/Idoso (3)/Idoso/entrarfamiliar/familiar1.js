const API_BASE_URL = 'http://localhost:8080';


document.addEventListener("DOMContentLoaded", () => {


    // ==========================================
    // 1. BOTÃO VOLTAR
    // ==========================================

    const btnVoltar = document.getElementById("btnVoltar");

    if (btnVoltar) {

        btnVoltar.addEventListener("click", () => {

            window.history.back();

        });

    }


    // ==========================================
    // 2. JANELA "PRECISA DE AJUDA?"
    // ==========================================

    const btnAjuda = document.getElementById("btnAjuda");

    const modalAjuda = document.getElementById("modalAjuda");

    const fecharAjuda = document.getElementById("fecharAjuda");


    // Abrir a ajuda

    if (btnAjuda && modalAjuda) {

        btnAjuda.addEventListener("click", () => {

            modalAjuda.classList.add("aberto");

        });

    }


    // Fechar a ajuda pelo botão ENTENDI

    if (fecharAjuda && modalAjuda) {

        fecharAjuda.addEventListener("click", () => {

            modalAjuda.classList.remove("aberto");

        });

    }


    // Fechar também quando clicar fora da caixa

    if (modalAjuda) {

        modalAjuda.addEventListener("click", (event) => {

            if (event.target === modalAjuda) {

                modalAjuda.classList.remove("aberto");

            }

        });

    }


    // ==========================================
    // 3. MÁSCARA DO TELEFONE
    // ==========================================

    const inputTelefone =
        document.getElementById("telefone");


    if (inputTelefone) {

        inputTelefone.setAttribute(
            "maxlength",
            "15"
        );


        inputTelefone.addEventListener(
            "input",
            (event) => {

                let valor = event.target.value;


                // Remove tudo que não for número

                valor = valor.replace(/\D/g, "");


                // Limita aos 11 números do telefone

                valor = valor.substring(0, 11);


                // Coloca o (

                if (valor.length > 0) {

                    valor = "(" + valor;

                }


                // Coloca o )

                if (valor.length > 3) {

                    valor =
                        valor.slice(0, 3) +
                        ") " +
                        valor.slice(3);

                }


                // Coloca o -

                if (valor.length > 10) {

                    valor =
                        valor.slice(0, 10) +
                        "-" +
                        valor.slice(10);

                }


                event.target.value = valor;

            }
        );

    }


    // ==========================================
    // 4. ENVIO DO FORMULÁRIO
    // ==========================================

    const formFamiliar =
        document.getElementById(
            "formCadastroFamiliar"
        );


    if (formFamiliar) {

        formFamiliar.addEventListener(
            "submit",
            async (event) => {

                event.preventDefault();


                const nomeDigitado =
                    document.getElementById(
                        "nome"
                    ).value;


                const telefoneDigitado =
                    document.getElementById(
                        "telefone"
                    ).value;


                const idadeDigitada =
                    document.getElementById(
                        "idade"
                    ).value;


                const dadosFamiliar = {

                    nome: nomeDigitado,

                    telefone: telefoneDigitado,

                    idade: parseInt(
                        idadeDigitada,
                        10
                    )

                };


                try {

                    const response =
                        await fetch(
                            `${API_BASE_URL}/familiares`,
                            {
                                method: "POST",

                                headers: {
                                    "Content-Type":
                                        "application/json"
                                },

                                body:
                                    JSON.stringify(
                                        dadosFamiliar
                                    )
                            }
                        );


                    if (!response.ok) {

                        throw new Error(
                            `Erro no servidor: ${response.status}`
                        );

                    }


                    const respostaServidor =
                        await response.json();


                    console.log(
                        "Familiar registrado com sucesso:",
                        respostaServidor
                    );


                    // Define o tipo de usuário

                    respostaServidor.userType =
                        "familiar";


                    // Salva os dados

                    localStorage.setItem(
                        "currentUser",
                        JSON.stringify(
                            respostaServidor
                        )
                    );


                    // Vai para a página de vínculo

                    window.location.href =
                        "../vinculo/vinculo.html";


                } catch (error) {

                    console.error(
                        "Falha ao registrar familiar:",
                        error
                    );


                    alert(
                        "Ocorreu um erro ao tentar entrar. " +
                        "Verifique se o servidor Java está rodando."
                    );

                }

            }
        );

    }

});
