const categoryIcons = {
  "Frutas e verduras": "🍎",
  Açougue: "🥩",
  Mercearia: "🛒",
  "Laticínios e frios": "🧀",
  Padaria: "🥖",
  Limpeza: "🧹",
  "Higiene pessoal": "🧼",
  Bebidas: "🥤",
  Congelados: "🧊",
  "Enlatados e conservas": "🥫",
  "Utensílios domésticos": "🍳",
  "Pet shop": "🐾",
  "Casa e ferramentas": "🔧",
  Jardinagem: "🪴",
  Papelaria: "✏️",
  "Roupas e costura": "🧵",
  "Outros itens": "🛍️"
};

const catalog = {
  "Frutas e verduras": [
    ["Banana prata", "kg", "🍌"], ["Maçã", "kg", "🍎"], ["Laranja", "kg", "🍊"],
    ["Mamão", "unidade", "🍈"], ["Tomate", "kg", "🍅"], ["Batata", "kg", "🥔"],
    ["Cebola", "kg", "🧅"], ["Alface", "unidade", "🥬"], ["Cenoura", "kg", "🥕"],
    ["Limão", "kg", "🍋"], ["Uva", "bandeja", "🍇"], ["Melancia", "unidade", "🍉"]
  ],
  Açougue: [
    ["Carne moída", "kg", "🥩"], ["Bife bovino", "kg", "🥩"], ["Coxão mole", "kg", "🥩"],
    ["Acém", "kg", "🥩"], ["Peito de frango", "kg", "🍗"], ["Coxa e sobrecoxa", "kg", "🍗"],
    ["Filé de frango", "kg", "🍗"], ["Carne suína", "kg", "🥓"], ["Linguiça", "kg", "🌭"],
    ["Patinho", "kg", "🥩"], ["Costela bovina", "kg", "🍖"], ["Peixe em filé", "kg", "🐟"]
  ],
  Mercearia: [
    ["Arroz branco", "pacote de 5 kg", "🍚"], ["Feijão carioca", "pacote de 1 kg", "🫘"],
    ["Feijão preto", "pacote de 1 kg", "🫘"], ["Café torrado e moído", "pacote de 500 g", "☕"],
    ["Açúcar", "pacote de 1 kg", "🧂"], ["Sal", "pacote de 1 kg", "🧂"],
    ["Óleo de soja", "garrafa de 900 ml", "🫗"], ["Macarrão espaguete", "pacote de 500 g", "🍝"],
    ["Farinha de trigo", "pacote de 1 kg", "🌾"], ["Farinha de mandioca", "pacote de 1 kg", "🌾"],
    ["Fubá", "pacote de 500 g", "🌽"], ["Aveia", "pacote de 500 g", "🥣"],
    ["Molho de tomate", "sachê", "🍅"], ["Biscoito água e sal", "pacote", "🍘"],
    ["Biscoito doce", "pacote", "🍪"], ["Milho para pipoca", "pacote de 500 g", "🍿"]
  ],
  "Laticínios e frios": [
    ["Leite integral", "caixa de 1 litro", "🥛"], ["Leite desnatado", "caixa de 1 litro", "🥛"],
    ["Leite em pó", "lata", "🥛"], ["Queijo muçarela", "pacote", "🧀"], ["Queijo minas", "unidade", "🧀"],
    ["Requeijão", "copo", "🧀"], ["Manteiga", "pote", "🧈"], ["Margarina", "pote", "🧈"],
    ["Iogurte", "unidade", "🥣"], ["Ovos", "dúzia", "🥚"], ["Presunto fatiado", "pacote", "🥪"],
    ["Creme de leite", "caixinha", "🥛"]
  ],
  Padaria: [
    ["Pão francês", "unidade", "🥖"], ["Pão de forma", "pacote", "🍞"], ["Pão integral", "pacote", "🍞"],
    ["Pão de queijo", "pacote", "🧀"], ["Bolo simples", "unidade", "🍰"], ["Torrada", "pacote", "🍞"],
    ["Pão de hot dog", "pacote", "🌭"], ["Pão de hambúrguer", "pacote", "🍔"],
    ["Rosquinha", "pacote", "🍩"], ["Broa de milho", "unidade", "🌽"]
  ],
  Limpeza: [
    ["Detergente", "frasco", "🧴"], ["Sabão em pó", "pacote", "🫧"], ["Sabão em barra", "pacote", "🧼"],
    ["Água sanitária", "frasco", "🧴"], ["Desinfetante", "frasco", "🧴"], ["Amaciante", "frasco", "🧴"],
    ["Esponja de lavar louça", "unidade", "🧽"], ["Saco de lixo", "rolo", "🗑️"],
    ["Papel higiênico", "pacote com 12 rolos", "🧻"], ["Papel-toalha", "pacote", "🧻"],
    ["Limpador multiuso", "frasco", "✨"], ["Sabão líquido para roupas", "frasco", "🫧"]
  ],
  "Higiene pessoal": [
    ["Sabonete", "unidade", "🧼"], ["Shampoo", "frasco", "🧴"], ["Condicionador", "frasco", "🧴"],
    ["Creme dental", "tubo", "🪥"], ["Escova de dentes", "unidade", "🪥"], ["Fio dental", "unidade", "🦷"],
    ["Desodorante", "unidade", "🧴"], ["Hidratante corporal", "frasco", "🧴"],
    ["Algodão", "pacote", "☁️"], ["Absorvente", "pacote", "🧻"]
  ],
  Bebidas: [
    ["Água mineral", "garrafa de 1,5 litro", "💧"], ["Água com gás", "garrafa", "💧"],
    ["Suco de laranja", "caixa de 1 litro", "🧃"], ["Suco de uva", "caixa de 1 litro", "🧃"],
    ["Refrigerante", "garrafa de 2 litros", "🥤"], ["Chá", "caixa", "🫖"],
    ["Achocolatado", "caixa", "🥛"], ["Água de coco", "caixa", "🥥"],
    ["Café solúvel", "frasco", "☕"], ["Refresco em pó", "envelope", "🧃"]
  ],
  Congelados: [
    ["Legumes congelados", "pacote", "🥦"], ["Ervilha congelada", "pacote", "🫛"],
    ["Milho congelado", "pacote", "🌽"], ["Batata frita congelada", "pacote", "🍟"],
    ["Hambúrguer", "caixa", "🍔"], ["Nuggets de frango", "pacote", "🍗"],
    ["Pizza congelada", "unidade", "🍕"], ["Lasanha congelada", "unidade", "🍝"],
    ["Polpa de fruta", "pacote", "🍓"], ["Sorvete", "pote", "🍨"]
  ],
  "Enlatados e conservas": [
    ["Milho em conserva", "lata", "🌽"], ["Ervilha em conserva", "lata", "🫛"],
    ["Atum", "lata", "🐟"], ["Sardinha", "lata", "🐟"], ["Azeitona", "vidro", "🫒"],
    ["Palmito", "vidro", "🌴"], ["Seleta de legumes", "lata", "🥫"],
    ["Pepino em conserva", "vidro", "🥒"], ["Grão-de-bico", "lata", "🫘"], ["Leite condensado", "lata", "🥛"]
  ],
  "Utensílios domésticos": [
    ["Esponja de limpeza", "pacote", "🧽"], ["Pano de prato", "unidade", "🧺"],
    ["Pano multiuso", "pacote", "🧻"], ["Papel-alumínio", "rolo", "🥡"],
    ["Filme plástico", "rolo", "🥡"], ["Saco para congelar", "pacote", "🛍️"],
    ["Palito de dente", "caixa", "📦"], ["Guardanapo", "pacote", "🧻"],
    ["Filtro de papel para café", "caixa", "☕"], ["Pilhas AA", "pacote", "🔋"]
  ],
  "Pet shop": [
    ["Ração para cachorro", "pacote", "🐶"], ["Ração para gato", "pacote", "🐱"],
    ["Petisco para cachorro", "pacote", "🦴"], ["Petisco para gato", "pacote", "🐟"],
    ["Areia para gatos", "pacote", "🐾"], ["Tapete higiênico", "pacote", "🐕"],
    ["Shampoo para pets", "frasco", "🧴"], ["Sachê para cachorro", "unidade", "🐶"],
    ["Sachê para gato", "unidade", "🐱"], ["Saquinhos higiênicos", "rolo", "🐾"]
  ],
  "Casa e ferramentas": [
    ["Lâmpada LED", "unidade", "💡"], ["Pilha AAA", "pacote", "🔋"], ["Fita adesiva", "rolo", "🩹"],
    ["Fita isolante", "rolo", "🧰"], ["Extensão elétrica", "unidade", "🔌"], ["Adaptador de tomada", "unidade", "🔌"],
    ["Martelo", "unidade", "🔨"], ["Chave de fenda", "unidade", "🪛"], ["Tesoura", "unidade", "✂️"],
    ["Corda", "metro", "🪢"], ["Pregos", "pacote", "🔩"], ["Parafusos", "pacote", "🔩"]
  ],
  Jardinagem: [
    ["Terra para plantas", "pacote", "🪴"], ["Adubo para plantas", "pacote", "🌱"], ["Vaso de planta", "unidade", "🪴"],
    ["Regador", "unidade", "🚿"], ["Mangueira de jardim", "unidade", "💧"], ["Sementes de flores", "pacote", "🌷"],
    ["Sementes de tempero", "pacote", "🌿"], ["Pá de jardinagem", "unidade", "🪏"], ["Luvas de jardinagem", "par", "🧤"],
    ["Tesoura de poda", "unidade", "✂️"], ["Prato para vaso", "unidade", "🪴"], ["Borrifador", "unidade", "💦"]
  ],
  Papelaria: [
    ["Caderno", "unidade", "📓"], ["Caneta azul", "unidade", "🖊️"], ["Caneta preta", "unidade", "🖊️"],
    ["Lápis", "unidade", "✏️"], ["Borracha", "unidade", "🩷"], ["Apontador", "unidade", "✏️"],
    ["Papel sulfite", "pacote", "📄"], ["Envelope", "pacote", "✉️"], ["Cola branca", "frasco", "🧴"],
    ["Fita crepe", "rolo", "📦"], ["Marcador de texto", "unidade", "🖍️"], ["Cartolina", "folha", "📃"]
  ],
  "Roupas e costura": [
    ["Meias", "par", "🧦"], ["Camiseta", "unidade", "👕"], ["Roupa íntima", "unidade", "🩲"],
    ["Pijama", "unidade", "🛌"], ["Toalha de banho", "unidade", "🛁"], ["Toalha de rosto", "unidade", "🧖"],
    ["Lençol", "unidade", "🛏️"], ["Fronha", "unidade", "🛏️"], ["Cobertor", "unidade", "🛌"],
    ["Linha de costura", "carretel", "🧵"], ["Agulha de costura", "pacote", "🪡"], ["Botões", "pacote", "🔘"]
  ],
  "Outros itens": [
    ["Carregador de celular", "unidade", "🔌"], ["Cabo para celular", "unidade", "🔌"], ["Guarda-chuva", "unidade", "☂️"],
    ["Chinelo", "par", "🩴"], ["Travesseiro", "unidade", "🛏️"], ["Tapete", "unidade", "🧶"],
    ["Cortina", "unidade", "🪟"], ["Garrafa térmica", "unidade", "🧉"], ["Óculos de leitura", "unidade", "👓"],
    ["Controle remoto", "unidade", "📺"], ["Relógio de parede", "unidade", "🕒"], ["Capa de chuva", "unidade", "🧥"]
  ]
};

const products = Object.entries(catalog).flatMap(([category, entries]) =>
  entries.map(([name, unit, icon], index) => ({
    id: `${Object.keys(catalog).indexOf(category) + 1}-${index + 1}`,
    name,
    unit,
    category,
    icon: icon || categoryIcons[category]
  }))
);

const extraCatalog = {
  "Frutas e verduras": [["Abacaxi", "unidade", "🍍"], ["Manga", "unidade", "🥭"], ["Pepino", "kg", "🥒"], ["Brócolis", "unidade", "🥦"]],
  Açougue: [["Filé mignon", "kg", "🥩"], ["Músculo bovino", "kg", "🥩"], ["Fígado bovino", "kg", "🥩"], ["Linguiça toscana", "pacote", "🌭"]],
  Mercearia: [["Farinha de milho", "pacote", "🌽"], ["Canjica", "pacote", "🌽"], ["Lentilha", "pacote", "🫘"], ["Vinagre", "garrafa", "🍾"]],
  "Laticínios e frios": [["Leite sem lactose", "caixa de 1 litro", "🥛"], ["Iogurte natural", "unidade", "🥣"], ["Parmesão ralado", "pacote", "🧀"], ["Cream cheese", "pote", "🧀"]],
  Padaria: [["Pão de milho", "unidade", "🌽"], ["Pão sírio", "pacote", "🫓"], ["Sonho", "unidade", "🍩"], ["Croissant", "unidade", "🥐"]],
  Limpeza: [["Limpador de banheiro", "frasco", "🧴"], ["Limpa-vidros", "frasco", "🪟"], ["Luvas de limpeza", "par", "🧤"], ["Vassoura", "unidade", "🧹"]],
  "Higiene pessoal": [["Enxaguante bucal", "frasco", "🫗"], ["Pente", "unidade", "💇"], ["Lenço de papel", "pacote", "🧻"], ["Protetor solar", "frasco", "☀️"]],
  Bebidas: [["Chá de camomila", "caixa", "🫖"], ["Chá de erva-doce", "caixa", "🫖"], ["Suco de maçã", "caixa de 1 litro", "🧃"], ["Água tônica", "lata", "🥤"]],
  Congelados: [["Pão de queijo congelado", "pacote", "🧀"], ["Peixe congelado", "pacote", "🐟"], ["Mandioca congelada", "pacote", "🥔"], ["Açaí congelado", "pote", "🫐"]],
  "Enlatados e conservas": [["Tomate pelado", "lata", "🍅"], ["Coco ralado", "pacote", "🥥"], ["Aspargo em conserva", "vidro", "🌱"], ["Cogumelo em conserva", "vidro", "🍄"]],
  "Utensílios domésticos": [["Colher de pau", "unidade", "🥄"], ["Abridor de latas", "unidade", "🥫"], ["Prendedor de roupa", "pacote", "🧺"], ["Papel-manteiga", "rolo", "📜"], ["Panela de pressão", "unidade", "🍲"], ["Panela média", "unidade", "🍲"], ["Frigideira", "unidade", "🍳"], ["Caçarola", "unidade", "🍲"], ["Chaleira", "unidade", "🫖"], ["Escorredor de macarrão", "unidade", "🥣"], ["Tábua de corte", "unidade", "🪵"], ["Conjunto de talheres", "conjunto", "🍴"], ["Pratos", "conjunto", "🍽️"], ["Copos", "conjunto", "🥛"], ["Canecas", "unidade", "☕"], ["Balde", "unidade", "🪣"], ["Rodo", "unidade", "🧹"], ["Pá de lixo", "unidade", "🧹"], ["Esfregão", "unidade", "🧹"], ["Pregadores de roupa", "pacote", "🧺"], ["Cabides", "pacote", "👕"], ["Varal de chão", "unidade", "🧺"]],
  "Pet shop": [["Coleira para cachorro", "unidade", "🐕"], ["Brinquedo para gato", "unidade", "🐈"], ["Osso para cachorro", "unidade", "🦴"], ["Comedouro para pets", "unidade", "🥣"]],
  "Casa e ferramentas": [["Fusível", "unidade", "🔌"], ["Lanterna", "unidade", "🔦"], ["Bateria", "unidade", "🔋"], ["Cola instantânea", "tubo", "🧴"]]
};

products.push(...Object.entries(extraCatalog).flatMap(([category, entries], categoryIndex) =>
  entries.map(([name, unit, icon], index) => ({
    id: `extra-${categoryIndex + 1}-${index + 1}`,
    name,
    unit,
    category,
    icon
  }))
));

const moreCatalog = {
  "Frutas e verduras": [["Morango", "bandeja", "🍓"], ["Abacate", "unidade", "🥑"], ["Repolho", "unidade", "🥬"]],
  Açougue: [["Almôndegas", "kg", "🍖"], ["Frango inteiro", "unidade", "🍗"], ["Carne para panela", "kg", "🥩"]],
  Mercearia: [["Fermento em pó", "lata", "🥣"], ["Maionese", "pote", "🥫"], ["Ketchup", "frasco", "🍅"]],
  "Laticínios e frios": [["Leite fermentado", "unidade", "🥛"], ["Queijo prato", "pacote", "🧀"], ["Ricota", "unidade", "🧀"]],
  Padaria: [["Pão de centeio", "pacote", "🍞"], ["Pão doce", "unidade", "🥐"], ["Muffin", "unidade", "🧁"]],
  Limpeza: [["Desengordurante", "frasco", "🧴"], ["Escova de limpeza", "unidade", "🧹"], ["Rodo de pia", "unidade", "🧹"]],
  "Higiene pessoal": [["Papel higiênico umedecido", "pacote", "🧻"], ["Cotonetes", "caixa", "🧴"], ["Creme para mãos", "tubo", "🧴"]],
  Bebidas: [["Leite de soja", "caixa", "🥛"], ["Suco de goiaba", "caixa", "🧃"], ["Isotônico", "garrafa", "🥤"]],
  Congelados: [["Peixe empanado", "pacote", "🐟"], ["Hambúrguer vegetal", "caixa", "🍔"], ["Aipim congelado", "pacote", "🥔"]],
  "Enlatados e conservas": [["Feijão branco", "lata", "🥫"], ["Beterraba em conserva", "vidro", "🫙"], ["Pêssego em calda", "lata", "🍑"]],
  "Utensílios domésticos": [["Assadeira", "unidade", "🍳"], ["Concha", "unidade", "🥄"], ["Peneira", "unidade", "🥣"]],
  "Pet shop": [["Ração para pássaros", "pacote", "🐦"], ["Areia sanitária para gatos", "pacote", "🐈"], ["Shampoo para cachorro", "frasco", "🧴"]],
  "Casa e ferramentas": [["Trena", "unidade", "📏"], ["Alicate", "unidade", "🔧"], ["Chave Philips", "unidade", "🪛"]],
  Jardinagem: [["Sementes de alface", "pacote", "🥬"], ["Pedras para jardim", "pacote", "🪨"], ["Cachepô", "unidade", "🪴"]],
  Papelaria: [["Régua", "unidade", "📏"], ["Grampeador", "unidade", "📎"], ["Clips de papel", "caixa", "📎"]],
  "Roupas e costura": [["Alfinetes", "caixa", "📍"], ["Elástico para costura", "rolo", "🧵"], ["Zíper", "unidade", "🤐"]]
};

products.push(...Object.entries(moreCatalog).flatMap(([category, entries], categoryIndex) =>
  entries.map(([name, unit, icon], index) => ({
    id: `more-${categoryIndex + 1}-${index + 1}`,
    name,
    unit,
    category,
    icon
  }))
));

const FAMILY_WHATSAPP = "5516993966195";
const STORAGE_KEY = "lista-de-casa-itens-v1";
const QUICK_CATEGORIES = ["Mais procurados", "Mercearia", "Frutas e verduras", "Limpeza", "Utensílios domésticos", "Todos os setores"];
const POPULAR_PRODUCTS = ["Arroz branco", "Feijão carioca", "Leite integral", "Pão francês", "Ovos", "Café torrado e moído", "Banana prata", "Tomate", "Batata", "Carne moída", "Frango inteiro", "Detergente", "Papel higiênico", "Vassoura", "Panela de pressão"];
let list = loadSavedList();
let activeCategory = "Mais procurados";
let categoryBeforeSearch = "Mais procurados";
const grid = document.querySelector("#productGrid");
const search = document.querySelector("#search");
const listCount = document.querySelector("#listCount");
const listItems = document.querySelector("#listItems");
const listPanel = document.querySelector("#listPanel");
const overlay = document.querySelector("#overlay");
const toast = document.querySelector("#toast");
const categoryFilters = document.querySelector("#categoryFilters");
const categorySelect = document.querySelector("#categorySelect");
const resultCount = document.querySelector("#resultCount");
const selectedCategoryTitle = document.querySelector("#selectedCategoryTitle");
const activeRecorders = new Map();
const FAMILY_AUDIO_KEY = "lista-de-casa-recado-v1";
let familyAudio = loadFamilyAudio();
let familyRecorder = null;

function loadSavedList() {
  try {
    const saved = JSON.parse(localStorage.getItem(STORAGE_KEY) || "[]");
    return Array.isArray(saved) ? saved.filter(item => item && typeof item.name === "string" && typeof item.id === "string" && Number(item.quantity) > 0).map(item => ({
      ...item,
      description: typeof item.description === "string" ? item.description : "",
      audioData: typeof item.audioData === "string" && item.audioData.startsWith("data:audio/") ? item.audioData : ""
    })) : [];
  } catch {
    return [];
  }
}

function escapeHTML(value) {
  return String(value ?? "").replace(/[&<>"']/g, character => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[character]);
}

function normalize(text) {
  return text.toLocaleLowerCase("pt-BR").normalize("NFD").replace(/[\u0300-\u036f]/g, "");
}

function loadFamilyAudio() {
  try {
    const saved = localStorage.getItem(FAMILY_AUDIO_KEY) || "";
    return saved.startsWith("data:audio/") ? saved : "";
  } catch { return ""; }
}

function saveFamilyAudio() {
  try { if (familyAudio) localStorage.setItem(FAMILY_AUDIO_KEY, familyAudio); else localStorage.removeItem(FAMILY_AUDIO_KEY); }
  catch { showToast("Espaço insuficiente para salvar o áudio neste aparelho."); }
}

function findProductFromSpeech(phrase) {
  const ignored = new Set(["eu", "quero", "preciso", "comprar", "compra", "por", "favor", "meu", "minha", "o", "a", "os", "as", "um", "uma", "uns", "umas", "de", "do", "da", "dos", "das", "pra", "para", "e", "mais", "coloca", "coloque", "adiciona", "adicionar", "lista", "falta", "faltando", "casa", "tem", "que", "no", "na"]);
  const spoken = normalize(phrase).replace(/[^a-z0-9\s]/g, " ").split(/\s+/).filter(word => word && !ignored.has(word));
  if (!spoken.length) return null;
  let best = null;
  let bestScore = 0;
  for (const product of products) {
    const name = normalize(product.name).replace(/[^a-z0-9\s]/g, " ").split(/\s+/).filter(word => word && !ignored.has(word));
    const matched = name.filter(word => spoken.some(heard => heard === word || (word.length > 4 && heard.startsWith(word)) || (heard.length > 4 && word.startsWith(heard))));
    let score = name.length ? matched.length / name.length : 0;
    if (normalize(product.name) === normalize(phrase.trim())) score += 2;
    else if (normalize(phrase).includes(normalize(product.name))) score += 1;
    if (score > bestScore) { best = product; bestScore = score; }
  }
  return bestScore >= 0.5 ? best : null;
}

function addSpokenProducts(transcript) {
  const quantityWords = { um: 1, uma: 1, dois: 2, duas: 2, tres: 3, quatro: 4, cinco: 5, seis: 6, sete: 7, oito: 8, nove: 9, dez: 10 };
  const cleaned = transcript
    .replace(/^(por favor[, ]*)?(eu )?(quero|preciso|falta|faltam|coloque|coloca|adiciona|adicionar|comprar|compra)( (na|no|para a|para o|pra|para) (minha|minha lista|lista))?\s+/i, "")
    .replace(/[.!?]+$/g, "");
  const pieces = cleaned.split(/\s*(?:,|;|\be\b|\bmais\b)\s*/i).map(part => part.trim()).filter(Boolean);
  const added = [];
  for (const piece of pieces) {
  const numberMatch = piece.match(/^(\d+|um|uma|dois|duas|três|tres|quatro|cinco|seis|sete|oito|nove|dez)\s+(.+)$/i);
    const quantity = numberMatch ? Math.max(1, Math.min(99, Number(numberMatch[1]) || quantityWords[normalize(numberMatch[1])] || 1)) : 1;
    const name = numberMatch ? numberMatch[2] : piece;
    const found = findProductFromSpeech(name);
    if (found) {
      addToList(found.id, quantity);
      added.push(`${quantity > 1 ? `${quantity} ` : ""}${found.name}`);
    } else if (normalize(name).length >= 2) {
      const custom = { id: `voice-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`, name: name.trim(), category: "Outros itens", unit: "unidade", icon: "🛍️", isCustom: true };
      products.push(custom);
      list.push({ ...custom, quantity, description: "", audioData: "" });
      added.push(`${quantity > 1 ? `${quantity} ` : ""}${custom.name}`);
    }
  }
  if (added.length) showToast(`Adicionado: ${added.join(", ")}. Confira em Minha lista.`);
  else showToast("Não entendi o nome. Tente falar de novo, um produto por vez.");
  return added;
}

function listenAndAddProducts() {
  const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
  const button = document.querySelector("#voiceAddButton");
  const status = document.querySelector("#voiceAddStatus");
  if (!SpeechRecognition) {
    status.textContent = "Este navegador não oferece ditado por voz. Peça à família para abrir no Chrome ou use Gravar recado para falar pelo áudio.";
    showToast("Ditado não disponível neste navegador.");
    return;
  }
  const recognition = new SpeechRecognition();
  recognition.lang = "pt-BR";
  recognition.interimResults = false;
  recognition.maxAlternatives = 1;
  button.disabled = true;
  button.textContent = "🎙️ Estou ouvindo…";
  status.textContent = "Fale agora: diga um ou mais produtos, como ‘leite, pão e vassoura’.";
  recognition.onresult = event => {
    const transcript = event.results?.[0]?.[0]?.transcript || "";
    status.textContent = `Entendi: “${transcript}”.`;
    addSpokenProducts(transcript);
  };
  recognition.onerror = event => {
    const message = event.error === "not-allowed" ? "Permita o uso do microfone nas configurações do navegador." : "Não consegui ouvir. Toque no botão e tente outra vez.";
    status.textContent = message;
  };
  recognition.onend = () => {
    button.disabled = false;
    button.textContent = "🎙️ Falar o que está faltando";
  };
  try { recognition.start(); }
  catch { button.disabled = false; button.textContent = "🎙️ Falar o que está faltando"; status.textContent = "Não consegui iniciar o microfone. Tente novamente."; }
}

function showToast(message) {
  toast.textContent = message;
  toast.classList.add("show");
  clearTimeout(showToast.timeout);
  showToast.timeout = setTimeout(() => toast.classList.remove("show"), 2500);
}

function renderCategoryFilters() {
  categoryFilters.innerHTML = QUICK_CATEGORIES.map(category => `
    <button class="category-chip${category === activeCategory ? " active" : ""}" data-category="${category}" aria-pressed="${category === activeCategory}">
      ${category === "Todos os setores" ? "🛍️" : category === "Mais procurados" ? "⭐" : categoryIcons[category]} ${category}
    </button>
  `).join("");
  categoryFilters.querySelectorAll(".category-chip").forEach(button => {
    button.addEventListener("click", () => {
      activeCategory = button.dataset.category;
      categorySelect.value = activeCategory;
      renderCategoryFilters();
      renderProducts();
    });
  });
  const allCategories = ["Mais procurados", "Todos os setores", ...Object.keys(catalog)];
  const uniqueCategories = [...new Set(allCategories)];
  categorySelect.innerHTML = `<option value="">Escolha um setor…</option>${uniqueCategories.map(category =>
    `<option value="${escapeHTML(category)}">${category === "Mais procurados" ? "⭐ " : category === "Todos os setores" ? "🛍️ " : `${categoryIcons[category]} `}${escapeHTML(category)}</option>`
  ).join("")}`;
  categorySelect.value = activeCategory;
}

function renderProducts() {
  const term = normalize(search.value.trim());
  const popularSet = new Set(POPULAR_PRODUCTS.map(normalize));
  const filtered = products.filter(item => {
    const matchesCategory = activeCategory === "Todos os setores" || (activeCategory === "Mais procurados" ? popularSet.has(normalize(item.name)) : item.category === activeCategory);
    const matchesSearch = normalize(`${item.name} ${item.category} ${item.unit}`).includes(term);
    return matchesCategory && matchesSearch;
  });
  if (activeCategory === "Mais procurados") filtered.sort((a, b) => POPULAR_PRODUCTS.map(normalize).indexOf(normalize(a.name)) - POPULAR_PRODUCTS.map(normalize).indexOf(normalize(b.name)));
  selectedCategoryTitle.textContent = activeCategory;
  resultCount.textContent = `${filtered.length} ${filtered.length === 1 ? "produto" : "produtos"}`;
  if (!filtered.length) {
    grid.innerHTML = '<p class="empty">Nenhum item encontrado. Tente outra palavra ou escolha outro setor.</p>';
    return;
  }
  grid.innerHTML = filtered.map(product => `
    <article class="product-card">
      <div class="product-illustration" aria-hidden="true">${product.icon}</div>
      <span class="category">${categoryIcons[product.category] || "🛍️"} ${escapeHTML(product.category)}</span>
      <h3>${escapeHTML(product.name)}</h3>
      <p class="product-unit">Por ${escapeHTML(product.unit)}</p>
      <div class="quantity-picker">
        <label class="quantity-label" for="quantity-${product.id}">Quantidade</label>
        <div class="quantity-controls">
          <button class="quantity-adjust" type="button" data-step="-1" data-target="quantity-${product.id}" aria-label="Diminuir quantidade de ${escapeHTML(product.name)}">−</button>
          <input id="quantity-${product.id}" class="quantity-input" type="number" min="1" max="99" value="1" inputmode="numeric" />
          <button class="quantity-adjust" type="button" data-step="1" data-target="quantity-${product.id}" aria-label="Aumentar quantidade de ${escapeHTML(product.name)}">＋</button>
        </div>
      </div>
      <button class="add-button" data-id="${product.id}">Adicionar à lista</button>
    </article>
  `).join("");
  grid.querySelectorAll(".quantity-adjust").forEach(button => button.addEventListener("click", () => {
    const input = grid.querySelector(`#${button.dataset.target}`);
    input.value = Math.max(1, Math.min(99, (Number.parseInt(input.value, 10) || 1) + Number(button.dataset.step)));
  }));
  grid.querySelectorAll(".add-button").forEach(button => {
    button.addEventListener("click", () => {
      const input = grid.querySelector(`#quantity-${button.dataset.id}`);
      const quantity = Math.max(1, Math.min(99, Number.parseInt(input.value, 10) || 1));
      addToList(button.dataset.id, quantity);
    });
  });
}

function saveList() {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(list));
  } catch {
    showToast("Não foi possível salvar a lista neste aparelho.");
  }
}

function addToList(id, quantity) {
  const product = products.find(item => item.id === id);
  const found = list.find(item => item.id === id);
  if (found) found.quantity += quantity;
  else list.push({ ...product, quantity });
  renderList();
  showToast(`${product.name} entrou na sua lista.`);
}

function renderList() {
  const count = list.reduce((sum, item) => sum + item.quantity, 0);
  listCount.textContent = count;
  if (!list.length) listItems.innerHTML = '<p>Ainda não há itens na lista.</p>';
  else listItems.innerHTML = list.map(item => {
    const hasDetails = Boolean(item.description || item.audioData);
    const detailsLabel = hasDetails ? "✅ Descrição salva · toque para abrir" : "＋ Adicionar descrição";
    return `
    <div class="list-row">
      <div class="list-row-main">
        <strong>${escapeHTML(item.icon || "🛍️")} ${escapeHTML(item.name)}</strong>
        <small>${escapeHTML(item.category || "Outro item")} · ${escapeHTML(item.unit || "unidade")}</small>
      </div>
      <div class="list-row-actions">
        <div class="list-quantity-controls" aria-label="Quantidade">
          <button type="button" class="list-quantity-adjust" data-list-id="${escapeHTML(item.id)}" data-step="-1" aria-label="Diminuir ${escapeHTML(item.name)}">−</button>
          <strong aria-live="polite">${item.quantity}</strong>
          <button type="button" class="list-quantity-adjust" data-list-id="${escapeHTML(item.id)}" data-step="1" aria-label="Aumentar ${escapeHTML(item.name)}">＋</button>
        </div>
        <button class="remove-button" data-remove="${escapeHTML(item.id)}" aria-label="Remover ${escapeHTML(item.name)}">Remover</button>
      </div>
      <details class="item-details"${activeRecorders.has(item.id) ? " open" : ""}>
        <summary>${detailsLabel}</summary>
        <div class="item-notes">
          <label for="description-${escapeHTML(item.id)}">Descrição (opcional)</label>
          <textarea id="description-${escapeHTML(item.id)}" class="item-description" data-description="${escapeHTML(item.id)}" rows="2" placeholder="Ex.: panela grande, cabo comprido">${escapeHTML(item.description || "")}</textarea>
          <div class="voice-actions">
            <button type="button" class="record-button" data-record="${escapeHTML(item.id)}">${activeRecorders.has(item.id) ? "⏹️ Parar gravação" : item.audioData ? "🎙️ Gravar de novo" : "🎙️ Gravar áudio"}</button>
            ${item.audioData ? `<button type="button" class="voice-button" data-delete-audio="${escapeHTML(item.id)}">Apagar áudio</button>` : ""}
          </div>
          ${item.audioData ? `<audio class="item-audio" controls preload="none" aria-label="Ouvir descrição de ${escapeHTML(item.name)}" src="${escapeHTML(item.audioData)}">Seu navegador não reproduz este áudio.</audio><a class="download-audio" href="${escapeHTML(item.audioData)}" download="descricao-${escapeHTML(item.id)}.${escapeHTML(item.audioData.split(";")[0].split("/")[1] || "webm")}">⬇️ Baixar áudio</a>` : ""}
          <p class="voice-status" data-status="${escapeHTML(item.id)}" aria-live="polite">${activeRecorders.has(item.id) ? "Gravando… toque em Parar quando terminar (máximo de 30 segundos)." : item.audioData ? "Áudio salvo neste aparelho." : "Digite uma descrição ou grave o áudio."}</p>
        </div>
      </details>
    </div>
  `;
  }).join("");
  listItems.querySelectorAll("[data-list-id]").forEach(button => button.addEventListener("click", () => {
    const item = list.find(entry => entry.id === button.dataset.listId);
    if (!item) return;
    const next = item.quantity + Number(button.dataset.step);
    if (next < 1) { showToast("A quantidade mínima é 1. Para tirar, use Remover."); return; }
    item.quantity = Math.min(99, next);
    renderList();
  }));
  listItems.querySelectorAll("[data-remove]").forEach(button => button.addEventListener("click", () => {
    const active = activeRecorders.get(button.dataset.remove);
    if (active?.recorder.state === "recording") active.recorder.stop();
    list = list.filter(item => item.id !== button.dataset.remove);
    renderList();
  }));
  listItems.querySelectorAll("[data-description]").forEach(field => field.addEventListener("input", () => {
    const item = list.find(entry => entry.id === field.dataset.description);
    if (item) { item.description = field.value; saveList(); }
  }));
  listItems.querySelectorAll("[data-record]").forEach(button => button.addEventListener("click", () => {
    const active = activeRecorders.get(button.dataset.record);
    if (active?.recorder.state === "recording") active.recorder.stop();
    else recordDescription(button.dataset.record, button);
  }));
  listItems.querySelectorAll("[data-delete-audio]").forEach(button => button.addEventListener("click", () => {
    const item = list.find(entry => entry.id === button.dataset.deleteAudio);
    if (item) { item.audioData = ""; renderList(); showToast("Gravação apagada."); }
  }));
  saveList();
}

async function recordDescription(id, button) {
  if (!navigator.mediaDevices?.getUserMedia || !window.MediaRecorder || !window.FileReader) {
    showToast("Gravação indisponível. Use HTTPS ou escreva a descrição.");
    return;
  }
  try {
    if (button) { button.disabled = true; button.textContent = "Aguardando microfone…"; }
    const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
    const supportedType = ["audio/webm;codecs=opus", "audio/webm", "audio/mp4"].find(type => MediaRecorder.isTypeSupported?.(type));
    const recorder = supportedType ? new MediaRecorder(stream, { mimeType: supportedType }) : new MediaRecorder(stream);
    const chunks = [];
    const status = [...listItems.querySelectorAll("[data-status]")].find(entry => entry.dataset.status === id);
    if (status) status.textContent = "Gravando… toque em Parar quando terminar (máximo de 30 segundos).";
    recorder.ondataavailable = event => { if (event.data.size) chunks.push(event.data); };
    recorder.onerror = () => showToast("Não foi possível gravar o áudio.");
    const timer = setTimeout(() => { if (recorder.state === "recording") recorder.stop(); }, 30000);
    activeRecorders.set(id, { recorder, stream, timer });
    recorder.onstop = () => {
      clearTimeout(timer);
      activeRecorders.delete(id);
      stream.getTracks().forEach(track => track.stop());
      const item = list.find(entry => entry.id === id);
      if (!item) return;
      const blob = new Blob(chunks, { type: recorder.mimeType || "audio/webm" });
      const reader = new FileReader();
      reader.onload = () => {
        item.audioData = reader.result;
        renderList();
        showToast("Áudio gravado e salvo neste aparelho.");
      };
      reader.onerror = () => showToast("Não foi possível salvar esta gravação.");
      reader.readAsDataURL(blob);
    };
    recorder.start();
    renderList();
  } catch (error) {
    if (button) { button.disabled = false; button.textContent = "🎙️ Gravar descrição"; }
    showToast(error.name === "NotAllowedError" ? "Permita o acesso ao microfone para gravar." : "Não foi possível acessar o microfone.");
  }
}

function toggleList(open) {
  listPanel.classList.toggle("open", open);
  listPanel.setAttribute("aria-hidden", String(!open));
  overlay.hidden = !open;
  if (open) document.querySelector("#closeList").focus();
}

function sendList() {
  if (!list.length && !familyAudio) {
    showToast("Adicione algum item antes de enviar.");
    return;
  }
  const text = ["Olá! Esta é a lista do que está faltando em casa:", "", ...list.map(item => `• ${item.name} (${item.category || "Outro"}) — quantidade: ${item.quantity} ${item.unit || "unidade"}${item.description ? `\n  Descrição: ${item.description}` : ""}${item.audioData ? "\n  (Há uma gravação de áudio deste item.)" : ""}`), familyAudio ? "\nTambém gravei um recado de voz para você." : "", "Obrigado!"].join("\n");
  const audioItems = list.filter(item => item.audioData);
  if ((audioItems.length || familyAudio) && navigator.share && navigator.canShare && window.File) {
    try {
      const files = audioItems.map(item => {
        const safeName = item.name.replace(/[^a-z0-9]/gi, "-").toLowerCase();
        return audioDataToFile(item.audioData, `audio-${safeName}`);
      });
      if (familyAudio) files.push(audioDataToFile(familyAudio, "recado-para-familia"));
      if (navigator.canShare({ files })) {
        navigator.share({ title: "Lista de Casa", text, files }).catch(error => {
          if (error.name !== "AbortError") showToast("Compartilhamento cancelado. Você ainda pode enviar a lista por texto.");
        });
        return;
      }
    } catch { /* navegador sem envio de arquivos: usar mensagem de texto */ }
  }
  window.open(`https://wa.me/${FAMILY_WHATSAPP}?text=${encodeURIComponent(text)}`, "_blank", "noopener");
  if (audioItems.length || familyAudio) showToast("Mensagem pronta. Anexe o áudio baixado na conversa do WhatsApp.");
}

function audioDataToFile(dataUrl, baseName) {
  const [metadata, content] = dataUrl.split(",", 2);
  const mime = metadata.match(/data:([^;]+)/)?.[1] || "audio/webm";
  const bytes = Uint8Array.from(atob(content), character => character.charCodeAt(0));
  const extension = mime.includes("mp4") ? "m4a" : mime.includes("ogg") ? "ogg" : "webm";
  return new File([bytes], `${baseName}.${extension}`, { type: mime });
}

function renderFamilyAudio() {
  const player = document.querySelector("#familyAudioPlayer");
  const download = document.querySelector("#downloadFamilyAudio");
  const removeButton = document.querySelector("#deleteFamilyVoiceButton");
  if (familyAudio) {
    player.src = familyAudio;
    player.hidden = false;
    download.href = familyAudio;
    download.download = `recado-para-familia.${familyAudio.split(";")[0].split("/")[1] || "webm"}`;
    download.hidden = false;
    removeButton.hidden = false;
    document.querySelector("#familyAudioStatus").textContent = "Seu recado está pronto e será compartilhado com a lista.";
  } else {
    player.removeAttribute("src");
    player.hidden = true;
    download.removeAttribute("href");
    download.hidden = true;
    removeButton.hidden = true;
  }
}

async function recordFamilyVoice() {
  if (activeRecorders.size) {
    showToast("Termine primeiro a gravação da descrição do produto.");
    return;
  }
  if (!navigator.mediaDevices?.getUserMedia || !window.MediaRecorder || !window.FileReader) {
    showToast("Para gravar, abra a página no Chrome pelo HTTPS ou localhost.");
    document.querySelector("#familyAudioStatus").textContent = "A gravação precisa de acesso ao microfone e HTTPS ou localhost.";
    return;
  }
  const recordButton = document.querySelector("#familyVoiceButton");
  const stopButton = document.querySelector("#stopFamilyVoiceButton");
  recordButton.disabled = true;
  document.querySelector("#familyAudioStatus").textContent = "Aguardando permissão para usar o microfone…";
  try {
    const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
    const supportedType = ["audio/webm;codecs=opus", "audio/webm", "audio/mp4"].find(type => MediaRecorder.isTypeSupported?.(type));
    const recorder = supportedType ? new MediaRecorder(stream, { mimeType: supportedType }) : new MediaRecorder(stream);
    const chunks = [];
    const timer = setTimeout(() => { if (recorder.state === "recording") recorder.stop(); }, 30000);
    familyRecorder = { recorder, stream, timer };
    recordButton.hidden = true;
    recordButton.disabled = false;
    stopButton.hidden = false;
    document.querySelector("#familyAudioStatus").textContent = "Gravando… fale agora. Toque em Parar gravação quando terminar.";
    recorder.ondataavailable = event => { if (event.data.size) chunks.push(event.data); };
    recorder.onerror = () => { document.querySelector("#familyAudioStatus").textContent = "Houve um problema durante a gravação."; };
    recorder.onstop = () => {
      clearTimeout(timer);
      stream.getTracks().forEach(track => track.stop());
      familyRecorder = null;
      stopButton.hidden = true;
      recordButton.hidden = false;
      const reader = new FileReader();
      reader.onload = () => {
        familyAudio = reader.result;
        saveFamilyAudio();
        renderFamilyAudio();
        showToast("Recado gravado. Será enviado com a lista.");
      };
      reader.onerror = () => { document.querySelector("#familyAudioStatus").textContent = "Não foi possível salvar o áudio. Tente gravar de novo."; };
      reader.readAsDataURL(new Blob(chunks, { type: recorder.mimeType || "audio/webm" }));
    };
    recorder.start();
  } catch (error) {
    recordButton.hidden = false;
    recordButton.disabled = false;
    const message = error.name === "NotAllowedError" ? "Permita o uso do microfone nas configurações do navegador." : "Não consegui usar o microfone. Abra no Chrome pelo HTTPS ou localhost.";
    document.querySelector("#familyAudioStatus").textContent = message;
    showToast(message);
  }
}

function addCustomProduct(event) {
  event.preventDefault();
  const form = event.currentTarget;
  const name = form.elements.name.value.trim();
  if (!name) { form.elements.name.focus(); return; }
  const category = form.elements.category.value;
  const quantity = Math.max(1, Math.min(99, Number.parseInt(form.elements.quantity.value, 10) || 1));
  const product = {
    id: `custom-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
    name,
    category,
    unit: form.elements.unit.value.trim() || "unidade",
    icon: categoryIcons[category] || "🛍️",
    description: form.elements.description.value.trim(),
    isCustom: true
  };
  products.push(product);
  list.push({ ...product, quantity, audioData: "" });
  renderList();
  form.reset();
  form.elements.quantity.value = "1";
  showToast(`${name} foi adicionado à sua lista.`);
  document.querySelector("#customName").focus();
}

function populateCustomCategories() {
  const categories = Object.keys(catalog).sort((a, b) => a === "Outros itens" ? -1 : b === "Outros itens" ? 1 : a.localeCompare(b, "pt-BR"));
  document.querySelector("#customCategory").innerHTML = categories.map(category =>
    `<option value="${escapeHTML(category)}"${category === "Outros itens" ? " selected" : ""}>${categoryIcons[category]} ${escapeHTML(category)}</option>`
  ).join("");
}

search.addEventListener("input", () => {
  if (search.value.trim()) activeCategory = "Todos os setores";
  else activeCategory = categoryBeforeSearch || "Mais procurados";
  renderCategoryFilters();
  renderProducts();
});
categorySelect.addEventListener("change", () => {
  if (!categorySelect.value) return;
  activeCategory = categorySelect.value;
  categoryBeforeSearch = activeCategory;
  search.value = "";
  renderCategoryFilters();
  renderProducts();
});
categoryFilters.addEventListener("click", event => {
  const button = event.target.closest("[data-category]");
  if (button) categoryBeforeSearch = button.dataset.category;
});
document.querySelector("#listButton").addEventListener("click", () => toggleList(true));
document.querySelector("#closeList").addEventListener("click", () => toggleList(false));
overlay.addEventListener("click", () => toggleList(false));
document.querySelector("#sendButton").addEventListener("click", sendList);
document.querySelector("#voiceAddButton").addEventListener("click", listenAndAddProducts);
document.querySelector("#familyVoiceButton").addEventListener("click", recordFamilyVoice);
document.querySelector("#stopFamilyVoiceButton").addEventListener("click", () => {
  if (familyRecorder?.recorder.state === "recording") {
    document.querySelector("#familyAudioStatus").textContent = "Salvando seu recado…";
    familyRecorder.recorder.stop();
  }
});
document.querySelector("#deleteFamilyVoiceButton").addEventListener("click", () => {
  familyAudio = "";
  saveFamilyAudio();
  renderFamilyAudio();
  document.querySelector("#familyAudioStatus").textContent = "Recado apagado. Toque em Gravar recado para fazer outro.";
});
document.querySelector("#clearButton").addEventListener("click", () => {
  activeRecorders.forEach(({ recorder }) => { if (recorder.state === "recording") recorder.stop(); });
  list = [];
  renderList();
  showToast("Lista limpa.");
});
document.querySelector("#customProductForm").addEventListener("submit", addCustomProduct);
document.addEventListener("keydown", event => { if (event.key === "Escape") toggleList(false); });
populateCustomCategories();
renderCategoryFilters();
renderProducts();
renderList();
renderFamilyAudio();
