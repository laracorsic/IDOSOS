# Lista de Casa — demonstração

Lista de compras simples, organizada em passos curtos para pessoas idosas. O botão de voz fica no início; os produtos comuns vêm primeiro; descrições, recados e envio ficam dentro de **Minha lista**.

## Recursos

- **312 produtos em 17 setores**, incluindo alimentos, limpeza, utensílios, panelas, vassoura, roupas, jardinagem, ferramentas e papelaria.
- A tela abre com **15 produtos mais procurados**. Há atalhos para setores frequentes e um seletor com todos os setores.
- A busca procura em todos os produtos, mesmo que o setor exibido seja outro.
- Botão grande **Falar o que está faltando** para dizer um ou vários produtos sem digitar.
- Dentro de **Minha lista**, ajuste quantidades com **+** e **−**. A descrição de cada item fica recolhida em **Adicionar descrição** para a lista não ficar carregada. Ela pode ser escrita ou gravada em áudio.
- Grave um recado curto para a família ou uma descrição de item. É possível ouvir, baixar ou apagar o áudio.
- **Enviar para WhatsApp** abre as opções de compartilhamento com texto e áudio quando o celular for compatível.
- A lista e os áudios ficam salvos neste aparelho. Não é preciso configurar uma API.

## Como abrir

1. Abra a pasta `loja-idosos-demo` no VS Code.
2. Inicie `index.html` com **Live Server** (`localhost`) ou hospede em HTTPS.
3. Autorize o acesso ao microfone.

O navegador precisa ter reconhecimento de voz em português para adicionar produtos falando. Se não tiver, ainda é possível gravar um recado em áudio e baixar para anexar à conversa do WhatsApp.

## Uso simples

1. Toque em **Falar o que está faltando** ou toque em **Adicionar à lista** num produto.
2. Abra **Minha lista** para mudar quantidades, adicionar uma descrição ou gravar um recado.
3. Toque em **Enviar para WhatsApp**, escolha WhatsApp no menu do celular e toque em **Enviar**.

Para mudar o telefone configurado, edite `FAMILY_WHATSAPP` em `app.js` (código do país e DDD, apenas números).
