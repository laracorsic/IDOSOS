const API_BASE = "http://localhost:8080";

document.addEventListener("DOMContentLoaded", () => {
    carregarFamiliares();
    carregarCuidadores();
    carregarIdosos();
    carregarRemedios();
    carregarLembretes();
});


const formFamiliar = document.getElementById("formFamiliar");
formFamiliar.addEventListener("submit", async (e) => {
    e.preventDefault();
    const id = document.getElementById("familiarId").value;
    const body = {
        nome: document.getElementById("familiarNome").value,
        idade: parseInt(document.getElementById("familiarIdade").value),
        telefone: document.getElementById("familiarTelefone").value
    };

    const url = id ? `${API_BASE}/familiares/${id}` : `${API_BASE}/familiares`;
    const method = id ? "PUT" : "POST";

    await fetch(url, {
        method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body)
    });

    formFamiliar.reset();
    document.getElementById("familiarId").value = "";
    carregarFamiliares();
});

async function carregarFamiliares() {
    const res = await fetch(`${API_BASE}/familiares`);
    const dados = await res.json();
    
    
    const tbody = document.getElementById("tabelaFamiliares");
    tbody.innerHTML = "";
    
    const selectFamiliar = document.getElementById("idosoFamiliar");
    selectFamiliar.innerHTML = `<option value="">Nenhum</option>`;

    dados.forEach(f => {
        tbody.innerHTML += `
            <tr>
                <td>${f.nome}</td>
                <td>${f.idade}</td>
                <td>${f.telefone}</td>
                <td>
                    <button class="btn btn-sm btn-warning" onclick="editarFamiliar(${f.id}, '${f.nome}', ${f.idade}, '${f.telefone}')">Editar</button>
                    <button class="btn btn-sm btn-danger" onclick="deletar('${API_BASE}/familiares', ${f.id}, carregarFamiliares)">Excluir</button>
                </td>
            </tr>
        `;
        selectFamiliar.innerHTML += `<option value="${f.id}">${f.nome}</option>`;
    });
}

function editarFamiliar(id, nome, idade, telefone) {
    document.getElementById("familiarId").value = id;
    document.getElementById("familiarNome").value = nome;
    document.getElementById("familiarIdade").value = idade;
    document.getElementById("familiarTelefone").value = telefone;
}



const formCuidador = document.getElementById("formCuidador");
formCuidador.addEventListener("submit", async (e) => {
    e.preventDefault();
    const id = document.getElementById("cuidadorId").value;
    const body = {
        nome: document.getElementById("cuidadorNome").value,
        telefone: document.getElementById("cuidadorTelefone").value,
        cpf: document.getElementById("cuidadorCpf").value
    };

    const url = id ? `${API_BASE}/cuidadores/${id}` : `${API_BASE}/cuidadores`;
    const method = id ? "PUT" : "POST";

    await fetch(url, {
        method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body)
    });

    formCuidador.reset();
    document.getElementById("cuidadorId").value = "";
    carregarCuidadores();
});

async function carregarCuidadores() {
    const res = await fetch(`${API_BASE}/cuidadores`);
    const dados = await res.json();
    
    const tbody = document.getElementById("tabelaCuidadores");
    tbody.innerHTML = "";
    
    const selectCuidador = document.getElementById("idosoCuidador");
    selectCuidador.innerHTML = `<option value="">Nenhum</option>`;

    dados.forEach(c => {
        tbody.innerHTML += `
            <tr>
                <td>${c.nome}</td>
                <td>${c.telefone}</td>
                <td>${c.cpf}</td>
                <td>
                    <button class="btn btn-sm btn-warning" onclick="editarCuidador(${c.id}, '${c.nome}', '${c.telefone}', '${c.cpf}')">Editar</button>
                    <button class="btn btn-sm btn-danger" onclick="deletar('${API_BASE}/cuidadores', ${c.id}, carregarCuidadores)">Excluir</button>
                </td>
            </tr>
        `;
        selectCuidador.innerHTML += `<option value="${c.id}">${c.nome}</option>`;
    });
}

function editarCuidador(id, nome, telefone, cpf) {
    document.getElementById("cuidadorId").value = id;
    document.getElementById("cuidadorNome").value = nome;
    document.getElementById("cuidadorTelefone").value = telefone;
    document.getElementById("cuidadorCpf").value = cpf;
}



const formIdoso = document.getElementById("formIdoso");
formIdoso.addEventListener("submit", async (e) => {
    e.preventDefault();
    const id = document.getElementById("idosoId").value;
    const idFamiliar = document.getElementById("idosoFamiliar").value;
    const idCuidador = document.getElementById("idosoCuidador").value;

    const body = {
        nome: document.getElementById("idosoNome").value,
        idade: parseInt(document.getElementById("idosoIdade").value),
        telefone: document.getElementById("idosoTelefone").value,
        idFamiliar: idFamiliar ? parseInt(idFamiliar) : null,
        idCuidador: idCuidador ? parseInt(idCuidador) : null
    };

    const url = id ? `${API_BASE}/idosos/${id}` : `${API_BASE}/idosos`;
    const method = id ? "PUT" : "POST";

    await fetch(url, {
        method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body)
    });

    formIdoso.reset();
    document.getElementById("idosoId").value = "";
    carregarIdosos();
});

async function carregarIdosos() {
    const res = await fetch(`${API_BASE}/idosos`);
    const dados = await res.json();
    
    const tbody = document.getElementById("tabelaIdosos");
    tbody.innerHTML = "";
    
    const selectIdoso = document.getElementById("remedioIdoso");
    selectIdoso.innerHTML = `<option value="">Selecione...</option>`;

    dados.forEach(i => {
        const familiarNome = i.familiar ? i.familiar.nome : "-";
        const cuidadorNome = i.cuidador ? i.cuidador.nome : "-";
        const idFamiliar = i.familiar ? i.familiar.id : "";
        const idCuidador = i.cuidador ? i.cuidador.id : "";

        tbody.innerHTML += `
            <tr>
                <td>${i.nome}</td>
                <td>${i.idade}</td>
                <td>${i.telefone}</td>
                <td>${familiarNome}</td>
                <td>${cuidadorNome}</td>
                <td>
                    <button class="btn btn-sm btn-warning" onclick="editarIdoso(${i.id}, '${i.nome}', ${i.idade}, '${i.telefone}', '${idFamiliar}', '${idCuidador}')">Editar</button>
                    <button class="btn btn-sm btn-danger" onclick="deletar('${API_BASE}/idosos', ${i.id}, carregarIdosos)">Excluir</button>
                </td>
            </tr>
        `;
        selectIdoso.innerHTML += `<option value="${i.id}">${i.nome}</option>`;
    });
}

function editarIdoso(id, nome, idade, telefone, idFamiliar, idCuidador) {
    document.getElementById("idosoId").value = id;
    document.getElementById("idosoNome").value = nome;
    document.getElementById("idosoIdade").value = idade;
    document.getElementById("idosoTelefone").value = telefone;
    document.getElementById("idosoFamiliar").value = idFamiliar;
    document.getElementById("idosoCuidador").value = idCuidador;
}



const formRemedio = document.getElementById("formRemedio");
formRemedio.addEventListener("submit", async (e) => {
    e.preventDefault();
    const id = document.getElementById("remedioId").value;
    const idIdoso = document.getElementById("remedioIdoso").value;

    const body = {
        nome: document.getElementById("remedioNome").value,
        dosagem: parseFloat(document.getElementById("remedioDosagem").value),
        intervalo: parseFloat(document.getElementById("remedioIntervalo").value),
        hora: document.getElementById("remedioHora").value,
        idIdoso: idIdoso ? parseInt(idIdoso) : null
    };

    const url = id ? `${API_BASE}/remedios/${id}` : `${API_BASE}/remedios`;
    const method = id ? "PUT" : "POST";

    await fetch(url, {
        method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body)
    });

    formRemedio.reset();
    document.getElementById("remedioId").value = "";
    carregarRemedios();
});

async function carregarRemedios() {
    const res = await fetch(`${API_BASE}/remedios`);
    const dados = await res.json();
    
    const tbody = document.getElementById("tabelaRemedios");
    tbody.innerHTML = "";
    
    const selectRemedio = document.getElementById("lembreteRemedio");
    selectRemedio.innerHTML = `<option value="">Selecione...</option>`;

    dados.forEach(r => {
        const idosoNome = r.idoso ? r.idoso.nome : "-";
        const idIdoso = r.idoso ? r.idoso.id : "";

        tbody.innerHTML += `
            <tr>
                <td>${r.nome}</td>
                <td>${r.dosagem}</td>
                <td>${r.intervalo}h</td>
                <td>${r.hora}</td>
                <td>${idosoNome}</td>
                <td>
                    <button class="btn btn-sm btn-warning" onclick="editarRemedio(${r.id}, '${r.nome}', ${r.dosagem}, ${r.intervalo}, '${r.hora}', '${idIdoso}')">Editar</button>
                    <button class="btn btn-sm btn-danger" onclick="deletar('${API_BASE}/remedios', ${r.id}, carregarRemedios)">Excluir</button>
                </td>
            </tr>
        `;
        selectRemedio.innerHTML += `<option value="${r.id}">${r.nome} (Idoso: ${idosoNome})</option>`;
    });
}

function editarRemedio(id, nome, dosagem, intervalo, hora, idIdoso) {
    document.getElementById("remedioId").value = id;
    document.getElementById("remedioNome").value = nome;
    document.getElementById("remedioDosagem").value = dosagem;
    document.getElementById("remedioIntervalo").value = intervalo;
    document.getElementById("remedioHora").value = hora;
    document.getElementById("remedioIdoso").value = idIdoso;
}


const formLembrete = document.getElementById("formLembrete");
formLembrete.addEventListener("submit", async (e) => {
    e.preventDefault();
    const id = document.getElementById("lembreteId").value;
    const idRemedio = document.getElementById("lembreteRemedio").value;

    const body = {
        descricao: document.getElementById("lembreteDescricao").value,
        data_hora: document.getElementById("lembreteDataHora").value,
        idRemedio: idRemedio ? parseInt(idRemedio) : null
    };

    const url = id ? `${API_BASE}/lembretes/${id}` : `${API_BASE}/lembretes`;
    const method = id ? "PUT" : "POST";

    await fetch(url, {
        method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body)
    });

    formLembrete.reset();
    document.getElementById("lembreteId").value = "";
    carregarLembretes();
});

async function carregarLembretes() {
    const res = await fetch(`${API_BASE}/lembretes`);
    const dados = await res.json();
    
    const tbody = document.getElementById("tabelaLembretes");
    tbody.innerHTML = "";

    dados.forEach(l => {
        const remedioNome = l.remedio ? l.remedio.nome : "-";
        const idosoNome = (l.remedio && l.remedio.idoso) ? l.remedio.idoso.nome : "-";
        const idRemedio = l.remedio ? l.remedio.id : "";
        
   
        const dataFormatada = l.data_hora ? l.data_hora.substring(0, 16) : "";

        tbody.innerHTML += `
            <tr>
                <td>${l.descricao}</td>
                <td>${l.data_hora ? new Date(l.data_hora).toLocaleString('pt-BR') : '-'}</td>
                <td>${remedioNome} (${idosoNome})</td>
                <td>
                    <button class="btn btn-sm btn-warning" onclick="editarLembrete(${l.id}, '${l.descricao}', '${dataFormatada}', '${idRemedio}')">Editar</button>
                    <button class="btn btn-sm btn-danger" onclick="deletar('${API_BASE}/lembretes', ${l.id}, carregarLembretes)">Excluir</button>
                </td>
            </tr>
        `;
    });
}

function editarLembrete(id, descricao, dataHora, idRemedio) {
    document.getElementById("lembreteId").value = id;
    document.getElementById("lembreteDescricao").value = descricao;
    document.getElementById("lembreteDataHora").value = dataHora;
    document.getElementById("lembreteRemedio").value = idRemedio;
}

async function deletar(url, id, callback) {
    if (confirm("Tem certeza que deseja excluir este registro?")) {
        await fetch(`${url}/${id}`, { method: "DELETE" });
        callback();
    }
}