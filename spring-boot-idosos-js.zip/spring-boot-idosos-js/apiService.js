const API_BASE_URL = 'http://localhost:8080';


async function apiRequest(endpoint, method = 'GET', data = null) {
  const config = {
    method: method,
    headers: {
      'Content-Type': 'application/json',
      'Accept': 'application/json'
    }
  };

  if (data && (method === 'POST' || method === 'PUT')) {
    config.body = JSON.stringify(data);
  }

  try {
    const response = await fetch(`${API_BASE_URL}${endpoint}`, config);
    if (response.status === 204) return null; 
    
    if (!response.ok) {
      throw new Error(`Erro na requisição: ${response.status}`);
    }
    return await response.json();
  } catch (error) {
    console.error(`[API Error] ${method} ${endpoint}:`, error);
    throw error;
  }
}

const IdosoService = {
  listar: () => apiRequest('/idosos'),
  cadastrar: (dados) => apiRequest('/idosos', 'POST', dados),
  deletar: (id) => apiRequest(`/idosos/${id}`, 'DELETE')
};

const FamiliarService = {
  listar: () => apiRequest('/familiares'),
  cadastrar: (dados) => apiRequest('/familiares', 'POST', dados),
  deletar: (id) => apiRequest(`/familiares/${id}`, 'DELETE')
};

const RemedioService = {
  listar: () => apiRequest('/remedios'),
  cadastrar: (dados) => apiRequest('/remedios', 'POST', dados),
  deletar: (id) => apiRequest(`/remedios/${id}`, 'DELETE')
};

const LembreteService = {
  listar: () => apiRequest('/lembretes'),
  cadastrar: (dados) => apiRequest('/lembretes', 'POST', dados),
  deletar: (id) => apiRequest(`/lembretes/${id}`, 'DELETE')
};