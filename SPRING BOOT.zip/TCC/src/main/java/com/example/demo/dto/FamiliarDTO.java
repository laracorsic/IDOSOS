package com.example.demo.dto;

public class FamiliarDTO {
    private String nome;
    private int idade;


    public FamiliarDTO(String nome, int idade) {
        this.nome = nome;
        this.idade = idade;
    }

    public String getNome() {
        return nome;
    }

    public int getIdade() {
        return idade;
    }
}






