package com.example.demo.entity;

import jakarta.persistence.*;
import java.util.List;

@Entity
@Table(name = "idoso")
public class Idoso {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String nome;
    private int idade;

    @OneToMany(mappedBy = "idoso", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<Remedio> remedios;

    @OneToMany(mappedBy = "idoso", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<Lembrete> lembretes;

    @ManyToMany
    @JoinTable(
            name = "idoso_familiar",
            joinColumns = @JoinColumn(name = "id_idoso"),
            inverseJoinColumns = @JoinColumn(name = "id_familiar")
    )
    private List<Familiar> familiares;

    protected Idoso() {}

    public Idoso(String nome, int idade) {
        this.nome = nome;
        this.idade = idade;
    }

    public Long getId() {
        return id;
    }

    public String getNome() {
        return nome;
    }

    public int getIdade() {
        return idade;
    }

    public List<Remedio> getRemedios() {
        return remedios;
    }

    public List<Lembrete> getLembretes() {
        return lembretes;
    }

    public List<Familiar> getFamiliares() {
        return familiares;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public void setIdade(int idade) {
        this.idade = idade;
    }

    public void setRemedios(List<Remedio> remedios) {
        this.remedios = remedios;
    }

    public void setLembretes(List<Lembrete> lembretes) {
        this.lembretes = lembretes;
    }

    public void setFamiliares(List<Familiar> familiares) {
        this.familiares = familiares;
    }
}