package com.example.demo.dto;

public class IdosoDTO {
    private String nome;
    private int idade;

    public IdosoDTO(String nome, int idade) {
        this.nome = nome;
        this.idade = idade;
    }

    public String getNome() {
        return nome;
    }

    public int getIdade() {
        return idade;
    }
}






