package com.example.demo.service;

import com.example.demo.dto.FamiliarDTO;
import com.example.demo.dto.FamiliarDTO;
import com.example.demo.entity.Familiar;
import com.example.demo.repository.FamiliarRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service

public class FamiliarService {

    @Autowired

    private FamiliarRepository repository;

    @Transactional

    public void cadastrar(FamiliarDTO familiarDTO){
        repository.save(new Familiar(familiarDTO.getNome(), familiarDTO.getIdade()));
    }

    public List<Familiar> listar(){
        return repository.findAll();
    }

    @Transactional
    public void atualizar(Long id, FamiliarDTO familiarDTO){
        Familiar familiarEncontrado = repository.getReferenceById(id);
        if (familiarEncontrado == null) {
            System.out.println("familiar não existe");
        }else{
            familiarEncontrado.setNome(familiarDTO.getNome());
            familiarEncontrado.setIdade(familiarDTO.getIdade());
        }
    }

    @Transactional
    public void remover(Long id) {
        Familiar familiarEncontrado = repository.getReferenceById(id);
        if (familiarEncontrado != null) {
            repository.deleteById(id);
        } else {
            System.out.println("Familiar não existe");
        }
    }
}