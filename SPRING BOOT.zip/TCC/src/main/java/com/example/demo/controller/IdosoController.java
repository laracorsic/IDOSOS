package com.example.demo.controller;

import com.example.demo.dto.IdosoDTO;
import com.example.demo.entity.Idoso;
import com.example.demo.service.IdosoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/idosos")
@CrossOrigin(origins = "*")
public class IdosoController {

    @Autowired
    private IdosoService service;

    @PostMapping
    public void cadastrar(@RequestBody IdosoDTO dto){

        service.cadastrar(dto);
    }

    @GetMapping
    public ResponseEntity<List<Idoso>> listar(){
        List<Idoso> lista = service.listar();
        return ResponseEntity.ok(lista);
    }

    @PutMapping("/{id}")
    public void atualizar(@PathVariable Long id, @RequestBody IdosoDTO dto){

        service.atualizar(id, dto);
    }

    @DeleteMapping("/{id}")
    public void remover(@PathVariable Long id){
        service.remover(id);
    }
}