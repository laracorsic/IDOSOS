package com.example.demo.controller;

import com.example.demo.dto.FamiliarDTO;
import com.example.demo.dto.IdosoDTO;
import com.example.demo.entity.Familiar;
import com.example.demo.entity.Idoso;
import com.example.demo.service.FamiliarService;
import com.example.demo.service.IdosoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/familiares")
@CrossOrigin(origins = "*")
public class FamiliarController {

    @Autowired
    private FamiliarService service;

    @PostMapping
    public void cadastrar(@RequestBody FamiliarDTO dto){

        service.cadastrar(dto);
    }

    @GetMapping
    public ResponseEntity<List<Familiar>> listar(){
        List<Familiar> lista = service.listar();
        return ResponseEntity.ok(lista);
    }

    @PutMapping("/{id}")
    public void atualizar(@PathVariable Long id, @RequestBody FamiliarDTO dto){

        service.atualizar(id, dto);
    }

    @DeleteMapping("/{id}")
    public void remover(@PathVariable Long id){
        service.remover(id);
    }
}