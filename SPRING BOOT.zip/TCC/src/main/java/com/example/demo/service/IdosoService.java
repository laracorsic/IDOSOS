package com.example.demo.service;

import com.example.demo.dto.IdosoDTO;
import com.example.demo.entity.Idoso;
import com.example.demo.repository.IdosoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service

public class IdosoService {

    @Autowired

    private IdosoRepository repository;

    @Transactional

    public void cadastrar(IdosoDTO idosoDTO){
        repository.save(new Idoso(idosoDTO.getNome(), idosoDTO.getIdade()));
    }

    public List<Idoso> listar(){
        return repository.findAll();
    }

    @Transactional
    public void atualizar(Long id, IdosoDTO idosoDTO){
       Idoso idosoEncontrado = repository.getReferenceById(id);
        if (idosoEncontrado == null) {
            System.out.println("Idoso não existe");
        }else{
           idosoEncontrado.setNome(idosoDTO.getNome());
           idosoEncontrado.setIdade(idosoDTO.getIdade());
        }
    }

    @Transactional
    public void remover(Long id) {
       Idoso idosoEncontrado = repository.getReferenceById(id);
        if (idosoEncontrado != null) {
            repository.deleteById(id);
        } else {
            System.out.println("Idoso não existe");
        }
    }
}