package com.auth.simpleauth.dto;

import com.auth.simpleauth.enums.Perfil;
import jakarta.validation.Validation;
import jakarta.validation.Validator;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class UsuarioCadastroDtoValidacaoTest {
    private final Validator validator = Validation.buildDefaultValidatorFactory().getValidator();

    private UsuarioCadastroDto cadastro(Perfil perfil, Integer idade) {
        return new UsuarioCadastroDto("Maria da Silva", "maria@example.com", "SenhaForte42", "(11) 99999-9999", null, perfil, idade);
    }

    @Test
    void familiarNaoPrecisaInformarIdade() {
        assertTrue(validator.validate(cadastro(Perfil.FAMILIAR, null)).isEmpty());
    }

    @Test
    void idosoPrecisaTerIdadeEntreUmECentoEVinte() {
        assertFalse(validator.validate(cadastro(Perfil.IDOSO, null)).isEmpty());
        assertFalse(validator.validate(cadastro(Perfil.IDOSO, 121)).isEmpty());
        assertTrue(validator.validate(cadastro(Perfil.IDOSO, 75)).isEmpty());
    }
}
