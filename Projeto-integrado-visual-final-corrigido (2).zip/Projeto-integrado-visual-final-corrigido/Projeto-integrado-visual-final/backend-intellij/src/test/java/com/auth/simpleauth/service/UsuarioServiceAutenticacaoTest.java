package com.auth.simpleauth.service;

import com.auth.simpleauth.entity.Familiar;
import com.auth.simpleauth.entity.Usuario;
import com.auth.simpleauth.repository.TokenAcessoLembradoRepository;
import com.auth.simpleauth.repository.UsuarioRepository;
import com.auth.simpleauth.repository.VinculoFamiliarRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

class UsuarioServiceAutenticacaoTest {
    private UsuarioRepository usuarios;
    private TokenAcessoLembradoRepository tokens;
    private BCryptPasswordEncoder encoder;
    private UsuarioService service;

    @BeforeEach
    void preparar() {
        usuarios = mock(UsuarioRepository.class);
        tokens = mock(TokenAcessoLembradoRepository.class);
        encoder = new BCryptPasswordEncoder(4);
        service = new UsuarioService(usuarios, mock(VinculoFamiliarRepository.class), tokens, encoder);
    }

    @Test
    void novasContasArmazenamHashEAutenticamSemDiferenciarCaixaDoEmail() {
        Familiar familiar = new Familiar("Ana Exemplo", "ANA@EXEMPLO.COM", "SenhaLegal42", "(11) 99999-9999", null);
        when(usuarios.save(any(Usuario.class))).thenAnswer(inv -> inv.getArgument(0));
        service.criaNovoUsuario(familiar);

        assertNotEquals("SenhaLegal42", familiar.getSenha());
        assertTrue(encoder.matches("SenhaLegal42", familiar.getSenha()));
        when(usuarios.findByEmailIgnoreCase("ana@exemplo.com")).thenReturn(Optional.of(familiar));
        assertTrue(service.autenticar("  ana@exemplo.com ", "SenhaLegal42").isPresent());
        assertTrue(service.autenticar("ana@exemplo.com", "incorreta").isEmpty());
    }

    @Test
    void senhaLegadaEmTextoPuroEhMigradaNoPrimeiroLogin() {
        Familiar familiar = new Familiar("Ana Exemplo", "ana@exemplo.com", "senha-antiga", "11999999999", null);
        when(usuarios.findByEmailIgnoreCase("ana@exemplo.com")).thenReturn(Optional.of(familiar));
        when(usuarios.save(any(Usuario.class))).thenAnswer(inv -> inv.getArgument(0));

        assertTrue(service.autenticar("ana@exemplo.com", "senha-antiga").isPresent());
        assertNotEquals("senha-antiga", familiar.getSenha());
        assertTrue(encoder.matches("senha-antiga", familiar.getSenha()));
        verify(usuarios).save(familiar);
    }

    @Test
    void loginInvalidoNaoRetornaConta() {
        when(usuarios.findByEmailIgnoreCase("naoexiste@example.com")).thenReturn(Optional.empty());
        assertTrue(service.autenticar("naoexiste@example.com", "qualquer").isEmpty());
        verify(usuarios, never()).save(any());
    }
}
