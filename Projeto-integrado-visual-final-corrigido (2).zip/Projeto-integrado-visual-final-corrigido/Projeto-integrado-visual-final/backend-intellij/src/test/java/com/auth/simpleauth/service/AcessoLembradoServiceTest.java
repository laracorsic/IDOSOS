package com.auth.simpleauth.service;

import com.auth.simpleauth.entity.Familiar;
import com.auth.simpleauth.entity.TokenAcessoLembrado;
import com.auth.simpleauth.entity.Usuario;
import com.auth.simpleauth.repository.TokenAcessoLembradoRepository;
import com.auth.simpleauth.repository.UsuarioRepository;
import jakarta.servlet.http.Cookie;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpServletResponse;

import java.time.Instant;
import java.util.Optional;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.*;

class AcessoLembradoServiceTest {
    @Test
    void emiteCookieHttpOnlyEArmazenaSomenteHashDoToken() {
        TokenAcessoLembradoRepository tokens = mock(TokenAcessoLembradoRepository.class);
        UsuarioRepository usuarios = mock(UsuarioRepository.class);
        AcessoLembradoService service = new AcessoLembradoService(tokens, usuarios, true, "None");
        Usuario usuario = new Familiar("Ana", "ana@example.com", "hash-da-senha", "11999999999", null);
        usuario.setId(42L);
        MockHttpServletResponse response = new MockHttpServletResponse();

        service.prepararLogin(usuario, true, new MockHttpServletRequest(), response);

        String setCookie = response.getHeader("Set-Cookie");
        assertNotNull(setCookie);
        assertTrue(setCookie.contains("HttpOnly"));
        assertTrue(setCookie.contains("Secure"));
        assertTrue(setCookie.contains("Max-Age=31536000"));
        Matcher matcher = Pattern.compile("ZELO_REMEMBER=([^;]+)").matcher(setCookie);
        assertTrue(matcher.find());
        String tokenEmCookie = matcher.group(1);

        ArgumentCaptor<TokenAcessoLembrado> captor = ArgumentCaptor.forClass(TokenAcessoLembrado.class);
        verify(tokens).save(captor.capture());
        TokenAcessoLembrado registro = captor.getValue();
        assertEquals(42L, registro.getUsuarioId());
        assertNotEquals(tokenEmCookie, registro.getTokenHash());
        assertEquals(64, registro.getTokenHash().length());

        when(tokens.findByTokenHashAndExpiraEmAfter(eq(registro.getTokenHash()), any(Instant.class)))
                .thenReturn(Optional.of(registro));
        when(usuarios.findById(42L)).thenReturn(Optional.of(usuario));
        MockHttpServletRequest request = new MockHttpServletRequest();
        request.setCookies(new Cookie(AcessoLembradoService.COOKIE_NAME, tokenEmCookie));
        MockHttpServletResponse restoreResponse = new MockHttpServletResponse();

        assertTrue(service.restaurarSessao(request, restoreResponse));
        assertSame(usuario, request.getSession(false).getAttribute("usuario"));
    }

    @Test
    void loginSemLembrarRemoveCookieAnterior() {
        TokenAcessoLembradoRepository tokens = mock(TokenAcessoLembradoRepository.class);
        AcessoLembradoService service = new AcessoLembradoService(tokens, mock(UsuarioRepository.class), false, "Lax");
        MockHttpServletRequest request = new MockHttpServletRequest();
        request.setCookies(new Cookie(AcessoLembradoService.COOKIE_NAME, "token-antigo"));
        MockHttpServletResponse response = new MockHttpServletResponse();
        Usuario usuario = new Familiar("Ana", "ana@example.com", "hash", "11999999999", null);

        service.prepararLogin(usuario, false, request, response);

        verify(tokens).deleteByTokenHash(any(String.class));
        assertTrue(response.getHeader("Set-Cookie").contains("Max-Age=0"));
    }
}
