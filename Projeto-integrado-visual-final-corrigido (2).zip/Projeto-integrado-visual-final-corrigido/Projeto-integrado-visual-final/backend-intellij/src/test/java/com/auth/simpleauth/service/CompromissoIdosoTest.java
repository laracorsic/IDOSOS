package com.auth.simpleauth.service;

import com.auth.simpleauth.config.TestableClock;
import com.auth.simpleauth.dto.CompromissoDto;
import com.auth.simpleauth.entity.Compromisso;
import com.auth.simpleauth.entity.Familiar;
import com.auth.simpleauth.entity.Idoso;
import com.auth.simpleauth.entity.VinculoFamiliarIdoso;
import com.auth.simpleauth.enums.StatusVinculo;
import com.auth.simpleauth.repository.CompromissoRepository;
import com.auth.simpleauth.repository.FamiliarRepository;
import com.auth.simpleauth.repository.IdosoRepository;
import com.auth.simpleauth.repository.VinculoFamiliarRepository;
import org.junit.jupiter.api.Test;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

class CompromissoIdosoTest {

    @Test
    void salvaEventoDoIdosoENotificaFamiliaresComVinculoAprovado() {
        CompromissoRepository compromissoRepository = mock(CompromissoRepository.class);
        IdosoRepository idosoRepository = mock(IdosoRepository.class);
        FamiliarRepository familiarRepository = mock(FamiliarRepository.class);
        VinculoFamiliarRepository vinculoRepository = mock(VinculoFamiliarRepository.class);
        WebPushNotificationService push = mock(WebPushNotificationService.class);
        TestableClock clock = new TestableClock("America/Sao_Paulo");

        Idoso idoso = new Idoso("Dona Ana", "ana@example.test", "senha", null, null, null);
        idoso.setId(12L);
        Familiar familiar = mock(Familiar.class);
        when(familiar.getId()).thenReturn(34L);
        VinculoFamiliarIdoso vinculo = mock(VinculoFamiliarIdoso.class);
        when(vinculo.getFamiliar()).thenReturn(familiar);
        when(idosoRepository.findById(12L)).thenReturn(Optional.of(idoso));
        when(vinculoRepository.findByIdosoIdAndStatusWithFamiliar(12L, StatusVinculo.ACEITO))
                .thenReturn(List.of(vinculo));
        when(compromissoRepository.save(any(Compromisso.class)))
                .thenAnswer(invocation -> invocation.getArgument(0));

        CompromissoService service = new CompromissoService(
                compromissoRepository, idosoRepository, familiarRepository, vinculoRepository, push, clock);
        CompromissoDto entrada = new CompromissoDto();
        entrada.setIdIdoso(12L);
        entrada.setTitulo("Ir ao parque");
        entrada.setCategoria("LAZER");
        entrada.setDataHora(LocalDateTime.now(clock).plusDays(2));
        entrada.setLocal("Parque Central");
        entrada.setObservacao("Levar água");

        CompromissoDto salvo = service.criar(idoso, entrada);

        assertEquals("LAZER", salvo.getCategoria());
        assertEquals("Levar água", salvo.getObservacao());
        assertTrue(salvo.isCriadoPeloIdoso());
        verify(compromissoRepository).save(argThat(c ->
                c.getIdoso().getId().equals(12L)
                        && "Ir ao parque".equals(c.getTitulo())
                        && "LAZER".equals(c.getCategoria())
                        && c.isCriadoPeloIdoso()));
        verify(push).notificar(eq(12L), eq("Novo evento do idoso"), contains("Ir ao parque"), anyString());
        verify(push).notificar(eq(34L), eq("Novo evento do idoso"), contains("Ir ao parque"), anyString());
    }
}
