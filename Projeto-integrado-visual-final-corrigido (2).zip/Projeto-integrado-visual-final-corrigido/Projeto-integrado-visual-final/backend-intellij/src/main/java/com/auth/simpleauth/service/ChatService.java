package com.auth.simpleauth.service;

import com.auth.simpleauth.dto.ChatDtos;
import com.auth.simpleauth.entity.*;
import com.auth.simpleauth.enums.Perfil;
import com.auth.simpleauth.repository.*;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.time.LocalDateTime;
import java.util.List;

@Service
public class ChatService {
    private final ChatMensagemRepository mensagens;
    private final UsuarioRepository usuarios;
    private final IdosoRepository idosos;
    private final FamiliarRepository familiares;
    private final VinculoFamiliarRepository vinculos;
    private final WebPushNotificationService push;

    public ChatService(ChatMensagemRepository mensagens, UsuarioRepository usuarios, IdosoRepository idosos,
                       FamiliarRepository familiares, VinculoFamiliarRepository vinculos, WebPushNotificationService push) {
        this.mensagens = mensagens; this.usuarios = usuarios; this.idosos = idosos; this.familiares = familiares;
        this.vinculos = vinculos; this.push = push;
    }

    @Transactional(readOnly = true)
    public List<ChatDtos.Mensagem> listar(Long usuarioId, Perfil perfil, Long idosoId) {
        Par par = parAutorizado(usuarioId, perfil, idosoId);
        return mensagens.findByIdosoIdAndFamiliarIdOrderByEnviadaEmAsc(par.idoso.getId(), par.familiar.getId(), PageRequest.of(0, 100))
                .stream().map(ChatDtos.Mensagem::de).toList();
    }

    @Transactional
    public ChatDtos.Mensagem enviar(Long usuarioId, Perfil perfil, ChatDtos.EnviarMensagem dto) {
        if (dto == null || dto.texto() == null || dto.texto().trim().isBlank()) throw new IllegalArgumentException("Escreva uma mensagem.");
        if (dto.texto().trim().length() > 2000) throw new IllegalArgumentException("A mensagem deve ter no máximo 2000 caracteres.");
        Par par = parAutorizado(usuarioId, perfil, dto.idosoId());
        Usuario remetente = usuarios.findById(usuarioId).orElseThrow();
        ChatMensagem salva = mensagens.save(new ChatMensagem(par.idoso, par.familiar, remetente, dto.texto().trim(), LocalDateTime.now()));
        Long destino = remetente.getId().equals(par.idoso.getId()) ? par.familiar.getId() : par.idoso.getId();
        push.notificar(destino, "Nova mensagem", remetente.getNome() + " enviou uma mensagem para você.", "/inicio" + (perfil == Perfil.IDOSO ? "familiar/iniciofamiliar.html" : "idoso/inicioidoso.html"));
        return ChatDtos.Mensagem.de(salva);
    }

    private Par parAutorizado(Long usuarioId, Perfil perfil, Long idosoId) {
        if (usuarioId == null || idosoId == null) throw new SecurityException("Conversa inválida.");
        Idoso idoso = idosos.findById(idosoId).orElseThrow(() -> new IllegalArgumentException("Idoso não encontrado."));
        Familiar familiar;
        if (perfil == Perfil.IDOSO) {
            if (!idoso.getId().equals(usuarioId)) throw new SecurityException("Acesso negado.");
            familiar = vinculos.findByIdosoIdAndStatusWithFamiliar(idosoId, com.auth.simpleauth.enums.StatusVinculo.ACEITO)
                    .stream().findFirst().map(VinculoFamiliarIdoso::getFamiliar)
                    .orElseThrow(() -> new IllegalArgumentException("Este idoso ainda não possui familiar vinculado."));
        } else {
            familiar = familiares.findById(usuarioId).orElseThrow(() -> new SecurityException("Acesso negado."));
            if (!vinculos.existsByFamiliarIdAndIdosoIdAndStatus(usuarioId, idosoId, com.auth.simpleauth.enums.StatusVinculo.ACEITO))
                throw new SecurityException("Você não possui vínculo aprovado com este idoso.");
        }
        return new Par(idoso, familiar);
    }
    private record Par(Idoso idoso, Familiar familiar) {}
}
