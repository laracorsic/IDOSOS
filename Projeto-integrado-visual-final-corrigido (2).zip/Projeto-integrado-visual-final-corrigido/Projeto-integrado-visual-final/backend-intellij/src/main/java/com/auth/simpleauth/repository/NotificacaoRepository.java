package com.auth.simpleauth.repository;

import com.auth.simpleauth.entity.Notificacao;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.time.LocalDateTime;
import java.util.List;

public interface NotificacaoRepository extends JpaRepository<Notificacao, Long> {
    List<Notificacao> findByUsuarioIdOrderByCriadaEmDesc(Long usuarioId, Pageable pageable);

    @Modifying
    @Query("delete from Notificacao n where n.usuario.id = :usuarioId")
    int excluirTodasDoUsuario(@Param("usuarioId") Long usuarioId);

    @Modifying
    @Query("delete from Notificacao n where n.criadaEm < :limite")
    int excluirAntigas(@Param("limite") LocalDateTime limite);
}
