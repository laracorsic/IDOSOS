package com.auth.simpleauth.repository;

import com.auth.simpleauth.entity.Compromisso;
import org.springframework.data.jpa.repository.JpaRepository;
import java.time.LocalDateTime;
import java.util.List;

public interface CompromissoRepository extends JpaRepository<Compromisso, Long> {
    List<Compromisso> findByIdosoIdAndDataHoraGreaterThanEqualOrderByDataHoraAsc(Long idosoId, LocalDateTime desde);
    List<Compromisso> findByLembreteEnviadoFalseAndDataHoraGreaterThanEqualAndDataHoraLessThanEqual(LocalDateTime agora, LocalDateTime limite);
}
