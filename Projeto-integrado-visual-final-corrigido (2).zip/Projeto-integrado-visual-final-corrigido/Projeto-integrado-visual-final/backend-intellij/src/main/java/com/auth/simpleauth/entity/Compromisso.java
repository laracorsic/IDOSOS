package com.auth.simpleauth.entity;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "tbl_compromisso", indexes = {
        @Index(name = "idx_compromisso_idoso_data", columnList = "idoso_id, data_hora")
})
public class Compromisso {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, length = 160)
    private String titulo;

    @Column(name = "data_hora", nullable = false)
    private LocalDateTime dataHora;

    @Column(length = 240)
    private String local;

    @Column(length = 32)
    private String categoria;

    @Column(length = 500)
    private String observacao;

    @Column(name = "criado_pelo_idoso")
    private Boolean criadoPeloIdoso = false;

    @Column(nullable = false)
    private boolean lembreteEnviado = false;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "idoso_id", nullable = false)
    private Idoso idoso;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "familiar_id", nullable = true)
    private Familiar familiarCriador;

    public Compromisso() {}

    public Compromisso(String titulo, LocalDateTime dataHora, String local, Idoso idoso, Familiar familiarCriador) {
        this.titulo = titulo;
        this.dataHora = dataHora;
        this.local = local;
        this.idoso = idoso;
        this.familiarCriador = familiarCriador;
    }

    public Long getId() { return id; }
    public String getTitulo() { return titulo; }
    public void setTitulo(String titulo) { this.titulo = titulo; }
    public LocalDateTime getDataHora() { return dataHora; }
    public void setDataHora(LocalDateTime dataHora) { this.dataHora = dataHora; }
    public String getLocal() { return local; }
    public void setLocal(String local) { this.local = local; }
    public String getCategoria() { return categoria; }
    public void setCategoria(String categoria) { this.categoria = categoria; }
    public String getObservacao() { return observacao; }
    public void setObservacao(String observacao) { this.observacao = observacao; }
    public boolean isCriadoPeloIdoso() { return Boolean.TRUE.equals(criadoPeloIdoso); }
    public void setCriadoPeloIdoso(boolean criadoPeloIdoso) { this.criadoPeloIdoso = criadoPeloIdoso; }
    public boolean isLembreteEnviado() { return lembreteEnviado; }
    public void setLembreteEnviado(boolean lembreteEnviado) { this.lembreteEnviado = lembreteEnviado; }
    public Idoso getIdoso() { return idoso; }
    public Familiar getFamiliarCriador() { return familiarCriador; }
}
