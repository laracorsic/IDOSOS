package com.auth.simpleauth.dto;

import jakarta.validation.constraints.AssertTrue;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;

public class AtualizarTelefoneDto {
    @NotBlank(message = "Informe seu telefone.")
    @Pattern(regexp = "^[+0-9() .-]{10,20}$", message = "Informe um telefone válido com DDD.")
    private String telefone;

    public AtualizarTelefoneDto() {}
    public String getTelefone() { return telefone; }
    public void setTelefone(String telefone) { this.telefone = telefone; }

    @AssertTrue(message = "Informe um telefone brasileiro válido com DDD (10 ou 11 dígitos).")
    public boolean isTelefoneBrasileiroValido() {
        if (telefone == null || telefone.isBlank()) return true;
        String digitos = telefone.replaceAll("\\D", "");
        if (digitos.startsWith("55") && (digitos.length() == 12 || digitos.length() == 13)) digitos = digitos.substring(2);
        return digitos.length() == 10 || digitos.length() == 11;
    }
}
