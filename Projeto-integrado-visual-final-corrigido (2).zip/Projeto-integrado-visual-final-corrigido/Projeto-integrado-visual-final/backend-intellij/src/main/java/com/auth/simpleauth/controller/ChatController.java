package com.auth.simpleauth.controller;

import com.auth.simpleauth.dto.ChatDtos;
import com.auth.simpleauth.entity.Usuario;
import com.auth.simpleauth.enums.Perfil;
import com.auth.simpleauth.service.ChatService;
import jakarta.servlet.http.HttpSession;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/chat")
public class ChatController {
    private final ChatService service;
    public ChatController(ChatService service) { this.service = service; }

    @GetMapping("/mensagens")
    public List<ChatDtos.Mensagem> listar(@RequestParam Long idosoId, HttpSession session) {
        Usuario u = usuario(session); return service.listar(u.getId(), u.getPerfil(), idosoId);
    }
    @PostMapping("/mensagens")
    public ChatDtos.Mensagem enviar(@RequestBody ChatDtos.EnviarMensagem dto, HttpSession session) {
        Usuario u = usuario(session); return service.enviar(u.getId(), u.getPerfil(), dto);
    }
    private static Usuario usuario(HttpSession s) {
        Object u = s.getAttribute("usuario");
        if (u instanceof Usuario usuario) return usuario;
        throw new SecurityException("Sessão inválida. Entre novamente.");
    }
}
