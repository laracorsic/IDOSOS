package com.auth.simpleauth.config;

import com.auth.simpleauth.service.AcessoLembradoService;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;

@Component
public class AutenticacaoInterceptor implements HandlerInterceptor {
    private final AcessoLembradoService acessoLembradoService;

    public AutenticacaoInterceptor(AcessoLembradoService acessoLembradoService) {
        this.acessoLembradoService = acessoLembradoService;
    }

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
        if ("OPTIONS".equalsIgnoreCase(request.getMethod())) {
            response.setStatus(HttpServletResponse.SC_OK);
            return true;
        }

        HttpSession session = request.getSession(false);
        if (session != null && session.getAttribute("usuario") != null) return true;
        if (acessoLembradoService.restaurarSessao(request, response)) return true;

        response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
        response.setContentType("application/json;charset=UTF-8");
        response.getWriter().write("{\"message\":\"Sua sessão terminou. Entre novamente para continuar.\"}");
        return false;
    }
}
