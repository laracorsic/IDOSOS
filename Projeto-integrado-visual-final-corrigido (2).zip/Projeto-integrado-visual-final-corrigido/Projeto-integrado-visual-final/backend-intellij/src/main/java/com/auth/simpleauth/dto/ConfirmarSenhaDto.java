package com.auth.simpleauth.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

public class ConfirmarSenhaDto {
    @NotBlank(message = "Informe sua senha atual para confirmar.")
    @Size(max = 128, message = "A senha informada é inválida.")
    private String senha;

    public ConfirmarSenhaDto() {}
    public String getSenha() { return senha; }
    public void setSenha(String senha) { this.senha = senha; }
}
