package com.auth.simpleauth.service;

import com.auth.simpleauth.dto.CompromissoDto;
import com.auth.simpleauth.config.TestableClock;
import com.auth.simpleauth.entity.Compromisso;
import com.auth.simpleauth.entity.Familiar;
import com.auth.simpleauth.entity.Idoso;
import com.auth.simpleauth.entity.Usuario;
import com.auth.simpleauth.enums.Perfil;
import com.auth.simpleauth.enums.StatusVinculo;
import com.auth.simpleauth.repository.CompromissoRepository;
import com.auth.simpleauth.repository.FamiliarRepository;
import com.auth.simpleauth.repository.IdosoRepository;
import com.auth.simpleauth.repository.VinculoFamiliarRepository;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class CompromissoService {
    private final CompromissoRepository compromissoRepository;
    private final IdosoRepository idosoRepository;
    private final FamiliarRepository familiarRepository;
    private final VinculoFamiliarRepository vinculoRepository;
    private final WebPushNotificationService push;
    private final TestableClock clock;

    public CompromissoService(CompromissoRepository compromissoRepository,
                              IdosoRepository idosoRepository,
                              FamiliarRepository familiarRepository,
                              VinculoFamiliarRepository vinculoRepository,
                              WebPushNotificationService push,
                              TestableClock clock) {
        this.compromissoRepository = compromissoRepository;
        this.idosoRepository = idosoRepository;
        this.familiarRepository = familiarRepository;
        this.vinculoRepository = vinculoRepository;
        this.push = push;
        this.clock = clock;
    }

    @Transactional
    public CompromissoDto criar(Usuario solicitante, CompromissoDto dto) {
        if (solicitante == null) throw new SecurityException("Sessão inválida. Entre novamente.");
        validarDto(dto);
        Long idosoId = dto.getIdIdoso();
        boolean criadoPeloIdoso = solicitante.getPerfil() == Perfil.IDOSO;
        if (criadoPeloIdoso) {
            if (!solicitante.getId().equals(idosoId)) {
                throw new SecurityException("O idoso só pode cadastrar eventos no próprio perfil.");
            }
        } else if (solicitante.getPerfil() == Perfil.FAMILIAR) {
            if (!vinculoRepository.existsByFamiliarIdAndIdosoIdAndStatus(solicitante.getId(), idosoId, StatusVinculo.ACEITO)) {
                throw new SecurityException("Você não possui vínculo aprovado com este idoso.");
            }
        } else {
            throw new SecurityException("Este perfil não pode cadastrar compromissos.");
        }
        Idoso idoso = idosoRepository.findById(idosoId)
                .orElseThrow(() -> new IllegalArgumentException("Idoso não encontrado."));
        Familiar familiar = criadoPeloIdoso ? idoso.getFamiliar() : familiarRepository.findById(solicitante.getId())
                .orElseThrow(() -> new IllegalArgumentException("Familiar não encontrado."));
        Compromisso novo = new Compromisso(
                dto.getTitulo().trim(), dto.getDataHora(), limpar(dto.getLocal()), idoso, familiar);
        novo.setCategoria(limpar(dto.getCategoria()));
        novo.setObservacao(limpar(dto.getObservacao()));
        novo.setCriadoPeloIdoso(criadoPeloIdoso);
        novo.setLembreteEnviado(!dto.getDataHora().isAfter(LocalDateTime.now(clock).plusHours(24)));
        Compromisso salvo = compromissoRepository.save(novo);
        String tituloNotificacao = criadoPeloIdoso ? "Novo evento do idoso" : "Novo compromisso";
        String mensagem = idoso.getNome() + (criadoPeloIdoso ? " cadastrou " : ": ") + salvo.getTitulo()
                + " em " + salvo.getDataHora().toLocalDate() + " às "
                + salvo.getDataHora().toLocalTime().withSecond(0).withNano(0)
                + (salvo.getLocal() == null ? "." : " — " + salvo.getLocal() + ".")
                + (salvo.getObservacao() == null ? "" : " Lembrete: " + salvo.getObservacao());
        notificarPartes(salvo, tituloNotificacao, mensagem);
        return converter(salvo);
    }

    @Transactional(readOnly = true)
    public List<CompromissoDto> listar(Usuario solicitante, Long idosoId) {
        validarAcesso(solicitante, idosoId);
        return compromissoRepository.findByIdosoIdAndDataHoraGreaterThanEqualOrderByDataHoraAsc(idosoId, LocalDateTime.now(clock))
                .stream().map(CompromissoService::converter).toList();
    }

    @Transactional
    public void excluir(Usuario solicitante, Long compromissoId) {
        Compromisso compromisso = compromissoRepository.findById(compromissoId)
                .orElseThrow(() -> new IllegalArgumentException("Compromisso não encontrado."));
        validarAcesso(solicitante, compromisso.getIdoso().getId());
        compromissoRepository.delete(compromisso);
    }

    private void validarAcesso(Usuario solicitante, Long idosoId) {
        if (idosoId == null) throw new IllegalArgumentException("Idoso não informado.");
        if (solicitante.getPerfil() == Perfil.IDOSO && solicitante.getId().equals(idosoId)) return;
        if (solicitante.getPerfil() == Perfil.FAMILIAR
                && vinculoRepository.existsByFamiliarIdAndIdosoIdAndStatus(solicitante.getId(), idosoId, StatusVinculo.ACEITO)) return;
        throw new SecurityException("Você não tem acesso aos compromissos deste idoso.");
    }

    @Scheduled(fixedRate = 60000)
    @Transactional
    public void enviarLembretesProximos() {
        LocalDateTime agora = LocalDateTime.now(clock);
        List<Compromisso> pendentes = compromissoRepository
                .findByLembreteEnviadoFalseAndDataHoraGreaterThanEqualAndDataHoraLessThanEqual(agora, agora.plusHours(24));
        for (Compromisso compromisso : pendentes) {
            compromisso.setLembreteEnviado(true);
            notificarPartes(compromisso, "Compromisso nas próximas 24 horas",
                    compromisso.getTitulo() + " está marcado para " + compromisso.getDataHora().toLocalDate()
                            + " às " + compromisso.getDataHora().toLocalTime().withSecond(0).withNano(0)
                            + (compromisso.getLocal() == null || compromisso.getLocal().isBlank() ? "." : " — " + compromisso.getLocal() + "."));
        }
    }

    private void notificarPartes(Compromisso compromisso, String titulo, String mensagem) {
        Idoso idoso = compromisso.getIdoso();
        push.notificar(idoso.getId(), titulo, mensagem, "/eventosidoso/eventoidoso.html");
        vinculoRepository.findByIdosoIdAndStatusWithFamiliar(idoso.getId(), StatusVinculo.ACEITO)
                .forEach(v -> push.notificar(v.getFamiliar().getId(), titulo, mensagem, "/compromissofamilia/compromissosfamiliar.html"));
    }

    private void validarDto(CompromissoDto dto) {
        if (dto == null || dto.getIdIdoso() == null || dto.getDataHora() == null
                || dto.getTitulo() == null || dto.getTitulo().isBlank()) {
            throw new IllegalArgumentException("Informe título, idoso, data e horário do compromisso.");
        }
        if (dto.getTitulo().trim().length() > 160) throw new IllegalArgumentException("O título deve ter até 160 caracteres.");
        if (dto.getDataHora().isBefore(LocalDateTime.now(clock))) throw new IllegalArgumentException("A data do compromisso deve ser futura.");
        if (dto.getLocal() != null && dto.getLocal().length() > 240) throw new IllegalArgumentException("O local deve ter até 240 caracteres.");
        if (dto.getCategoria() != null && dto.getCategoria().length() > 32) throw new IllegalArgumentException("A categoria deve ter até 32 caracteres.");
        if (dto.getObservacao() != null && dto.getObservacao().length() > 500) throw new IllegalArgumentException("A observação deve ter até 500 caracteres.");
    }

    private static String limpar(String texto) { return texto == null || texto.isBlank() ? null : texto.trim(); }
    private static CompromissoDto converter(Compromisso c) {
        CompromissoDto dto = new CompromissoDto(c.getId(), c.getTitulo(), c.getDataHora(), c.getLocal(), c.getIdoso().getId());
        dto.setCategoria(c.getCategoria());
        dto.setObservacao(c.getObservacao());
        dto.setCriadoPeloIdoso(c.isCriadoPeloIdoso());
        return dto;
    }
}
