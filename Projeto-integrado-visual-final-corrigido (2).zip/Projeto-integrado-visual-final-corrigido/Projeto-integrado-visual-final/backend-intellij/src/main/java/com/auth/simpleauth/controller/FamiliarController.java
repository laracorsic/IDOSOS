package com.auth.simpleauth.controller;

import com.auth.simpleauth.dto.AtualizarFotoDto;
import com.auth.simpleauth.dto.FamiliarDto;
import com.auth.simpleauth.dto.FamiliarResponseDto;
import com.auth.simpleauth.entity.Familiar;
import com.auth.simpleauth.entity.Usuario;
import com.auth.simpleauth.enums.Perfil;
import com.auth.simpleauth.service.FamiliarService;
import jakarta.servlet.http.HttpSession;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/familiares")
public class FamiliarController {
    private final FamiliarService service;

    public FamiliarController(FamiliarService service) {
        this.service = service;
    }

    @PostMapping
    public ResponseEntity<?> cadastrar(@Valid @RequestBody FamiliarDto dto) {
        return ResponseEntity.status(HttpStatus.FORBIDDEN).body("Crie novas contas pelo fluxo /login/register.");
    }

    @GetMapping
    public ResponseEntity<?> listar(HttpSession session) {
        Usuario usuario = usuarioSessao(session);
        if (!(usuario instanceof Familiar familiar)) return proibido(session);
        return ResponseEntity.ok(List.of(new FamiliarResponseDto(familiar)));
    }

    @GetMapping("/{id}")
    public ResponseEntity<?> buscarPorId(@PathVariable Long id, HttpSession session) {
        if (!ehTitularFamiliar(id, session)) return proibido(session);
        return service.buscarPorId(id).<ResponseEntity<?>>map(f -> ResponseEntity.ok(new FamiliarResponseDto(f)))
                .orElseGet(() -> ResponseEntity.notFound().build());
    }

    @PutMapping("/{id}")
    public ResponseEntity<?> atualizar(@PathVariable Long id, @Valid @RequestBody FamiliarDto dto, HttpSession session) {
        if (!ehTitularFamiliar(id, session)) return proibido(session);
        Familiar atualizado = service.atualizar(id, dto);
        return ResponseEntity.ok(new FamiliarResponseDto(atualizado));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> remover(@PathVariable Long id, HttpSession session) {
        if (!ehTitularFamiliar(id, session)) return proibido(session);
        service.remover(id);
        session.invalidate();
        return ResponseEntity.noContent().build();
    }

    @PatchMapping("/{id}/foto")
    public ResponseEntity<?> atualizarFotoPerfil(@PathVariable Long id, @RequestBody AtualizarFotoDto dto, HttpSession session) {
        if (!ehTitularFamiliar(id, session)) return proibido(session);
        service.atualizarFotoPerfil(id, dto.getImagemUrl());
        return ResponseEntity.ok().build();
    }

    private boolean ehTitularFamiliar(Long id, HttpSession session) {
        Usuario usuario = usuarioSessao(session);
        return usuario instanceof Familiar && usuario.getPerfil() == Perfil.FAMILIAR && id.equals(usuario.getId());
    }

    private Usuario usuarioSessao(HttpSession session) {
        Object usuario = session.getAttribute("usuario");
        return usuario instanceof Usuario u ? u : null;
    }

    private ResponseEntity<?> proibido(HttpSession session) {
        if (usuarioSessao(session) == null) return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Entre na sua conta para continuar.");
        return ResponseEntity.status(HttpStatus.FORBIDDEN).body("Esta operação só é permitida ao titular de uma conta FAMILIAR.");
    }
}
