package com.auth.simpleauth.dto;

import com.auth.simpleauth.entity.Familiar;
import com.auth.simpleauth.entity.Idoso;
import com.auth.simpleauth.entity.Usuario;
import com.auth.simpleauth.enums.Perfil;
import jakarta.validation.constraints.AssertTrue;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;

public class UsuarioCadastroDto {
    @NotBlank(message = "Informe seu nome.")
    @Size(min = 2, max = 100, message = "O nome deve ter entre 2 e 100 caracteres.")
    private String nome;

    @NotBlank(message = "Informe seu e-mail.")
    @Email(message = "Informe um e-mail válido.")
    @Size(max = 254, message = "O e-mail é muito longo.")
    private String email;

    @NotBlank(message = "Crie uma senha.")
    @Size(min = 8, max = 64, message = "A senha deve ter entre 8 e 64 caracteres.")
    @Pattern(regexp = "^(?=.*[A-Za-z])(?=.*\\d).+$", message = "A senha precisa conter pelo menos uma letra e um número.")
    private String senha;

    @NotBlank(message = "Informe seu telefone.")
    @Pattern(regexp = "^[+0-9() .-]{10,20}$", message = "Informe um telefone válido com DDD.")
    private String telefone;

    private String telegramChatId;

    @NotNull(message = "Escolha o tipo de conta: idoso ou familiar.")
    private Perfil perfil;

    private Integer idade;

    public UsuarioCadastroDto() {}

    public UsuarioCadastroDto(String nome, String email, String senha, String telefone, String telegramChatId, Perfil perfil) {
        this(nome, email, senha, telefone, telegramChatId, perfil, null);
    }

    public UsuarioCadastroDto(String nome, String email, String senha, String telefone, String telegramChatId, Perfil perfil, Integer idade) {
        this.nome = nome;
        this.email = email;
        this.senha = senha;
        this.telefone = telefone;
        this.telegramChatId = telegramChatId;
        this.perfil = perfil;
        this.idade = idade;
    }

    @AssertTrue(message = "Informe idade entre 1 e 120 anos para criar uma conta de idoso.")
    public boolean isIdadeValidaParaPerfil() {
        return perfil != Perfil.IDOSO || (idade != null && idade >= 1 && idade <= 120);
    }

    @AssertTrue(message = "Informe um telefone brasileiro válido com DDD (10 ou 11 dígitos).")
    public boolean isTelefoneBrasileiroValido() {
        if (telefone == null || telefone.isBlank()) return true; // @NotBlank apresenta a mensagem principal.
        String digitos = telefone.replaceAll("\\D", "");
        if (digitos.startsWith("55") && (digitos.length() == 12 || digitos.length() == 13)) {
            digitos = digitos.substring(2);
        }
        return digitos.length() == 10 || digitos.length() == 11;
    }

    public Usuario toEntity() {
        if (perfil == Perfil.FAMILIAR) {
            return new Familiar(nome.trim(), email.trim().toLowerCase(), senha, telefone.trim(), telegramChatId);
        }
        if (perfil == Perfil.IDOSO) {
            Idoso idoso = new Idoso(nome.trim(), email.trim().toLowerCase(), senha, telefone.trim(), telegramChatId, null);
            idoso.setIdade(idade);
            return idoso;
        }
        throw new IllegalArgumentException("Tipo de conta inválido.");
    }

    public String getNome() { return nome; }
    public void setNome(String nome) { this.nome = nome; }
    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }
    public String getSenha() { return senha; }
    public void setSenha(String senha) { this.senha = senha; }
    public String getTelefone() { return telefone; }
    public void setTelefone(String telefone) { this.telefone = telefone; }
    public String getTelegramChatId() { return telegramChatId; }
    public void setTelegramChatId(String telegramChatId) { this.telegramChatId = telegramChatId; }
    public Perfil getPerfil() { return perfil; }
    public void setPerfil(Perfil perfil) { this.perfil = perfil; }
    public Integer getIdade() { return idade; }
    public void setIdade(Integer idade) { this.idade = idade; }
}
