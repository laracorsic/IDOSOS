package com.auth.simpleauth.exception;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

@RestControllerAdvice
public class ApiValidationHandler {
    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ResponseEntity<Map<String, Object>> tratarCamposInvalidos(MethodArgumentNotValidException erro) {
        List<String> detalhes = new ArrayList<>();
        for (FieldError campo : erro.getBindingResult().getFieldErrors()) {
            if (!detalhes.contains(campo.getDefaultMessage())) detalhes.add(campo.getDefaultMessage());
        }
        erro.getBindingResult().getGlobalErrors().forEach(global -> {
            if (!detalhes.contains(global.getDefaultMessage())) detalhes.add(global.getDefaultMessage());
        });
        String mensagem = detalhes.isEmpty() ? "Confira os dados informados." : String.join(" ", detalhes);
        Map<String, Object> corpo = new LinkedHashMap<>();
        corpo.put("message", mensagem);
        corpo.put("errors", detalhes);
        return ResponseEntity.badRequest().body(corpo);
    }

    @ExceptionHandler(HttpMessageNotReadableException.class)
    public ResponseEntity<Map<String, String>> tratarJsonInvalido(HttpMessageNotReadableException erro) {
        return ResponseEntity.badRequest().body(Map.of("message", "Os dados enviados estão incompletos ou em formato inválido."));
    }

    @ExceptionHandler(IllegalArgumentException.class)
    public ResponseEntity<Map<String, String>> tratarRegraInvalida(IllegalArgumentException erro) {
        String mensagem = erro.getMessage() == null ? "Confira os dados informados." : erro.getMessage();
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(Map.of("message", mensagem));
    }
}
