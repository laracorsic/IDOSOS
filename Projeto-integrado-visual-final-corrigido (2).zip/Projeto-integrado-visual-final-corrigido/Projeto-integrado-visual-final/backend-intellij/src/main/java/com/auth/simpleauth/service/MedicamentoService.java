package com.auth.simpleauth.service;

import com.auth.simpleauth.dto.MedicamentoDto;
import com.auth.simpleauth.entity.Dose;
import com.auth.simpleauth.entity.Idoso;
import com.auth.simpleauth.entity.Medicamento;
import com.auth.simpleauth.entity.Usuario;
import com.auth.simpleauth.enums.Perfil;
import com.auth.simpleauth.enums.StatusDose;
import com.auth.simpleauth.enums.StatusVinculo;
import com.auth.simpleauth.enums.TipoTratamento;
import com.auth.simpleauth.enums.UnidadeTempoDuracao;
import com.auth.simpleauth.repository.DoseRepository;
import com.auth.simpleauth.repository.IdosoRepository;
import com.auth.simpleauth.repository.MedicamentoRepository;
import com.auth.simpleauth.repository.VinculoFamiliarRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
public class MedicamentoService {

    private final MedicamentoRepository medicamentoRepository;
    private final IdosoRepository idosoRepository;
    private final DoseRepository doseRepository;
    private final DoseSchedulerEngine doseSchedulerEngine;
    private final WebPushNotificationService webPushNotificationService;
    private final VinculoFamiliarRepository vinculoFamiliarRepository;

    public MedicamentoService(MedicamentoRepository medicamentoRepository,
                              IdosoRepository idosoRepository,
                              DoseRepository doseRepository,
                              DoseSchedulerEngine doseSchedulerEngine,
                              WebPushNotificationService webPushNotificationService,
                              VinculoFamiliarRepository vinculoFamiliarRepository) {
        this.medicamentoRepository = medicamentoRepository;
        this.idosoRepository = idosoRepository;
        this.doseRepository = doseRepository;
        this.doseSchedulerEngine = doseSchedulerEngine;
        this.webPushNotificationService = webPushNotificationService;
        this.vinculoFamiliarRepository = vinculoFamiliarRepository;
    }

    @Transactional
    public Medicamento cadastrar(MedicamentoDto dto, Usuario solicitante) {
        validarAcessoFamiliar(solicitante, dto.getIdIdoso());
        Idoso idoso = idosoRepository.findById(dto.getIdIdoso())
                .orElseThrow(() -> new IllegalArgumentException("Idoso não encontrado com ID: " + dto.getIdIdoso()));
        validarDuracao(dto);

        UnidadeTempoDuracao unidadeDuracao = resolverUnidadeDuracao(dto);
        Integer valorDuracao = (dto.getTipoTratamento() == TipoTratamento.CONTINUO) ? null : dto.getValorDuracao();
        LocalDateTime dataFim = calcularDataFimTratamento(dto.getPrimeiroHorario(), dto.getTipoTratamento(), unidadeDuracao, valorDuracao);

        Medicamento medicamento = new Medicamento(
                dto.getNome(),
                dto.getDosagem(),
                dto.getUnidade(),
                dto.getQuantidadePorDose(),
                dto.getPrimeiroHorario(),
                dto.getIntervaloHoras(),
                dto.getCorCaixa(),
                dto.getIdentificadorCaixa(),
                dto.getTipoTratamento(),
                unidadeDuracao,
                valorDuracao,
                dataFim,
                idoso,
                idoso.getFamiliar()
        );

        Medicamento medicamentoSalvo = medicamentoRepository.save(medicamento);
        gerarPrimeiraDose(medicamentoSalvo);
        webPushNotificationService.notificar(
                idoso.getId(), "Novo remédio cadastrado",
                "Seu familiar cadastrou " + medicamentoSalvo.getNome() + ". Confira o horário no Zelo.",
                "/remedioidoso/remedioidoso.html");
        vinculoFamiliarRepository.findByIdosoIdAndStatusWithFamiliar(idoso.getId(), StatusVinculo.ACEITO)
                .forEach(v -> webPushNotificationService.notificar(v.getFamiliar().getId(),
                        "Novo remédio cadastrado", idoso.getNome() + ": " + medicamentoSalvo.getNome()
                                + " foi adicionado à rotina de medicamentos.", "/remediofamiliar/remediosfamiliar.html"));

        return medicamentoSalvo;
    }

    private void gerarPrimeiraDose(Medicamento medicamento) {
        Dose primeiraDose = new Dose(medicamento, medicamento.getPrimeiroHorario());
        Dose doseSalva = doseRepository.save(primeiraDose);
        doseSchedulerEngine.agendarDose(doseSalva);
    }

    public List<Medicamento> listar(Usuario solicitante) {
        if (solicitante == null) throw new SecurityException("Faça login para consultar medicamentos.");
        if (solicitante.getPerfil() == Perfil.IDOSO) return listarPorIdoso(solicitante.getId(), solicitante);
        if (solicitante.getPerfil() == Perfil.FAMILIAR) {
            return vinculoFamiliarRepository.findByFamiliarIdAndStatusWithIdoso(solicitante.getId(), StatusVinculo.ACEITO)
                    .stream().flatMap(v -> medicamentoRepository.findByIdosoIdAndAtivoTrue(v.getIdoso().getId()).stream()).toList();
        }
        throw new SecurityException("Perfil sem acesso a medicamentos.");
    }

    public List<Medicamento> listarPorIdoso(Long idosoId, Usuario solicitante) {
        validarAcessoLeitura(solicitante, idosoId);
        return medicamentoRepository.findByIdosoIdAndAtivoTrue(idosoId);
    }

    public Optional<Medicamento> buscarPorId(Long id, Usuario solicitante) {
        Optional<Medicamento> resultado = medicamentoRepository.findById(id);
        resultado.ifPresent(m -> validarAcessoLeitura(solicitante, m.getIdoso().getId()));
        return resultado;
    }

    @Transactional
    public Medicamento atualizar(Long id, MedicamentoDto dto, Usuario solicitante) {
        Medicamento medicamento = medicamentoRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Medicamento não encontrado com ID: " + id));
        validarAcessoFamiliar(solicitante, medicamento.getIdoso().getId());
        if (dto.getIdIdoso() != null && !dto.getIdIdoso().equals(medicamento.getIdoso().getId())) {
            throw new IllegalArgumentException("Não é permitido transferir um medicamento para outro idoso.");
        }
        validarDuracao(dto);

        boolean horarioOuIntervaloMudou = !medicamento.getPrimeiroHorario().equals(dto.getPrimeiroHorario()) ||
                !medicamento.getIntervaloHoras().equals(dto.getIntervaloHoras());

        medicamento.setNome(dto.getNome());
        medicamento.setDosagem(dto.getDosagem());
        medicamento.setUnidade(dto.getUnidade());
        medicamento.setQuantidadePorDose(dto.getQuantidadePorDose());
        medicamento.setPrimeiroHorario(dto.getPrimeiroHorario());
        medicamento.setIntervaloHoras(dto.getIntervaloHoras());
        medicamento.setCorCaixa(dto.getCorCaixa());
        medicamento.setIdentificadorCaixa(dto.getIdentificadorCaixa());

        UnidadeTempoDuracao unidadeDuracao = resolverUnidadeDuracao(dto);
        Integer valorDuracao = (dto.getTipoTratamento() == TipoTratamento.CONTINUO) ? null : dto.getValorDuracao();
        LocalDateTime dataFim = calcularDataFimTratamento(dto.getPrimeiroHorario(), dto.getTipoTratamento(), unidadeDuracao, valorDuracao);

        medicamento.setTipoTratamento(dto.getTipoTratamento());
        medicamento.setUnidadeDuracao(unidadeDuracao);
        medicamento.setValorDuracao(valorDuracao);
        medicamento.setDataFimTratamento(dataFim);

        if (dto.getIdIdoso() != null) {
            Idoso idoso = idosoRepository.findById(dto.getIdIdoso())
                    .orElseThrow(() -> new IllegalArgumentException("Idoso não encontrado com ID: " + dto.getIdIdoso()));
            medicamento.setIdoso(idoso);
            medicamento.setFamiliar(idoso.getFamiliar());
        }

        Medicamento medicamentoAtualizado = medicamentoRepository.save(medicamento);

        // Se mudou o cronograma, cancela doses pendentes e re-agenda a partir do novo primeiro horário
        if (horarioOuIntervaloMudou) {
            cancelarDosesPendentesDoMedicamento(id);
            gerarPrimeiraDose(medicamentoAtualizado);
        }

        return medicamentoAtualizado;
    }

    @Transactional
    public void desativar(Long id, Usuario solicitante) {
        Medicamento medicamento = medicamentoRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Medicamento não encontrado com ID: " + id));
        validarAcessoFamiliar(solicitante, medicamento.getIdoso().getId());

        medicamento.setAtivo(false);
        medicamentoRepository.save(medicamento);

        cancelarDosesPendentesDoMedicamento(id);
    }

    private void cancelarDosesPendentesDoMedicamento(Long medicamentoId) {
        List<Dose> doses = doseRepository.findByMedicamentoId(medicamentoId);
        for (Dose dose : doses) {
            if (dose.getStatus() == StatusDose.PENDENTE || dose.getStatus() == StatusDose.NOTIFICADO) {
                dose.setStatus(StatusDose.CANCELADO);
                dose.setProximaNotificacao(null);
                doseRepository.save(dose);
            }
        }
    }

    private UnidadeTempoDuracao resolverUnidadeDuracao(MedicamentoDto dto) {
        if (dto.getTipoTratamento() == TipoTratamento.CONTINUO) {
            return UnidadeTempoDuracao.ILIMITADO;
        }
        return dto.getUnidadeDuracao();
    }

    private void validarDuracao(MedicamentoDto dto) {
        if (dto.getTipoTratamento() == null) throw new IllegalArgumentException("Informe o tipo do tratamento.");
        if (dto.getTipoTratamento() == TipoTratamento.TEMPORARIO
                && (dto.getValorDuracao() == null || dto.getValorDuracao() < 1
                || dto.getUnidadeDuracao() == null || dto.getUnidadeDuracao() == UnidadeTempoDuracao.ILIMITADO)) {
            throw new IllegalArgumentException("Para tratamento temporário, informe duração válida em dias, meses ou anos.");
        }
    }

    private void validarAcessoLeitura(Usuario solicitante, Long idosoId) {
        if (solicitante == null) throw new SecurityException("Faça login para consultar medicamentos.");
        if (solicitante.getPerfil() == Perfil.IDOSO && solicitante.getId().equals(idosoId)) return;
        if (solicitante.getPerfil() == Perfil.FAMILIAR
                && vinculoFamiliarRepository.existsByFamiliarIdAndIdosoIdAndStatus(
                        solicitante.getId(), idosoId, StatusVinculo.ACEITO)) return;
        throw new SecurityException("Você não tem vínculo aprovado com este idoso.");
    }

    private void validarAcessoFamiliar(Usuario solicitante, Long idosoId) {
        if (solicitante == null || solicitante.getPerfil() != Perfil.FAMILIAR) {
            throw new SecurityException("Somente um familiar pode alterar medicamentos.");
        }
        validarAcessoLeitura(solicitante, idosoId);
    }

    private LocalDateTime calcularDataFimTratamento(LocalDateTime inicio, TipoTratamento tipo, UnidadeTempoDuracao unidade, Integer valor) {
        if (tipo == TipoTratamento.CONTINUO || unidade == UnidadeTempoDuracao.ILIMITADO || valor == null || inicio == null) {
            return null;
        }

        return switch (unidade) {
            case DIAS -> inicio.plusDays(valor);
            case MESES -> inicio.plusMonths(valor);
            case ANOS -> inicio.plusYears(valor);
            default -> null;
        };
    }
}
