package com.auth.simpleauth.service;

import com.auth.simpleauth.config.TestableClock;
import com.auth.simpleauth.dto.NotificacaoDto;
import com.auth.simpleauth.entity.Notificacao;
import com.auth.simpleauth.repository.NotificacaoRepository;
import com.auth.simpleauth.repository.UsuarioRepository;
import org.springframework.data.domain.PageRequest;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class NotificacaoService {
    private final NotificacaoRepository notificacaoRepository;
    private final UsuarioRepository usuarioRepository;
    private final TestableClock clock;

    public NotificacaoService(NotificacaoRepository notificacaoRepository,
                              UsuarioRepository usuarioRepository,
                              TestableClock clock) {
        this.notificacaoRepository = notificacaoRepository;
        this.usuarioRepository = usuarioRepository;
        this.clock = clock;
    }

    @Transactional
    public void registrar(Long usuarioId, String titulo, String mensagem, String url) {
        if (usuarioId == null) return;
        usuarioRepository.findById(usuarioId).ifPresent(usuario -> notificacaoRepository.save(
                new Notificacao(usuario, limitar(titulo, 120), limitar(mensagem, 1200), limitar(url, 400), LocalDateTime.now(clock))));
    }

    @Transactional(readOnly = true)
    public List<NotificacaoDto> listar(Long usuarioId) {
        return notificacaoRepository.findByUsuarioIdOrderByCriadaEmDesc(usuarioId, PageRequest.of(0, 50))
                .stream().map(NotificacaoDto::de).toList();
    }

    @Transactional
    public void limpar(Long usuarioId) {
        notificacaoRepository.excluirTodasDoUsuario(usuarioId);
    }

    @Scheduled(cron = "0 15 4 * * *")
    @Transactional
    public void expurgarAntigas() {
        notificacaoRepository.excluirAntigas(LocalDateTime.now(clock).minusDays(90));
    }

    private static String limitar(String valor, int maximo) {
        if (valor == null || valor.isBlank()) return "";
        String texto = valor.trim();
        return texto.length() <= maximo ? texto : texto.substring(0, maximo);
    }
}
