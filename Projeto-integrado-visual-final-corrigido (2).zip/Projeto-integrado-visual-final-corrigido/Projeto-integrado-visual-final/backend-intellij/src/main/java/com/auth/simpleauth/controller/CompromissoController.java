package com.auth.simpleauth.controller;

import com.auth.simpleauth.dto.CompromissoDto;
import com.auth.simpleauth.entity.Usuario;
import com.auth.simpleauth.service.CompromissoService;
import jakarta.servlet.http.HttpSession;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/compromissos")
public class CompromissoController {
    private final CompromissoService service;
    public CompromissoController(CompromissoService service) { this.service = service; }

    @PostMapping
    public ResponseEntity<CompromissoDto> criar(@RequestBody CompromissoDto dto, HttpSession session) {
        return ResponseEntity.status(HttpStatus.CREATED).body(service.criar(usuario(session), dto));
    }

    @GetMapping("/idoso/{idosoId}")
    public List<CompromissoDto> listar(@PathVariable Long idosoId, HttpSession session) {
        return service.listar(usuario(session), idosoId);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> excluir(@PathVariable Long id, HttpSession session) {
        service.excluir(usuario(session), id);
        return ResponseEntity.noContent().build();
    }

    private static Usuario usuario(HttpSession session) {
        Object usuario = session.getAttribute("usuario");
        if (usuario instanceof Usuario u) return u;
        throw new SecurityException("Sessão inválida. Entre novamente.");
    }
}
