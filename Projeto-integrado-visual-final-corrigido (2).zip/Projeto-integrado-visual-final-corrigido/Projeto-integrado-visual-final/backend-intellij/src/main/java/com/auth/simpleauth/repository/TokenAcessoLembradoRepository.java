package com.auth.simpleauth.repository;

import com.auth.simpleauth.entity.TokenAcessoLembrado;
import org.springframework.data.jpa.repository.JpaRepository;
import java.time.Instant;
import java.util.Optional;

public interface TokenAcessoLembradoRepository extends JpaRepository<TokenAcessoLembrado, Long> {
    Optional<TokenAcessoLembrado> findByTokenHashAndExpiraEmAfter(String tokenHash, Instant agora);
    void deleteByTokenHash(String tokenHash);
    void deleteByUsuarioId(Long usuarioId);
    long deleteByExpiraEmBefore(Instant instante);
}
