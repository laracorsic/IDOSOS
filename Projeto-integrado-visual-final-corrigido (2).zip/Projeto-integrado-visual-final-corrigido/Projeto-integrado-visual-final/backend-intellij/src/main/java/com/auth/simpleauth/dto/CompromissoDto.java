package com.auth.simpleauth.dto;

import java.time.LocalDateTime;

public class CompromissoDto {
    private Long id;
    private String titulo;
    private LocalDateTime dataHora;
    private String local;
    private Long idIdoso;
    private String categoria;
    private String observacao;
    private boolean criadoPeloIdoso;

    public CompromissoDto() {}
    public CompromissoDto(Long id, String titulo, LocalDateTime dataHora, String local, Long idIdoso) {
        this.id = id;
        this.titulo = titulo;
        this.dataHora = dataHora;
        this.local = local;
        this.idIdoso = idIdoso;
    }
    public Long getId() { return id; }
    public String getTitulo() { return titulo; }
    public void setTitulo(String titulo) { this.titulo = titulo; }
    public LocalDateTime getDataHora() { return dataHora; }
    public void setDataHora(LocalDateTime dataHora) { this.dataHora = dataHora; }
    public String getLocal() { return local; }
    public void setLocal(String local) { this.local = local; }
    public Long getIdIdoso() { return idIdoso; }
    public void setIdIdoso(Long idIdoso) { this.idIdoso = idIdoso; }
    public String getCategoria() { return categoria; }
    public void setCategoria(String categoria) { this.categoria = categoria; }
    public String getObservacao() { return observacao; }
    public void setObservacao(String observacao) { this.observacao = observacao; }
    public boolean isCriadoPeloIdoso() { return criadoPeloIdoso; }
    public void setCriadoPeloIdoso(boolean criadoPeloIdoso) { this.criadoPeloIdoso = criadoPeloIdoso; }
}
