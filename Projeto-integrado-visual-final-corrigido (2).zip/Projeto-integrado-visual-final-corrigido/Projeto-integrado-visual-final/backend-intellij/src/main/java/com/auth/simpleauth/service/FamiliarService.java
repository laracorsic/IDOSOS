package com.auth.simpleauth.service;

import com.auth.simpleauth.dto.FamiliarDto;
import com.auth.simpleauth.entity.Familiar;
import com.auth.simpleauth.repository.FamiliarRepository;
import com.auth.simpleauth.repository.TokenAcessoLembradoRepository;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.Optional;

@Service
public class FamiliarService {
    private final FamiliarRepository repository;
    private final TokenAcessoLembradoRepository tokenRepository;
    private final PasswordEncoder passwordEncoder;

    public FamiliarService(FamiliarRepository repository, TokenAcessoLembradoRepository tokenRepository, PasswordEncoder passwordEncoder) {
        this.repository = repository;
        this.tokenRepository = tokenRepository;
        this.passwordEncoder = passwordEncoder;
    }

    @Transactional
    public Familiar cadastrar(FamiliarDto dto) {
        String email = dto.getEmail().trim().toLowerCase();
        if (repository.findByEmailIgnoreCase(email).isPresent()) throw new IllegalArgumentException("Este e-mail já está cadastrado.");
        validarTamanhoSenha(dto.getSenha());
        Familiar familiar = dto.toEntity();
        familiar.setEmail(email);
        familiar.setSenha(passwordEncoder.encode(dto.getSenha()));
        return repository.save(familiar);
    }

    @Transactional(readOnly = true)
    public List<Familiar> listar() { return repository.findAll(); }

    @Transactional(readOnly = true)
    public Optional<Familiar> buscarPorId(Long id) { return repository.findById(id); }

    @Transactional
    public Familiar atualizar(Long id, FamiliarDto dto) {
        Familiar familiar = repository.findById(id).orElseThrow(() -> new RuntimeException("Familiar não encontrado com ID: " + id));
        familiar.setNome(dto.getNome().trim());
        familiar.setTelefone(dto.getTelefone().trim());
        if (dto.getEmail() != null && !dto.getEmail().isBlank()) {
            String email = dto.getEmail().trim().toLowerCase();
            repository.findByEmailIgnoreCase(email).ifPresent(outro -> {
                if (!outro.getId().equals(id)) throw new IllegalArgumentException("Este e-mail já está em uso.");
            });
            familiar.setEmail(email);
        }
        if (dto.getSenha() != null && !dto.getSenha().isBlank()) {
            validarTamanhoSenha(dto.getSenha());
            familiar.setSenha(passwordEncoder.encode(dto.getSenha()));
            tokenRepository.deleteByUsuarioId(id);
        }
        if (dto.getTelegramChatId() != null) familiar.setTelegramChatId(dto.getTelegramChatId());
        return repository.save(familiar);
    }

    @Transactional
    public void remover(Long id) {
        if (!repository.existsById(id)) throw new RuntimeException("Familiar não encontrado com ID: " + id);
        tokenRepository.deleteByUsuarioId(id);
        repository.deleteById(id);
    }

    @Transactional
    public void atualizarFotoPerfil(Long id, String imagemUrl) {
        Familiar familiar = repository.findById(id).orElseThrow(() -> new RuntimeException("Familiar não encontrado com ID: " + id));
        familiar.setImagemUrl(imagemUrl);
        repository.save(familiar);
    }

    private void validarTamanhoSenha(String senha) {
        if (senha == null || senha.getBytes(StandardCharsets.UTF_8).length > 72) {
            throw new IllegalArgumentException("A senha é longa demais. Use até 72 bytes em UTF-8.");
        }
    }
}
