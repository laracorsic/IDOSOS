package com.auth.simpleauth.entity;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "tbl_chat_mensagem", indexes = {
        @Index(name = "idx_chat_par_id_data", columnList = "idoso_id, familiar_id, enviada_em")
})
public class ChatMensagem {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "idoso_id", nullable = false)
    private Idoso idoso;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "familiar_id", nullable = false)
    private Familiar familiar;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "remetente_id", nullable = false)
    private Usuario remetente;

    @Column(nullable = false, length = 2000)
    private String texto;

    @Column(name = "enviada_em", nullable = false)
    private LocalDateTime enviadaEm;

    public ChatMensagem() {}
    public ChatMensagem(Idoso idoso, Familiar familiar, Usuario remetente, String texto, LocalDateTime enviadaEm) {
        this.idoso = idoso; this.familiar = familiar; this.remetente = remetente;
        this.texto = texto; this.enviadaEm = enviadaEm;
    }
    public Long getId() { return id; }
    public Idoso getIdoso() { return idoso; }
    public Familiar getFamiliar() { return familiar; }
    public Usuario getRemetente() { return remetente; }
    public String getTexto() { return texto; }
    public LocalDateTime getEnviadaEm() { return enviadaEm; }
}
