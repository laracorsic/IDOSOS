package com.auth.simpleauth.controller;

import com.auth.simpleauth.dto.*;
import com.auth.simpleauth.entity.Usuario;
import com.auth.simpleauth.enums.Perfil;
import com.auth.simpleauth.enums.StatusVinculo;
import com.auth.simpleauth.repository.VinculoFamiliarRepository;
import com.auth.simpleauth.service.AcessoLembradoService;
import com.auth.simpleauth.service.UsuarioService;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;
import java.util.Base64;

@RestController
@RequestMapping("/usuarios")
public class UsuarioController {
    private final UsuarioService usuarioService;
    private final VinculoFamiliarRepository vinculoRepository;
    private final AcessoLembradoService acessoLembradoService;

    public UsuarioController(UsuarioService usuarioService, VinculoFamiliarRepository vinculoRepository, AcessoLembradoService acessoLembradoService) {
        this.usuarioService = usuarioService;
        this.vinculoRepository = vinculoRepository;
        this.acessoLembradoService = acessoLembradoService;
    }

    @GetMapping("/{id}")
    public ResponseEntity<?> buscarUsuario(@PathVariable Long id, HttpSession session) {
        Usuario solicitante = usuarioSessao(session);
        if (solicitante == null) return naoAutorizado();
        if (!podeLerPerfil(solicitante, id)) return proibido("Você não tem permissão para consultar esse perfil.");
        return usuarioService.buscarPorId(id)
                .map(usuario -> ResponseEntity.ok(new UsuarioPerfilDto(usuario.getId(), usuario.getNome(), usuario.getEmail(), usuario.getTelefone(), usuario.getPerfil(), usuario.getImagemUrl())))
                .orElse(ResponseEntity.notFound().build());
    }

    @GetMapping("/{id}/status-telegram")
    public ResponseEntity<?> checarStatusTelegram(@PathVariable Long id, HttpSession session) {
        Usuario solicitante = usuarioSessao(session);
        if (solicitante == null) return naoAutorizado();
        if (!podeLerPerfil(solicitante, id)) return proibido("Você não tem permissão para consultar esse perfil.");
        return usuarioService.buscarPorId(id).map(usuario -> {
            boolean conectado = usuario.getTelegramChatId() != null && !usuario.getTelegramChatId().isBlank()
                    && usuario.getPerfil() == Perfil.FAMILIAR;
            if (usuario.getPerfil() == Perfil.IDOSO) {
                conectado = usuario.getTelegramChatId() != null && !usuario.getTelegramChatId().isBlank()
                        && usuario instanceof com.auth.simpleauth.entity.Idoso idoso && idoso.isTodosBotsConectados();
            }
            if (usuario.getPerfil() == Perfil.FAMILIAR && usuario instanceof com.auth.simpleauth.entity.Familiar familiar) {
                conectado = usuario.getTelegramChatId() != null && !usuario.getTelegramChatId().isBlank() && familiar.isBotMedicamentosConectado();
            }
            return ResponseEntity.ok(Map.of("telegramConectado", conectado, "tipo", usuario.getPerfil().name()));
        }).orElse(ResponseEntity.notFound().build());
    }

    @PutMapping("/{id}/nome")
    public ResponseEntity<?> atualizarNome(@PathVariable Long id, @Valid @RequestBody AtualizarNomeDto dto, HttpSession session) {
        if (!ehTitular(id, session)) return respostaSemAcesso(session);
        Usuario usuario = usuarioService.atualizarNome(id, dto.getNome());
        return ResponseEntity.ok(perfil(usuario));
    }

    @PutMapping("/{id}/email")
    public ResponseEntity<?> atualizarEmail(@PathVariable Long id, @Valid @RequestBody AtualizarEmailDto dto, HttpSession session) {
        if (!ehTitular(id, session)) return respostaSemAcesso(session);
        Usuario usuario = usuarioService.atualizarEmail(id, dto.getEmail());
        return ResponseEntity.ok(perfil(usuario));
    }

    @PutMapping("/{id}/telefone")
    public ResponseEntity<?> atualizarTelefone(@PathVariable Long id, @Valid @RequestBody AtualizarTelefoneDto dto, HttpSession session) {
        if (!ehTitular(id, session)) return respostaSemAcesso(session);
        Usuario usuario = usuarioService.atualizarTelefone(id, dto.getTelefone());
        return ResponseEntity.ok(perfil(usuario));
    }

    @PutMapping("/{id}/senha")
    public ResponseEntity<?> atualizarSenha(@PathVariable Long id, @Valid @RequestBody AtualizarSenhaDto dto, HttpSession session,
                                             HttpServletRequest request, HttpServletResponse response) {
        if (!ehTitular(id, session)) return respostaSemAcesso(session);
        boolean manterConectado = acessoLembradoService.temCookieLembrado(request);
        usuarioService.atualizarSenha(id, dto.getSenhaAtual(), dto.getNovaSenha());
        Usuario usuarioAtualizado = usuarioService.buscarPorId(id).orElseThrow();
        acessoLembradoService.revogarTodosDoUsuario(id);
        acessoLembradoService.prepararLogin(usuarioAtualizado, manterConectado, request, response);
        return ResponseEntity.ok(Map.of("message", "Senha alterada com sucesso."));
    }

    @PutMapping("/{id}/foto")
    public ResponseEntity<?> atualizarFoto(@PathVariable Long id, @Valid @RequestBody AtualizarFotoDto dto, HttpSession session) {
        if (!ehTitular(id, session)) return respostaSemAcesso(session);
        validarFoto(dto.getImagemUrl());
        Usuario usuario = usuarioService.atualizarFoto(id, dto.getImagemUrl());
        return ResponseEntity.ok(perfil(usuario));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> excluirConta(@PathVariable Long id, @Valid @RequestBody ConfirmarSenhaDto dto, HttpSession session) {
        if (!ehTitular(id, session)) return respostaSemAcesso(session);
        usuarioService.confirmarSenhaAtual(id, dto.getSenha());
        usuarioService.deletarPorId(id);
        session.invalidate();
        return ResponseEntity.ok(Map.of("message", "Conta excluída com sucesso."));
    }

    @DeleteMapping("/{id}/acessos-lembrados")
    public ResponseEntity<?> revogarAcessosLembrados(@PathVariable Long id, HttpSession session,
                                                      HttpServletRequest request, HttpServletResponse response) {
        if (!ehTitular(id, session)) return respostaSemAcesso(session);
        acessoLembradoService.revogarTodosDoUsuario(id);
        acessoLembradoService.revogarAcessoAtual(request, response);
        session.invalidate();
        return ResponseEntity.ok(Map.of("message", "Acessos lembrados revogados. Entre novamente quando quiser."));
    }

    private void validarFoto(String imagem) {
        if (imagem == null || imagem.isBlank()) return;
        if (!imagem.startsWith("data:image/jpeg;base64,")) {
            throw new IllegalArgumentException("A foto deve ser uma imagem JPEG enviada pelo seletor de arquivos.");
        }
        try {
            byte[] bytes = Base64.getDecoder().decode(imagem.substring("data:image/jpeg;base64,".length()));
            if (bytes.length > 300_000) throw new IllegalArgumentException("A foto deve ter até 300 KB.");
            if (bytes.length < 3 || (bytes[0] & 0xff) != 0xff || (bytes[1] & 0xff) != 0xd8 || (bytes[2] & 0xff) != 0xff) {
                throw new IllegalArgumentException("O arquivo selecionado não é um JPEG válido.");
            }
        } catch (IllegalArgumentException erro) {
            throw new IllegalArgumentException("A foto deve ser um JPEG válido de até 300 KB.");
        }
    }

    private UsuarioPerfilDto perfil(Usuario usuario) {
        return new UsuarioPerfilDto(usuario.getId(), usuario.getNome(), usuario.getEmail(), usuario.getTelefone(), usuario.getPerfil(), usuario.getImagemUrl());
    }

    private Usuario usuarioSessao(HttpSession session) {
        Object usuario = session.getAttribute("usuario");
        return usuario instanceof Usuario u ? u : null;
    }

    private boolean ehTitular(Long id, HttpSession session) {
        Usuario usuario = usuarioSessao(session);
        return usuario != null && usuario.getId() != null && usuario.getId().equals(id);
    }

    private boolean podeLerPerfil(Usuario solicitante, Long idAlvo) {
        if (solicitante.getId() != null && solicitante.getId().equals(idAlvo)) return true;
        if (solicitante.getPerfil() != Perfil.FAMILIAR) return false;
        return usuarioService.buscarPorId(idAlvo)
                .filter(alvo -> alvo.getPerfil() == Perfil.IDOSO)
                .map(alvo -> vinculoRepository.existsByFamiliarIdAndIdosoIdAndStatus(solicitante.getId(), idAlvo, StatusVinculo.ACEITO))
                .orElse(false);
    }

    private ResponseEntity<?> respostaSemAcesso(HttpSession session) {
        if (usuarioSessao(session) == null) return naoAutorizado();
        return proibido("Você só pode alterar ou excluir a própria conta.");
    }

    private ResponseEntity<?> naoAutorizado() {
        return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(Map.of("message", "Entre na sua conta para continuar."));
    }

    private ResponseEntity<?> proibido(String mensagem) {
        return ResponseEntity.status(HttpStatus.FORBIDDEN).body(Map.of("message", mensagem));
    }
}
