package com.auth.simpleauth.service;

import com.auth.simpleauth.dto.IdosoDto;
import com.auth.simpleauth.entity.Familiar;
import com.auth.simpleauth.entity.Idoso;
import com.auth.simpleauth.repository.FamiliarRepository;
import com.auth.simpleauth.repository.IdosoRepository;
import com.auth.simpleauth.repository.TokenAcessoLembradoRepository;
import com.auth.simpleauth.repository.UsuarioRepository;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.Optional;

@Service
public class IdosoService {
    private final IdosoRepository idosoRepository;
    private final FamiliarRepository familiarRepository;
    private final UsuarioRepository usuarioRepository;
    private final TokenAcessoLembradoRepository tokenRepository;
    private final PasswordEncoder passwordEncoder;

    public IdosoService(IdosoRepository idosoRepository, FamiliarRepository familiarRepository,
                        UsuarioRepository usuarioRepository, TokenAcessoLembradoRepository tokenRepository,
                        PasswordEncoder passwordEncoder) {
        this.idosoRepository = idosoRepository;
        this.familiarRepository = familiarRepository;
        this.usuarioRepository = usuarioRepository;
        this.tokenRepository = tokenRepository;
        this.passwordEncoder = passwordEncoder;
    }

    @Transactional
    public Idoso cadastrar(IdosoDto dto) {
        String email = dto.getEmail().trim().toLowerCase();
        if (usuarioRepository.findByEmailIgnoreCase(email).isPresent()) throw new IllegalArgumentException("Este e-mail já está cadastrado.");
        validarTamanhoSenha(dto.getSenha());
        Familiar familiar = dto.getIdFamiliar() == null ? null : familiarRepository.findById(dto.getIdFamiliar())
                .orElseThrow(() -> new RuntimeException("Familiar não encontrado com ID: " + dto.getIdFamiliar()));
        Idoso novoIdoso = dto.toEntity(familiar);
        novoIdoso.setEmail(email);
        novoIdoso.setSenha(passwordEncoder.encode(dto.getSenha()));
        return idosoRepository.save(novoIdoso);
    }

    @Transactional(readOnly = true)
    public List<Idoso> listar() { return idosoRepository.findAll(); }

    @Transactional(readOnly = true)
    public Optional<Idoso> buscarPorId(Long id) { return idosoRepository.findById(id); }

    @Transactional
    public Idoso atualizar(Long id, IdosoDto dto) {
        Idoso idoso = idosoRepository.findById(id).orElseThrow(() -> new RuntimeException("Idoso não encontrado com ID: " + id));
        if (dto.getNome() != null) idoso.setNome(dto.getNome().trim());
        if (dto.getTelefone() != null) idoso.setTelefone(dto.getTelefone().trim());
        if (dto.getTelegramChatId() != null) idoso.setTelegramChatId(dto.getTelegramChatId());
        if (dto.getEmail() != null && !dto.getEmail().isBlank()) {
            String email = dto.getEmail().trim().toLowerCase();
            usuarioRepository.findByEmailIgnoreCase(email).ifPresent(outro -> {
                if (!outro.getId().equals(id)) throw new IllegalArgumentException("Este e-mail já está em uso.");
            });
            idoso.setEmail(email);
        }
        if (dto.getSenha() != null && !dto.getSenha().isBlank()) {
            validarTamanhoSenha(dto.getSenha());
            idoso.setSenha(passwordEncoder.encode(dto.getSenha()));
            tokenRepository.deleteByUsuarioId(id);
        }
        if (dto.getIdade() != null) idoso.setIdade(dto.getIdade());
        if (dto.getIdFamiliar() != null) {
            Familiar familiar = familiarRepository.findById(dto.getIdFamiliar())
                    .orElseThrow(() -> new RuntimeException("Familiar não encontrado com ID: " + dto.getIdFamiliar()));
            idoso.setFamiliar(familiar);
        }
        return idosoRepository.save(idoso);
    }

    @Transactional
    public void remover(Long id) {
        if (!idosoRepository.existsById(id)) throw new RuntimeException("Idoso não encontrado com ID: " + id);
        tokenRepository.deleteByUsuarioId(id);
        idosoRepository.deleteById(id);
    }

    private void validarTamanhoSenha(String senha) {
        if (senha == null || senha.getBytes(StandardCharsets.UTF_8).length > 72) {
            throw new IllegalArgumentException("A senha é longa demais. Use até 72 bytes em UTF-8.");
        }
    }
}
