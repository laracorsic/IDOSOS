package com.auth.simpleauth.repository;

import com.auth.simpleauth.entity.ChatMensagem;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface ChatMensagemRepository extends JpaRepository<ChatMensagem, Long> {
    List<ChatMensagem> findByIdosoIdAndFamiliarIdOrderByEnviadaEmAsc(Long idosoId, Long familiarId, PageRequest page);
    List<ChatMensagem> findTop1ByIdosoIdAndFamiliarIdOrderByEnviadaEmDesc(Long idosoId, Long familiarId);
}
