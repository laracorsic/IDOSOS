package com.auth.simpleauth.entity;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "tbl_notificacao", indexes = {
        @Index(name = "idx_notificacao_usuario_criada", columnList = "usuario_id, criada_em")
})
public class Notificacao {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "usuario_id", nullable = false)
    private Usuario usuario;

    @Column(nullable = false, length = 120)
    private String titulo;

    @Column(nullable = false, length = 1200)
    private String mensagem;

    @Column(length = 400)
    private String url;

    @Column(name = "criada_em", nullable = false)
    private LocalDateTime criadaEm;

    @Column(nullable = false)
    private boolean lida = false;

    public Notificacao() {}

    public Notificacao(Usuario usuario, String titulo, String mensagem, String url, LocalDateTime criadaEm) {
        this.usuario = usuario;
        this.titulo = titulo;
        this.mensagem = mensagem;
        this.url = url;
        this.criadaEm = criadaEm;
    }

    @PrePersist
    void aoCriar() {
        if (criadaEm == null) criadaEm = LocalDateTime.now();
    }

    public Long getId() { return id; }
    public Usuario getUsuario() { return usuario; }
    public String getTitulo() { return titulo; }
    public String getMensagem() { return mensagem; }
    public String getUrl() { return url; }
    public LocalDateTime getCriadaEm() { return criadaEm; }
    public boolean isLida() { return lida; }
    public void setLida(boolean lida) { this.lida = lida; }
}
