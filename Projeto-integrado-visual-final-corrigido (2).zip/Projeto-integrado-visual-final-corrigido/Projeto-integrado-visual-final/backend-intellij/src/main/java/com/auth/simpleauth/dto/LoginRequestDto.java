package com.auth.simpleauth.dto;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

public class LoginRequestDto {
    @NotBlank(message = "Informe seu e-mail.")
    @Email(message = "Informe um e-mail válido.")
    @Size(max = 254, message = "O e-mail é muito longo.")
    private String email;

    @NotBlank(message = "Informe sua senha.")
    @Size(max = 128, message = "A senha informada é inválida.")
    private String senha;

    private boolean lembrarMe = false;

    public LoginRequestDto() {}
    public LoginRequestDto(String email, String senha) {
        this.email = email;
        this.senha = senha;
    }

    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }
    public String getSenha() { return senha; }
    public void setSenha(String senha) { this.senha = senha; }
    public boolean isLembrarMe() { return lembrarMe; }
    public void setLembrarMe(boolean lembrarMe) { this.lembrarMe = lembrarMe; }
}
