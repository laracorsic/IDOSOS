package com.auth.simpleauth.service;

import com.auth.simpleauth.entity.TokenAcessoLembrado;
import com.auth.simpleauth.entity.Usuario;
import com.auth.simpleauth.repository.TokenAcessoLembradoRepository;
import com.auth.simpleauth.repository.UsuarioRepository;
import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseCookie;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.time.Duration;
import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.Base64;
import java.util.HexFormat;
import java.util.Optional;

@Service
public class AcessoLembradoService {
    public static final String COOKIE_NAME = "ZELO_REMEMBER";
    private static final long DURACAO_DIAS = 365;
    private static final long RENOVAR_SE_RESTANTAM_DIAS = 180;
    private static final SecureRandom RANDOM = new SecureRandom();

    private final TokenAcessoLembradoRepository tokenRepository;
    private final UsuarioRepository usuarioRepository;
    private final boolean cookieSecure;
    private final String sameSite;

    public AcessoLembradoService(TokenAcessoLembradoRepository tokenRepository,
                                 UsuarioRepository usuarioRepository,
                                 @Value("${server.servlet.session.cookie.secure:true}") boolean cookieSecure,
                                 @Value("${server.servlet.session.cookie.same-site:None}") String sameSite) {
        this.tokenRepository = tokenRepository;
        this.usuarioRepository = usuarioRepository;
        this.cookieSecure = cookieSecure;
        this.sameSite = sameSite;
    }

    @Transactional
    public void prepararLogin(Usuario usuario, boolean lembrar, HttpServletRequest request, HttpServletResponse response) {
        revogarCookieAtual(request);
        if (!lembrar) {
            limparCookie(response);
            return;
        }

        byte[] bytes = new byte[32];
        RANDOM.nextBytes(bytes);
        String tokenSecreto = Base64.getUrlEncoder().withoutPadding().encodeToString(bytes);
        Instant agora = Instant.now();
        tokenRepository.save(new TokenAcessoLembrado(
                usuario.getId(), hash(tokenSecreto), agora, agora.plus(DURACAO_DIAS, ChronoUnit.DAYS)));
        gravarCookie(response, tokenSecreto, Duration.ofDays(DURACAO_DIAS));
    }

    /** Restaura a sessão sem guardar a senha no navegador nem depender do processo em memória. */
    @Transactional
    public boolean restaurarSessao(HttpServletRequest request, HttpServletResponse response) {
        String token = lerCookie(request);
        if (token == null || token.isBlank()) return false;

        Optional<TokenAcessoLembrado> opcional = tokenRepository.findByTokenHashAndExpiraEmAfter(hash(token), Instant.now());
        if (opcional.isEmpty()) {
            limparCookie(response);
            return false;
        }

        TokenAcessoLembrado registro = opcional.get();
        Optional<Usuario> usuario = usuarioRepository.findById(registro.getUsuarioId());
        if (usuario.isEmpty()) {
            tokenRepository.delete(registro);
            limparCookie(response);
            return false;
        }

        Instant agora = Instant.now();
        if (registro.getExpiraEm().isBefore(agora.plus(RENOVAR_SE_RESTANTAM_DIAS, ChronoUnit.DAYS))) {
            registro.setExpiraEm(agora.plus(DURACAO_DIAS, ChronoUnit.DAYS));
            tokenRepository.save(registro);
            gravarCookie(response, token, Duration.ofDays(DURACAO_DIAS));
        }

        HttpSession session = request.getSession(true);
        session.setAttribute("usuario", usuario.get());
        return true;
    }

    @Transactional
    public void revogarAcessoAtual(HttpServletRequest request, HttpServletResponse response) {
        revogarCookieAtual(request);
        limparCookie(response);
    }

    @Transactional
    public void revogarTodosDoUsuario(Long usuarioId) {
        tokenRepository.deleteByUsuarioId(usuarioId);
    }

    public boolean temCookieLembrado(HttpServletRequest request) {
        String token = lerCookie(request);
        return token != null && !token.isBlank();
    }

    private void revogarCookieAtual(HttpServletRequest request) {
        String token = lerCookie(request);
        if (token != null && !token.isBlank()) tokenRepository.deleteByTokenHash(hash(token));
    }

    private String lerCookie(HttpServletRequest request) {
        Cookie[] cookies = request.getCookies();
        if (cookies == null) return null;
        for (Cookie cookie : cookies) {
            if (COOKIE_NAME.equals(cookie.getName())) return cookie.getValue();
        }
        return null;
    }

    private void gravarCookie(HttpServletResponse response, String token, Duration duracao) {
        response.addHeader("Set-Cookie", ResponseCookie.from(COOKIE_NAME, token)
                .httpOnly(true)
                .secure(cookieSecure)
                .sameSite(sameSite)
                .path("/")
                .maxAge(duracao)
                .build().toString());
    }

    private void limparCookie(HttpServletResponse response) {
        gravarCookie(response, "", Duration.ZERO);
    }

    private String hash(String token) {
        try {
            byte[] digest = MessageDigest.getInstance("SHA-256").digest(token.getBytes(StandardCharsets.UTF_8));
            return HexFormat.of().formatHex(digest);
        } catch (Exception e) {
            throw new IllegalStateException("Não foi possível processar o token de acesso.", e);
        }
    }
}
