package com.auth.simpleauth.controller;

import com.auth.simpleauth.dto.NotificacaoDto;
import com.auth.simpleauth.entity.Usuario;
import com.auth.simpleauth.service.NotificacaoService;
import jakarta.servlet.http.HttpSession;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/notificacoes")
public class NotificacaoController {
    private final NotificacaoService notificacaoService;

    public NotificacaoController(NotificacaoService notificacaoService) {
        this.notificacaoService = notificacaoService;
    }

    @GetMapping
    public List<NotificacaoDto> listar(HttpSession session) {
        return notificacaoService.listar(usuarioDaSessao(session).getId());
    }

    @DeleteMapping
    public ResponseEntity<Void> limpar(HttpSession session) {
        notificacaoService.limpar(usuarioDaSessao(session).getId());
        return ResponseEntity.noContent().build();
    }

    private static Usuario usuarioDaSessao(HttpSession session) {
        Object usuario = session.getAttribute("usuario");
        if (usuario instanceof Usuario u) return u;
        throw new SecurityException("Sessão inválida. Entre novamente.");
    }
}
