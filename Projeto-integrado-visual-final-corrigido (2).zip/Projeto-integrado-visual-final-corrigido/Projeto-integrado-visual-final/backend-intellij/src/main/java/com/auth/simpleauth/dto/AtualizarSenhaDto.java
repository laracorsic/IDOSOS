package com.auth.simpleauth.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;

public class AtualizarSenhaDto {
    @NotBlank(message = "Informe a senha atual.")
    @Size(max = 128, message = "A senha atual informada é inválida.")
    private String senhaAtual;

    @NotBlank(message = "Informe a nova senha.")
    @Size(min = 8, max = 64, message = "A nova senha deve ter entre 8 e 64 caracteres.")
    @Pattern(regexp = "^(?=.*[A-Za-z])(?=.*\\d).+$", message = "A nova senha precisa conter pelo menos uma letra e um número.")
    private String novaSenha;

    public AtualizarSenhaDto() {}
    public String getSenhaAtual() { return senhaAtual; }
    public void setSenhaAtual(String senhaAtual) { this.senhaAtual = senhaAtual; }
    public String getNovaSenha() { return novaSenha; }
    public void setNovaSenha(String novaSenha) { this.novaSenha = novaSenha; }
}
