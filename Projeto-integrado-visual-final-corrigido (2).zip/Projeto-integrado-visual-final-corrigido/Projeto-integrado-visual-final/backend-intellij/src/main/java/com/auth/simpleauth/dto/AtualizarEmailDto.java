package com.auth.simpleauth.dto;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

public class AtualizarEmailDto {
    @NotBlank(message = "Informe um e-mail.")
    @Email(message = "Informe um e-mail válido.")
    @Size(max = 254, message = "O e-mail é muito longo.")
    private String email;

    public AtualizarEmailDto() {}
    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }
}
