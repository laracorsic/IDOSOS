package com.auth.simpleauth.dto;

import com.auth.simpleauth.entity.Notificacao;
import java.time.LocalDateTime;

public record NotificacaoDto(Long id, String titulo, String mensagem, String url, LocalDateTime criadaEm, boolean lida) {
    public static NotificacaoDto de(Notificacao notificacao) {
        return new NotificacaoDto(notificacao.getId(), notificacao.getTitulo(), notificacao.getMensagem(),
                notificacao.getUrl(), notificacao.getCriadaEm(), notificacao.isLida());
    }
}
