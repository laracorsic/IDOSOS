package com.auth.simpleauth.dto;

public class UsuarioVinculadoDto {
    private Long id;
    private String nome;
    private String email;
    private String telefone;
    private String fotoUrl;

    public UsuarioVinculadoDto() {}

    public UsuarioVinculadoDto(Long id, String nome, String email, String telefone, String fotoUrl) {
        this.id = id;
        this.nome = nome;
        this.email = email;
        this.telefone = telefone;
        this.fotoUrl = fotoUrl;
    }

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getNome() { return nome; }
    public void setNome(String nome) { this.nome = nome; }

    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }

    public String getTelefone() { return telefone; }
    public void setTelefone(String telefone) { this.telefone = telefone; }

    public String getFotoUrl() { return fotoUrl; }
    public void setFotoUrl(String fotoUrl) { this.fotoUrl = fotoUrl; }
}
