package com.auth.simpleauth.controller;

import com.auth.simpleauth.dto.LoginRequestDto;
import com.auth.simpleauth.dto.LoginResponseDto;
import com.auth.simpleauth.dto.UsuarioCadastroDto;
import com.auth.simpleauth.entity.Usuario;
import com.auth.simpleauth.service.AcessoLembradoService;
import com.auth.simpleauth.service.UsuarioService;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;

@RestController
@RequestMapping("/login")
public class LoginController {

    private final UsuarioService usuarioService;
    private final AcessoLembradoService acessoLembradoService;

    public LoginController(UsuarioService usuarioService, AcessoLembradoService acessoLembradoService) {
        this.usuarioService = usuarioService;
        this.acessoLembradoService = acessoLembradoService;
    }

    @PostMapping
    public ResponseEntity<?> login(@Valid @RequestBody LoginRequestDto loginDto,
                                   HttpSession session,
                                   HttpServletRequest request,
                                   HttpServletResponse response) {
        Optional<Usuario> usuarioEncontrado = usuarioService.autenticar(loginDto.getEmail(), loginDto.getSenha());
        if (usuarioEncontrado.isEmpty()) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("E-mail ou senha incorretos.");
        }

        Usuario usuario = usuarioEncontrado.get();
        if (!session.isNew()) request.changeSessionId();
        session.setAttribute("usuario", usuario);
        acessoLembradoService.prepararLogin(usuario, loginDto.isLembrarMe(), request, response);
        return ResponseEntity.ok(new LoginResponseDto(usuario));
    }

    @PostMapping("/register")
    public ResponseEntity<String> register(@Valid @RequestBody UsuarioCadastroDto novoUsuarioDto) {
        if (usuarioService.findByEmail(novoUsuarioDto.getEmail()).isPresent()) {
            return ResponseEntity.status(HttpStatus.CONFLICT).body("Este e-mail já está cadastrado.");
        }
        try {
            usuarioService.criaNovoUsuario(novoUsuarioDto.toEntity());
            return ResponseEntity.status(HttpStatus.CREATED).body("Conta criada com sucesso.");
        } catch (IllegalArgumentException erro) {
            return ResponseEntity.badRequest().body(erro.getMessage());
        }
    }

    @PostMapping("/logout")
    public ResponseEntity<String> logout(HttpSession session, HttpServletRequest request, HttpServletResponse response) {
        acessoLembradoService.revogarAcessoAtual(request, response);
        session.invalidate();
        return ResponseEntity.ok("Você saiu da sua conta.");
    }

    @GetMapping
    public ResponseEntity<?> usuarioLogado(HttpSession session, HttpServletRequest request, HttpServletResponse response) {
        Usuario usuarioSessao = (Usuario) session.getAttribute("usuario");
        if (usuarioSessao == null && acessoLembradoService.restaurarSessao(request, response)) {
            if (!session.isNew()) request.changeSessionId();
            usuarioSessao = (Usuario) session.getAttribute("usuario");
        }
        if (usuarioSessao == null) return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Nenhuma sessão ativa.");

        Optional<Usuario> usuarioAtualizado = usuarioService.buscarPorId(usuarioSessao.getId());
        if (usuarioAtualizado.isEmpty()) {
            session.invalidate();
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("A sessão não é mais válida.");
        }
        session.setAttribute("usuario", usuarioAtualizado.get());
        return ResponseEntity.ok(new LoginResponseDto(usuarioAtualizado.get()));
    }

    /** Conta só pode ser encerrada pelo próprio titular, independentemente do grupo. */
    @DeleteMapping("/{id}")
    public ResponseEntity<String> deletarUsuario(@PathVariable Long id, @Valid @RequestBody com.auth.simpleauth.dto.ConfirmarSenhaDto dto, HttpSession session) {
        Usuario usuarioLogado = (Usuario) session.getAttribute("usuario");
        if (usuarioLogado == null) return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Entre na sua conta para continuar.");
        if (!usuarioLogado.getId().equals(id)) return ResponseEntity.status(HttpStatus.FORBIDDEN).body("Você só pode excluir a própria conta.");
        usuarioService.confirmarSenhaAtual(id, dto.getSenha());
        usuarioService.deletarPorId(id);
        session.invalidate();
        return ResponseEntity.ok("Conta excluída.");
    }
}
