package com.auth.simpleauth.dto;

public class VinculoTelefoneDto {
    private Long idIdoso;
    private String telefone;

    public VinculoTelefoneDto() {}
    public Long getIdIdoso() { return idIdoso; }
    public void setIdIdoso(Long idIdoso) { this.idIdoso = idIdoso; }
    public String getTelefone() { return telefone; }
    public void setTelefone(String telefone) { this.telefone = telefone; }
}
