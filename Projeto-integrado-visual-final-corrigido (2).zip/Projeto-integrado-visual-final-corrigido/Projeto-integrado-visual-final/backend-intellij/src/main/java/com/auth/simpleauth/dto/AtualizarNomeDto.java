package com.auth.simpleauth.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

public class AtualizarNomeDto {
    @NotBlank(message = "Informe seu nome.")
    @Size(min = 2, max = 100, message = "O nome deve ter entre 2 e 100 caracteres.")
    private String nome;

    public AtualizarNomeDto() {}
    public String getNome() { return nome; }
    public void setNome(String nome) { this.nome = nome; }
}
