package com.auth.simpleauth.service;

import com.auth.simpleauth.entity.Usuario;
import com.auth.simpleauth.repository.TokenAcessoLembradoRepository;
import com.auth.simpleauth.repository.UsuarioRepository;
import com.auth.simpleauth.repository.VinculoFamiliarRepository;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Optional;

@Service
public class UsuarioService {

    private final UsuarioRepository loginRepository;
    private final VinculoFamiliarRepository vinculoRepository;
    private final TokenAcessoLembradoRepository tokenRepository;
    private final PasswordEncoder passwordEncoder;

    public UsuarioService(UsuarioRepository loginRepository,
                          VinculoFamiliarRepository vinculoRepository,
                          TokenAcessoLembradoRepository tokenRepository,
                          PasswordEncoder passwordEncoder) {
        this.loginRepository = loginRepository;
        this.vinculoRepository = vinculoRepository;
        this.tokenRepository = tokenRepository;
        this.passwordEncoder = passwordEncoder;
    }

    @Transactional
    public Optional<Usuario> autenticar(String email, String senha) {
        if (email == null || senha == null) return Optional.empty();
        Optional<Usuario> encontrado = loginRepository.findByEmailIgnoreCase(email.trim());
        if (encontrado.isEmpty()) return Optional.empty();

        Usuario usuario = encontrado.get();
        String senhaArmazenada = usuario.getSenha();
        if (senhaArmazenada == null || !senhaCorresponde(senha, senhaArmazenada)) return Optional.empty();

        // Migra automaticamente credenciais antigas em texto puro no primeiro login válido.
        if (!senhaArmazenada.startsWith("$2a$") && !senhaArmazenada.startsWith("$2b$") && !senhaArmazenada.startsWith("$2y$")) {
            usuario.setSenha(passwordEncoder.encode(senha));
            loginRepository.save(usuario);
        }
        return Optional.of(usuario);
    }

    private boolean senhaCorresponde(String senhaDigitada, String armazenada) {
        if (armazenada.startsWith("$2a$") || armazenada.startsWith("$2b$") || armazenada.startsWith("$2y$")) {
            try {
                return passwordEncoder.matches(senhaDigitada, armazenada);
            } catch (IllegalArgumentException ignorado) {
                return false;
            }
        }
        return MessageDigest.isEqual(senhaDigitada.getBytes(StandardCharsets.UTF_8), armazenada.getBytes(StandardCharsets.UTF_8));
    }

    @Transactional(readOnly = true)
    public Optional<Usuario> buscarPorId(Long id) {
        return loginRepository.findById(id);
    }

    @Transactional(readOnly = true)
    public Optional<Usuario> findByEmail(String email) {
        if (email == null || email.isBlank()) return Optional.empty();
        return loginRepository.findByEmailIgnoreCase(email.trim());
    }

    @Transactional
    public void criaNovoUsuario(Usuario novoUsuario) {
        validarLimiteSenhaBcrypt(novoUsuario.getSenha());
        novoUsuario.setEmail(novoUsuario.getEmail().trim().toLowerCase());
        novoUsuario.setSenha(passwordEncoder.encode(novoUsuario.getSenha()));
        loginRepository.save(novoUsuario);
    }

    @Transactional
    public void deletarUsuario(Usuario usuario) {
        tokenRepository.deleteByUsuarioId(usuario.getId());
        loginRepository.delete(usuario);
    }

    @Transactional
    public void deletarPorId(Long id) {
        loginRepository.limparTelegramChatId(id);
        vinculoRepository.deleteByFamiliarIdOrIdosoId(id, id);
        tokenRepository.deleteByUsuarioId(id);
        Usuario usuario = loginRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Usuário não encontrado"));
        loginRepository.delete(usuario);
        loginRepository.flush();
    }

    @Transactional
    public Usuario atualizarNome(Long id, String nome) {
        loginRepository.atualizarApenasNome(id, nome.trim());
        return loginRepository.findById(id).orElseThrow(() -> new RuntimeException("Usuário não encontrado"));
    }

    @Transactional
    public Usuario atualizarEmail(Long id, String email) {
        String normalizado = email.trim().toLowerCase();
        loginRepository.findByEmailIgnoreCase(normalizado).ifPresent(existente -> {
            if (!existente.getId().equals(id)) throw new IllegalArgumentException("Este e-mail já está em uso.");
        });
        loginRepository.atualizarApenasEmail(id, normalizado);
        return loginRepository.findById(id).orElseThrow(() -> new RuntimeException("Usuário não encontrado"));
    }

    @Transactional
    public Usuario atualizarTelefone(Long id, String telefone) {
        loginRepository.atualizarApenasTelefone(id, telefone.trim());
        return loginRepository.findById(id).orElseThrow(() -> new RuntimeException("Usuário não encontrado"));
    }

    @Transactional
    public Usuario atualizarSenha(Long id, String senhaAtual, String novaSenha) {
        Usuario usuario = loginRepository.findById(id).orElseThrow(() -> new RuntimeException("Usuário não encontrado"));
        if (senhaAtual == null || !senhaCorresponde(senhaAtual, usuario.getSenha())) {
            throw new IllegalArgumentException("Senha atual incorreta.");
        }
        if (!senhaForteValida(novaSenha)) {
            throw new IllegalArgumentException("A nova senha deve ter 8 a 64 caracteres e conter pelo menos uma letra e um número.");
        }
        validarLimiteSenhaBcrypt(novaSenha);
        usuario.setSenha(passwordEncoder.encode(novaSenha));
        tokenRepository.deleteByUsuarioId(id);
        return loginRepository.save(usuario);
    }

    @Transactional(readOnly = true)
    public void confirmarSenhaAtual(Long id, String senhaAtual) {
        Usuario usuario = loginRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Conta não encontrada."));
        if (senhaAtual == null || !senhaCorresponde(senhaAtual, usuario.getSenha())) {
            throw new IllegalArgumentException("A senha atual não confere.");
        }
    }

    private boolean senhaForteValida(String senha) {
        return senha != null && senha.length() >= 8 && senha.length() <= 64
                && senha.chars().anyMatch(Character::isLetter)
                && senha.chars().anyMatch(Character::isDigit);
    }

    private void validarLimiteSenhaBcrypt(String senha) {
        if (senha == null || senha.getBytes(StandardCharsets.UTF_8).length > 72) {
            throw new IllegalArgumentException("A senha é longa demais. Use até 72 bytes em UTF-8.");
        }
    }

    @Transactional
    public Usuario atualizarFoto(Long id, String imagemUrl) {
        loginRepository.atualizarApenasFoto(id, imagemUrl);
        return loginRepository.findById(id).orElseThrow(() -> new RuntimeException("Usuário não encontrado"));
    }
}
