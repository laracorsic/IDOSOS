package com.auth.simpleauth.dto;

import jakarta.validation.constraints.Size;

public class AtualizarFotoDto {
    @Size(max = 500_000, message = "A foto é muito grande. Escolha uma imagem menor.")
    private String imagemUrl;

    public AtualizarFotoDto() {}
    public String getImagemUrl() { return imagemUrl; }
    public void setImagemUrl(String imagemUrl) { this.imagemUrl = imagemUrl; }
}
