package com.auth.simpleauth.controller;

import com.auth.simpleauth.dto.IdosoDto;
import com.auth.simpleauth.dto.IdosoResponseDto;
import com.auth.simpleauth.entity.Idoso;
import com.auth.simpleauth.entity.Usuario;
import com.auth.simpleauth.enums.Perfil;
import com.auth.simpleauth.enums.StatusVinculo;
import com.auth.simpleauth.repository.VinculoFamiliarRepository;
import com.auth.simpleauth.service.IdosoService;
import jakarta.servlet.http.HttpSession;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/idosos")
public class IdosoController {
    private final IdosoService service;
    private final VinculoFamiliarRepository vinculoRepository;

    public IdosoController(IdosoService service, VinculoFamiliarRepository vinculoRepository) {
        this.service = service;
        this.vinculoRepository = vinculoRepository;
    }

    @PostMapping
    public ResponseEntity<?> cadastrar(@Valid @RequestBody IdosoDto dto) {
        return ResponseEntity.status(HttpStatus.FORBIDDEN).body("Crie novas contas pelo fluxo /login/register.");
    }

    @GetMapping
    public ResponseEntity<?> listar(HttpSession session) {
        Usuario atual = usuarioSessao(session);
        if (atual instanceof Idoso idoso) return ResponseEntity.ok(List.of(new IdosoResponseDto(idoso)));
        if (atual == null || atual.getPerfil() != Perfil.FAMILIAR) return proibido(session);
        List<IdosoResponseDto> vinculados = vinculoRepository.findByFamiliarIdAndStatusWithIdoso(atual.getId(), StatusVinculo.ACEITO)
                .stream().map(v -> new IdosoResponseDto(v.getIdoso())).toList();
        return ResponseEntity.ok(vinculados);
    }

    @GetMapping("/{id}")
    public ResponseEntity<?> buscarPorId(@PathVariable Long id, HttpSession session) {
        Usuario atual = usuarioSessao(session);
        if (atual == null) return proibido(session);
        boolean proprioPerfil = atual instanceof Idoso && id.equals(atual.getId());
        boolean familiarVinculado = atual.getPerfil() == Perfil.FAMILIAR &&
                (vinculoRepository.existsByFamiliarIdAndIdosoIdAndStatus(atual.getId(), id, StatusVinculo.ACEITO)
                        || vinculoRepository.existsByFamiliarIdAndIdosoIdAndStatus(atual.getId(), id, StatusVinculo.PENDENTE));
        if (!proprioPerfil && !familiarVinculado) return proibido(session);
        return service.buscarPorId(id).<ResponseEntity<?>>map(i -> ResponseEntity.ok(new IdosoResponseDto(i)))
                .orElseGet(() -> ResponseEntity.notFound().build());
    }

    @PutMapping("/{id}")
    public ResponseEntity<?> atualizar(@PathVariable Long id, @Valid @RequestBody IdosoDto dto, HttpSession session) {
        Usuario atual = usuarioSessao(session);
        if (!(atual instanceof Idoso) || !id.equals(atual.getId())) return proibido(session);
        Idoso idosoAtualizado = service.atualizar(id, dto);
        return ResponseEntity.ok(new IdosoResponseDto(idosoAtualizado));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> remover(@PathVariable Long id, HttpSession session) {
        Usuario atual = usuarioSessao(session);
        if (!(atual instanceof Idoso) || !id.equals(atual.getId())) return proibido(session);
        service.remover(id);
        session.invalidate();
        return ResponseEntity.noContent().build();
    }

    private Usuario usuarioSessao(HttpSession session) {
        Object usuario = session.getAttribute("usuario");
        return usuario instanceof Usuario u ? u : null;
    }

    private ResponseEntity<?> proibido(HttpSession session) {
        if (usuarioSessao(session) == null) return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Entre na sua conta para continuar.");
        return ResponseEntity.status(HttpStatus.FORBIDDEN).body("Esta operação não é permitida para o seu perfil ou vínculo.");
    }
}
