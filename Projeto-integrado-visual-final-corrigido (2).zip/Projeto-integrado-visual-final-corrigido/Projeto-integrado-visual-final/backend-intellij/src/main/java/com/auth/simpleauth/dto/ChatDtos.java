package com.auth.simpleauth.dto;

import com.auth.simpleauth.entity.ChatMensagem;
import java.time.LocalDateTime;

public final class ChatDtos {
    private ChatDtos() {}
    public record EnviarMensagem(Long idosoId, String texto) {}
    public record Mensagem(Long id, Long remetenteId, String remetenteNome, String texto, LocalDateTime enviadaEm) {
        public static Mensagem de(ChatMensagem m) {
            return new Mensagem(m.getId(), m.getRemetente().getId(), m.getRemetente().getNome(), m.getTexto(), m.getEnviadaEm());
        }
    }
    public record Conversa(Long idosoId, String idosoNome, Long familiarId, String familiarNome, LocalDateTime ultimaMensagem) {}
}
