# Executar o backend no IntelliJ

## Requisitos

- Java 21.
- Maven Wrapper incluído no projeto.
- Nenhum MySQL é necessário para desenvolvimento local: use o perfil `local`, que seleciona H2 em arquivo (`connecthub-local.mv.db`).

## IntelliJ

1. Abra a pasta `backend-intellij` como projeto Maven.
2. Aguarde o IntelliJ importar as dependências.
3. Abra **Run → Edit Configurations** e selecione a configuração da classe `SimpleAuthApplication` (ou crie uma aplicação Spring Boot apontando para essa classe).
4. Defina `SPRING_PROFILES_ACTIVE=local` em **Environment variables**.
5. Opcionalmente, adicione `ASSISTENTE_IA_CHAVE=sua_chave_groq_nova` para respostas generativas. A chave deve permanecer só no ambiente/gerenciador de segredos. Sem ela, o backend responde em modo local limitado.
6. Execute a aplicação. A API estará em `http://localhost:8080`.

## Terminal

Na pasta do backend:

```bash
SPRING_PROFILES_ACTIVE=local ./mvnw spring-boot:run
```

Para respostas generativas:

```bash
SPRING_PROFILES_ACTIVE=local ASSISTENTE_IA_CHAVE='sua_chave_groq_nova' ./mvnw spring-boot:run
```

## Verificação rápida

Abra `http://localhost:8080/assistente/status`. O status deve indicar se a IA generativa está configurada. As rotas protegidas por sessão devem ser chamadas pelo frontend com `credentials: 'include'`; o cadastro e o login do pacote já fazem isso. O CORS autoriza origens locais `localhost` e `127.0.0.1`.

O banco H2 local usa arquivo (`connecthub-local.mv.db`) e preserva cadastros entre reinicializações. Para produção, configure banco persistente, cookies seguros, HTTPS, CORS com a origem real e segredos fora dos arquivos versionados. Revogue qualquer chave que tenha sido compartilhada no ZIP original se ela era válida.
