# Executar localmente sem configurar variáveis no IntelliJ

O perfil padrão usa H2 em arquivo local (`connecthub-local.mv.db`) no modo de compatibilidade PostgreSQL. Basta abrir o projeto e executar `SimpleAuthApplication`; não é necessário preencher variáveis em **Run → Edit Configurations** nem instalar um servidor de banco. Os dados desse banco ficam no computador e continuam disponíveis depois de reiniciar a aplicação.

Esse banco local é independente do PostgreSQL do Render: dados criados localmente não aparecem no site publicado. Em produção, o Render continua usando PostgreSQL pelas variáveis `SPRING_DATASOURCE_URL`, `SPRING_DATASOURCE_USERNAME` e `SPRING_DATASOURCE_PASSWORD`, que sobrescrevem os padrões locais.

O perfil `local` usa o mesmo H2 em arquivo e também não depende de MySQL. O arquivo `connecthub-local.mv.db` é local e está ignorado pelo Git.

A chave do assistente de IA não é necessária para iniciar o backend. Sem `ASSISTENTE_IA_CHAVE`, o assistente usa as respostas locais limitadas.

O login lembrado dura até 365 dias e é renovado enquanto o dispositivo for usado. O navegador recebe somente um token aleatório em cookie `HttpOnly`; o backend mantém o hash do token no banco. O botão **Sair** revoga o token daquele dispositivo. Em produção, configure um banco persistente e HTTPS; sessões não podem sobreviver a reinicializações se o banco usado for temporário/em memória.

O arquivo de banco local é ignorado pelo Git. Como credenciais do arquivo original foram compartilhadas, revogue-as e gere novas; não coloque novas credenciais no código ou em repositórios.
