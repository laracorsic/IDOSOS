function obterIdosoAtual() {
    const idosoSalvo = JSON.parse(localStorage.getItem("selectedIdoso"));
    if (idosoSalvo && idosoSalvo.id) {
        return idosoSalvo;
    }
    
    const currentUser = JSON.parse(localStorage.getItem("currentUser")) || {};
    return {
        id: currentUser.idIdoso || "12345",
        nome: currentUser.nomeIdoso || "Miquéias de Sousa"
    };
}

function obterChaveCompromissos() {
    const idoso = obterIdosoAtual();
    return `zelo_compromissos_${idoso.id}`;
}

function abrirModal(modalId) {
    document.getElementById(modalId).classList.remove('hidden');
    if (modalId === 'modal-remover') carregarListaRemover();
    if (modalId === 'modal-listar') carregarListaVisualizar();
}

function fecharModal(modalId) {
    document.getElementById(modalId).classList.add('hidden');
}

function adicionarCompromisso(event) {
    event.preventDefault();

    const titulo = document.getElementById("titulo").value;
    const data = document.getElementById("data").value;
    const hora = document.getElementById("hora").value;
    const local = document.getElementById("local").value;

    const novoCompromisso = {
        id: Date.now(),
        titulo,
        data,
        hora,
        local
    };

    const chave = obterChaveCompromissos();
    const compromissos = JSON.parse(localStorage.getItem(chave)) || [];
    compromissos.push(novoCompromisso);

    localStorage.setItem(chave, JSON.stringify(compromissos));

    document.getElementById("form-adicionar").reset();
    fecharModal('modal-adicionar');
    alert("Compromisso adicionado com sucesso!");
}

function carregarListaVisualizar() {
    const chave = obterChaveCompromissos();
    const compromissos = JSON.parse(localStorage.getItem(chave)) || [];
    const lista = document.getElementById("lista-visualizar");
    lista.innerHTML = "";

    if (compromissos.length === 0) {
        lista.innerHTML = "<li>Nenhum compromisso cadastrado.</li>";
        return;
    }

    compromissos.forEach(c => {
        const dataFormatada = c.data ? c.data.split("-").reverse().join("/") : "";
        const li = document.createElement("li");
        li.innerHTML = `
            <div>
                <strong>${c.titulo}</strong><br>
                <small>📅 ${dataFormatada} às ⏰ ${c.hora} ${c.local ? '| 📍 ' + c.local : ''}</small>
            </div>
        `;
        lista.appendChild(li);
    });
}

function carregarListaRemover() {
    const chave = obterChaveCompromissos();
    const compromissos = JSON.parse(localStorage.getItem(chave)) || [];
    const lista = document.getElementById("lista-remover");
    lista.innerHTML = "";

    if (compromissos.length === 0) {
        lista.innerHTML = "<li>Nenhum compromisso para remover.</li>";
        return;
    }

    compromissos.forEach(c => {
        const dataFormatada = c.data ? c.data.split("-").reverse().join("/") : "";
        const li = document.createElement("li");
        li.innerHTML = `
            <div>
                <strong>${c.titulo}</strong><br>
                <small>📅 ${dataFormatada} às ⏰ ${c.hora}</small>
            </div>
            <button class="btn-delete-item" onclick="removerCompromisso(${c.id})">Excluir</button>
        `;
        lista.appendChild(li);
    });
}

function removerCompromisso(id) {
    const chave = obterChaveCompromissos();
    let compromissos = JSON.parse(localStorage.getItem(chave)) || [];
    compromissos = compromissos.filter(c => c.id !== id);
    localStorage.setItem(chave, JSON.stringify(compromissos));
    carregarListaRemover();
}

document.addEventListener("DOMContentLoaded", () => {
    const idoso = obterIdosoAtual();
    const label = document.getElementById("nome-idoso-label");
    if (label) {
        label.textContent = idoso.nome;
    }
});