package com.auth.simpleauth.service;

import com.auth.simpleauth.entity.Dose;
import com.auth.simpleauth.enums.StatusDose;
import com.auth.simpleauth.repository.DoseRepository;
import com.auth.simpleauth.repository.FamiliarRepository;
import com.auth.simpleauth.repository.IdosoRepository;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.List;
import java.util.Map;

@Service
public class TelegramPollingService {

    @Value("${telegram.bot.token}")
    private String botToken;

    private final RestTemplate restTemplate = new RestTemplate();
    private final DoseRepository doseRepository;
    private final IdosoRepository idosoRepository;
    private final FamiliarRepository familiarRepository;
    private final TelegramService telegramService;
    private final DoseService doseService;

    private long lastUpdateId = 0;

    public TelegramPollingService(DoseRepository doseRepository,
                                  IdosoRepository idosoRepository,
                                  FamiliarRepository familiarRepository,
                                  TelegramService telegramService,
                                  DoseService doseService) {
        this.doseRepository = doseRepository;
        this.idosoRepository = idosoRepository;
        this.familiarRepository = familiarRepository;
        this.telegramService = telegramService;
        this.doseService = doseService;
    }

    @Scheduled(fixedRate = 3000)
    public void verificarCliquesNosBotoes() {
        if (botToken == null || botToken.isBlank()) return;

        String url = String.format("https://api.telegram.org/bot%s/getUpdates?offset=%d", botToken, lastUpdateId + 1);

        try {
            Map<String, Object> response = restTemplate.getForObject(url, Map.class);
            if (response != null && Boolean.TRUE.equals(response.get("ok"))) {
                List<Map<String, Object>> result = (List<Map<String, Object>>) response.get("result");

                for (Map<String, Object> update : result) {
                    lastUpdateId = ((Number) update.get("update_id")).longValue();

                    if (update.containsKey("callback_query")) {
                        Map<String, Object> callback = (Map<String, Object>) update.get("callback_query");
                        String data = (String) callback.get("data");

                        if (data != null && data.startsWith("TOMAR_DOSE:")) {
                            Long idDose = Long.parseLong(data.split(":")[1]);
                            processarConfirmacao(idDose);
                        }
                    }

                    if (update.containsKey("message")) {
                        Map<String, Object> message = (Map<String, Object>) update.get("message");
                        if (message.containsKey("text") && message.containsKey("chat")) {
                            String texto = (String) message.get("text");
                            Map<String, Object> chat = (Map<String, Object>) message.get("chat");
                            String chatId = String.valueOf(chat.get("id"));
                            processarComandoStart(texto, chatId);
                        }
                    }
                }
            }
        } catch (Exception e) {
            // Ignora falhas temporárias de conexão
        }
    }

    private void processarComandoStart(String texto, String chatId) {
        if (texto.startsWith("/start")) {
            String[] partes = texto.split(" ");
            if (partes.length > 1) {
                String token = partes[1];
                try {
                    if (token.startsWith("IDOSO_")) {
                        Long idosoId = Long.parseLong(token.replace("IDOSO_", ""));
                        idosoRepository.findById(idosoId).ifPresentOrElse(
                                idoso -> {
                                    idoso.setTelegramChatId(chatId);
                                    idosoRepository.save(idoso);
                                    telegramService.enviarNotificacao(chatId, String.format("✅ Olá, <b>%s</b>! Seu Telegram foi vinculado com sucesso para receber os alertas de remédios.", idoso.getNome()));
                                },
                                () -> telegramService.enviarNotificacao(chatId, String.format("⚠️ Idoso com ID %d não foi encontrado no banco de dados.", idosoId))
                        );
                    } else if (token.startsWith("FAMILIAR_")) {
                        Long familiarId = Long.parseLong(token.replace("FAMILIAR_", ""));
                        familiarRepository.findById(familiarId).ifPresentOrElse(
                                familiar -> {
                                    familiar.setTelegramChatId(chatId);
                                    familiarRepository.save(familiar);
                                    telegramService.enviarNotificacao(chatId, String.format("✅ Olá, <b>%s</b>! Seu Telegram foi vinculado para acompanhar as medicações.", familiar.getNome()));
                                },
                                () -> telegramService.enviarNotificacao(chatId, String.format("⚠️ Familiar com ID %d não foi encontrado no banco de dados.", familiarId))
                        );
                    }
                } catch (Exception e) {
                    telegramService.enviarNotificacao(chatId, "⚠️ Código de vinculação inválido.");
                }
            } else {
                telegramService.enviarNotificacao(chatId, "👋 Bem-vindo ao sistema de lembrete de medicamentos!\nPara vincular sua conta, acesse o sistema web e clique no link de conexão do Telegram.");
            }
        }
    }

    private void processarConfirmacao(Long idDose) {
        doseRepository.findById(idDose).ifPresent(dose -> {
            if (dose.getStatus() != StatusDose.TOMADO) {
                doseService.confirmarDose(idDose);

                String chatIdIdoso = dose.getMedicamento().getIdoso().getTelegramChatId();
                if (chatIdIdoso != null) {
                    telegramService.enviarNotificacao(chatIdIdoso, "🎉 Parabéns! Sua dose foi confirmada com sucesso.");
                }

                var familiar = dose.getMedicamento().getIdoso().getFamiliar();
                if (familiar != null && familiar.getTelegramChatId() != null) {
                    String msgFamiliar = String.format(
                            "✅ O idoso <b>%s</b> confirmou a tomada do medicamento '<b>%s</b>'!",
                            dose.getMedicamento().getIdoso().getNome(),
                            dose.getMedicamento().getNome()
                    );
                    telegramService.enviarNotificacao(familiar.getTelegramChatId(), msgFamiliar);
                }
            }
        });
    }
}