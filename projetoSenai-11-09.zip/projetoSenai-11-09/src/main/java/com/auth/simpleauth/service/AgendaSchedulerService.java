package com.auth.simpleauth.service;

import com.auth.simpleauth.entity.Dose;
import com.auth.simpleauth.entity.Familiar;
import com.auth.simpleauth.entity.Medicamento;
import com.auth.simpleauth.enums.StatusDose;
import com.auth.simpleauth.repository.DoseRepository;
import com.auth.simpleauth.repository.MedicamentoRepository;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

@Service
public class AgendaSchedulerService {

    private final DoseRepository doseRepository;
    private final MedicamentoRepository medicamentoRepository;
    private final TelegramService telegramService;

    public AgendaSchedulerService(DoseRepository doseRepository,
                                  MedicamentoRepository medicamentoRepository,
                                  TelegramService telegramService) {
        this.doseRepository = doseRepository;
        this.medicamentoRepository = medicamentoRepository;
        this.telegramService = telegramService;
    }

    /**
     * 1. Processa a notificação das doses que estão pendentes ou notificadas.
     */
    @Scheduled(fixedRate = 10000)
    @Transactional
    public void verificarDosesAgendadas() {
        LocalDateTime agora = LocalDateTime.now();

        List<Dose> dosesParaProcessar = doseRepository.findByStatusInAndHorarioProgramadoLessThanEqual(
                List.of(StatusDose.PENDENTE, StatusDose.NOTIFICADO),
                agora
        );

        for (Dose dose : dosesParaProcessar) {
            processarDose(dose, agora);
        }
    }

    /**
     * 2. Varredura dedicada para inativar tratamentos expirados.
     * REMOVIDO @Transactional do método principal para efetivar o commit imediatamente no banco.
     */
    @Scheduled(fixedRate = 10000)
    public void verificarTratamentosExpirados() {
        LocalDateTime agora = LocalDateTime.now();

        // Busca apenas medicamentos que AINDA estão ativos mas já passaram da dataFimTratamento
        List<Medicamento> medicamentosExpirados = medicamentoRepository
                .findByAtivoTrueAndDataFimTratamentoLessThanEqual(agora);

        for (Medicamento med : medicamentosExpirados) {
            try {
                // A) INATIVA IMEDIATAMENTE NO BANCO DE DADOS
                med.setAtivo(false);
                medicamentoRepository.save(med);

                // B) CANCELA TODAS AS DOSES PENDENTES/NOTIFICADAS REMANESCENTES
                List<Dose> dosesPendentes = doseRepository.findByMedicamentoIdosoId(med.getIdoso().getId());
                for (Dose dose : dosesPendentes) {
                    if (dose.getMedicamento().getId().equals(med.getId()) &&
                            (dose.getStatus() == StatusDose.PENDENTE || dose.getStatus() == StatusDose.NOTIFICADO)) {
                        dose.setStatus(StatusDose.CANCELADO);
                        dose.setProximaNotificacao(null);
                        doseRepository.save(dose);
                    }
                }

                // C) ENVIA A NOTIFICAÇÃO NO TELEGRAM (Apenas após persistir a inativação)
                notificarFamiliarTerminoTratamento(med);

            } catch (Exception e) {
                System.err.println("Erro ao processar inativação do medicamento ID " + med.getId() + ": " + e.getMessage());
            }
        }
    }

    private void processarDose(Dose dose, LocalDateTime agora) {
        Medicamento med = dose.getMedicamento();

        // Se o medicamento estiver inativo, cancela a dose vinculada
        if (Boolean.FALSE.equals(med.getAtivo())) {
            dose.setStatus(StatusDose.CANCELADO);
            doseRepository.save(dose);
            return;
        }

        // VERIFICAÇÃO DE FIM DE TRATAMENTO
        if (med.getDataFimTratamento() != null && agora.isAfter(med.getDataFimTratamento())) {
            inativarTratamentoExpirado(med, dose);
            return;
        }

        String nomeMedicamento = med.getNome();
        String nomeIdoso = med.getIdoso().getNome();
        String telegramIdIdoso = med.getIdoso().getTelegramChatId();

        // 1. PRIMEIRA NOTIFICAÇÃO
        if (dose.getStatus() == StatusDose.PENDENTE) {
            dose.setStatus(StatusDose.NOTIFICADO);
            dose.setQuantidadeNotificacoes(1);
            dose.setProximaNotificacao(agora.plusMinutes(2));
            doseRepository.save(dose);

            String mensagemAcessivel = montarMensagemAcessivel(dose);
            telegramService.enviarNotificacaoComBotao(telegramIdIdoso, mensagemAcessivel, dose.getId());
            return;
        }

        // 2. RE-NOTIFICAÇÃO OU ATRASO
        if (dose.getStatus() == StatusDose.NOTIFICADO && dose.getProximaNotificacao() != null) {
            if (agora.isAfter(dose.getProximaNotificacao())) {
                int tentativas = dose.getQuantidadeNotificacoes() + 1;
                dose.setQuantidadeNotificacoes(tentativas);

                if (tentativas == 2) {
                    dose.setProximaNotificacao(agora.plusMinutes(1));
                    doseRepository.save(dose);

                    String emojiCor = obterEmojiCor(med.getCorCaixa());
                    String msgReiteracao = String.format(
                            "⚠️ %s, você ainda não confirmou o remédio da caixa %s <b>%s</b> ('<b>%s</b>')!\n" +
                                    "Por favor, clique no botão abaixo para confirmar.",
                            nomeIdoso,
                            emojiCor,
                            med.getCorCaixa() != null ? med.getCorCaixa().toUpperCase() : "",
                            nomeMedicamento
                    );
                    telegramService.enviarNotificacaoComBotao(telegramIdIdoso, msgReiteracao, dose.getId());

                } else {
                    dose.setStatus(StatusDose.ATRASADO);
                    doseRepository.save(dose);

                    notificarFamiliarAtraso(dose);
                }
            }
        }
    }

    private void inativarTratamentoExpirado(Medicamento med, Dose dose) {
        med.setAtivo(false);
        medicamentoRepository.save(med);

        dose.setStatus(StatusDose.CANCELADO);
        doseRepository.save(dose);

        notificarFamiliarTerminoTratamento(med);
    }

    private void notificarFamiliarTerminoTratamento(Medicamento med) {
        Familiar familiar = med.getIdoso().getFamiliar();
        if (familiar != null && familiar.getTelegramChatId() != null) {
            String msgFamiliar = String.format(
                    "📋 <b>TRATAMENTO CONCLUÍDO</b>\n\n" +
                            "O tratamento do medicamento <b>%s</b> para o idoso <b>%s</b> atingiu a data de término prevista (%s).\n\n" +
                            "ℹ️ O medicamento foi inativado automaticamente e não gerará novos lembretes.",
                    med.getNome(),
                    med.getIdoso().getNome(),
                    med.getDataFimTratamento().format(DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm"))
            );
            telegramService.enviarNotificacao(familiar.getTelegramChatId(), msgFamiliar);
        }
    }

    private String montarMensagemAcessivel(Dose dose) {
        Medicamento med = dose.getMedicamento();

        String horarioFormatado = dose.getHorarioProgramado().format(DateTimeFormatter.ofPattern("HH:mm")) + "h";
        String emojiCor = obterEmojiCor(med.getCorCaixa());

        String quantidadeDose = (med.getQuantidadePorDose() % 1 == 0)
                ? String.valueOf(med.getQuantidadePorDose().longValue())
                : String.valueOf(med.getQuantidadePorDose());

        StringBuilder msg = new StringBuilder();
        msg.append(String.format("⏰ <b>Horário: %s</b>\n", horarioFormatado));
        msg.append("🔔 <b>HORA DO REMÉDIO!</b>\n\n");

        if (med.getCorCaixa() != null || med.getIdentificadorCaixa() != null) {
            String identificador = med.getIdentificadorCaixa() != null ? med.getIdentificadorCaixa().trim() : "";

            boolean isNumero = identificador.matches("\\d+");
            String tipoIdentificador = isNumero ? "com o número" : "com a letra";

            msg.append(String.format("%s <b>Procure a caixa %s %s %s</b>\n\n",
                    emojiCor,
                    med.getCorCaixa() != null ? med.getCorCaixa().toUpperCase() : "",
                    tipoIdentificador,
                    identificador));
        }

        msg.append(String.format("💊 <i>Remédio: %s (%s %s)</i>",
                med.getNome(),
                quantidadeDose,
                med.getUnidade().name().toLowerCase()));

        return msg.toString();
    }

    private String obterEmojiCor(String cor) {
        if (cor == null) return "📦";
        return switch (cor.toUpperCase().trim()) {
            case "VERMELHO" -> "🟥";
            case "LARANJA"  -> "🟧";
            case "AMARELO"  -> "🟨";
            case "VERDE"    -> "🟩";
            case "AZUL"     -> "🟦";
            case "ROXO"     -> "🟪";
            case "MARROM"   -> "🟫";
            case "BRANCO"   -> "⬜";
            case "PRETO"    -> "⬛";
            default         -> "📦";
        };
    }

    private void notificarFamiliarAtraso(Dose dose) {
        Familiar familiar = dose.getMedicamento().getIdoso().getFamiliar();
        if (familiar != null && familiar.getTelegramChatId() != null) {
            String msgFamiliar = String.format(
                    "🚨 ATENÇÃO: O idoso %s NÃO confirmou a dose do medicamento '%s' programada para as %s!",
                    dose.getMedicamento().getIdoso().getNome(),
                    dose.getMedicamento().getNome(),
                    dose.getHorarioProgramado().toLocalTime().format(DateTimeFormatter.ofPattern("HH:mm"))
            );
            telegramService.enviarNotificacao(familiar.getTelegramChatId(), msgFamiliar);
        }
    }
}