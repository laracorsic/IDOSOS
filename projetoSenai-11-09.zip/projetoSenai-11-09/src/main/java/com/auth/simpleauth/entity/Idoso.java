package com.auth.simpleauth.entity;

import com.auth.simpleauth.enums.Perfil;
import jakarta.persistence.*;

import java.util.ArrayList;
import java.util.List;

@Entity
@DiscriminatorValue("IDOSO")
public class Idoso extends Usuario {

    @ManyToOne
    @JoinColumn(name = "id_familiar", nullable = true)
    private Familiar familiar;

    @OneToMany(mappedBy = "idoso")
    private List<Medicamento> medicamentos = new ArrayList<>();

    public Idoso() {
        super();
        setPerfil(Perfil.IDOSO);
    }

    public Idoso(String nome, String email, String senha, String telefone, String telegramChatId, Familiar familiar) {
        super(nome, email, senha, telefone, telegramChatId, Perfil.IDOSO);
        this.familiar = familiar;
    }


    public Familiar getFamiliar() { return familiar; }
    public void setFamiliar(Familiar familiar) { this.familiar = familiar; }

    public List<Medicamento> getMedicamentos() { return medicamentos; }
    public void setMedicamentos(List<Medicamento> medicamentos) { this.medicamentos = medicamentos; }
}