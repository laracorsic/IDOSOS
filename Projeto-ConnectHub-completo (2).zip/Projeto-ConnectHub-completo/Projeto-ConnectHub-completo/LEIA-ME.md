# ConnectHub — projeto completo

Este pacote reúne as duas pastas completas do projeto: `Projeto/connecthub-frontend-webpush-atualizado` e `Projeto/connecthub-backend-webpush-atualizado`. Inclui as correções recentes no chat Zelo (renderização segura das formatações Markdown) e no endpoint de teste Web Push (resposta HTTP 200 somente após aceitação do provedor).

## Estrutura

- `Projeto/connecthub-frontend-webpush-atualizado/`: páginas, CSS, JavaScript, service worker e instruções do frontend.
- `Projeto/connecthub-backend-webpush-atualizado/`: aplicação Spring Boot, fontes, Maven Wrapper e recursos do backend.

## Executar

- Backend: use Java 21 e execute `./mvnw spring-boot:run` dentro da pasta do backend. Configure `SPRING_DATASOURCE_URL`, `SPRING_DATASOURCE_USERNAME`, `SPRING_DATASOURCE_PASSWORD` para o banco usado. Para respostas generativas do Zelo, configure também `ASSISTENTE_IA_CHAVE`.
- Frontend local: sirva a pasta por HTTP (não abra com `file://`), por exemplo `python -m http.server 5500`, e acesse `http://localhost:5500/index.html`. Consulte também `INSTRUCOES-WEBPUSH-E-ZELO.md`.

## Web Push e confirmação

O endpoint de teste agora espera a resposta do provedor de push e retorna HTTP 200 se algum provedor aceitar o envio. Isso não confirma que o Windows exibiu o aviso nem que a pessoa o viu; a exibição depende do navegador, permissões, conectividade e configurações do dispositivo.

## Credenciais

Valores de senha e chave de IA que estavam gravados no arquivo original foram removidos desta cópia. Configure-os como variáveis de ambiente antes de conectar a bancos ou serviços externos. Se as credenciais antigas já foram usadas fora do ambiente local, rotacione-as.

## Validação

O ZIP e a estrutura foram verificados. Não foi possível compilar aqui porque o ambiente de execução não disponibiliza JDK 21; compile/deploy com Java 21.
