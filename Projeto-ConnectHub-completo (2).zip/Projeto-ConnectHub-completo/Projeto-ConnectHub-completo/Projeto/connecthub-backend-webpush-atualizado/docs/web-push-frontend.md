# Integração do Web Push no frontend

O ZIP recebido contém somente o backend. Para as notificações aparecerem mesmo com a página fechada, o frontend precisa registrar um service worker no mesmo domínio do app. Depois da primeira autorização, o app pode sincronizar e renovar a inscrição automaticamente ao entrar, sem novo pedido de permissão. O navegador não permite conceder a permissão silenciosamente: na primeira vez, a pessoa precisa tocar uma vez em um botão simples como “Ativar lembretes” e confirmar no próprio navegador. O backend envia lembretes sem depender de Telegram, bots ou tokens Telegram.

## 1. Chaves VAPID automáticas

Não é preciso gerar nem cadastrar chaves manualmente. Na primeira inicialização do backend, o sistema cria um par VAPID e grava uma única cópia na tabela `tbl_web_push_vapid_key` do banco já usado pelo app. Nas próximas inicializações, reutiliza exatamente o mesmo par. A chave privada não fica hard-coded no repositório e não é enviada ao navegador; o endpoint `GET /notificacoes/push/configuracao` entrega somente a chave pública.

Para manter as inscrições funcionando, o banco de dados precisa preservar essa tabela entre reinicializações e deploys. Se ela for apagada junto com o banco, um novo par será gerado e os usuários terão de criar inscrições novamente. Restrinja o acesso administrativo ao banco, pois a tabela contém a chave privada de assinatura do servidor.

## 2. Adicionar o service worker

Crie `public/service-worker.js` no frontend. Para projetos Vite/React, o arquivo na pasta `public` ficará disponível em `/service-worker.js`.

```javascript
self.addEventListener("push", (event) => {
  let data = {};
  try {
    data = event.data ? event.data.json() : {};
  } catch {
    data = { body: event.data ? event.data.text() : "" };
  }

  event.waitUntil(self.registration.showNotification(data.title || "ConnectHub", {
    body: data.body || "Você tem um novo lembrete.",
    icon: "/favicon.ico",
    badge: "/favicon.ico",
    tag: data.tag || "connecthub-notificacao",
    data: { url: data.url || "/" }
  }));
});

self.addEventListener("notificationclick", (event) => {
  event.notification.close();
  const url = new URL(event.notification.data?.url || "/", self.location.origin).href;
  event.waitUntil((async () => {
    const windows = await self.clients.matchAll({ type: "window", includeUncontrolled: true });
    for (const client of windows) {
      if ("focus" in client) {
        await client.focus();
        if ("navigate" in client) await client.navigate(url);
        return;
      }
    }
    if (self.clients.openWindow) await self.clients.openWindow(url);
  })());
});
```

## 3. Ativação inicial simples e sincronização automática

Configure `API` com a URL pública real do backend. No login, chame `sincronizarNotificacoes()`; ela registra o service worker e, se a permissão já foi concedida, atualiza a inscrição no servidor sem mostrar novos avisos. Se a permissão ainda estiver como `default`, mostre uma única ação clara ao familiar/cuidador ou ao usuário — por exemplo, “Ativar lembretes de remédios e eventos”. O clique chama `ativarNotificacoes()` e o navegador apresenta seu próprio botão de autorização. Se a permissão estiver negada, não repita o pedido: a pessoa precisa liberar nas configurações do navegador.

```javascript
const API = "https://SUA-API-BACKEND";

function base64UrlToBytes(value) {
  const padding = "=".repeat((4 - value.length % 4) % 4);
  const base64 = (value + padding).replace(/-/g, "+").replace(/_/g, "/");
  return Uint8Array.from(atob(base64), (character) => character.charCodeAt(0));
}

async function enviarInscricao(subscription) {
  const response = await fetch(`${API}/notificacoes/push/inscricoes`, {
    method: "POST",
    credentials: "include",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(subscription.toJSON())
  });
  if (!response.ok) throw new Error("Não foi possível salvar a inscrição de notificações.");
}

// Chame esta função somente pelo evento de clique de “Ativar lembretes”.
export async function ativarNotificacoes() {
  if (!("serviceWorker" in navigator) || !("PushManager" in window) || !("Notification" in window)) {
    throw new Error("Este navegador não oferece suporte a notificações push.");
  }

  // Deve ser chamado antes de qualquer await para preservar o gesto do usuário.
  const permissionPromise = Notification.requestPermission();
  const permission = await permissionPromise;
  if (permission !== "granted") throw new Error("A permissão para notificações não foi concedida.");

  const resposta = await fetch(`${API}/notificacoes/push/configuracao`, { credentials: "include" });
  if (!resposta.ok) throw new Error("Não foi possível consultar a configuração de notificações.");
  const configuracao = await resposta.json();
  if (!configuracao.enabled || !configuracao.publicKey) {
    throw new Error("O Web Push ainda não foi configurado no backend.");
  }

  const registration = await navigator.serviceWorker.register("/service-worker.js");
  let subscription = await registration.pushManager.getSubscription();
  if (!subscription) {
    subscription = await registration.pushManager.subscribe({
      userVisibleOnly: true,
      applicationServerKey: base64UrlToBytes(configuracao.publicKey)
    });
  }
  await enviarInscricao(subscription);
  return true;
}

// Chame automaticamente após login/carregamento do app.
export async function sincronizarNotificacoes() {
  if (!("serviceWorker" in navigator) || !("PushManager" in window) || !("Notification" in window)) return;
  const registration = await navigator.serviceWorker.register("/service-worker.js");
  if (Notification.permission !== "granted") return;
  const subscription = await registration.pushManager.getSubscription();
  if (subscription) {
    await enviarInscricao(subscription);
  } else {
    const resposta = await fetch(`${API}/notificacoes/push/configuracao`, { credentials: "include" });
    const configuracao = await resposta.json();
    if (!configuracao.enabled || !configuracao.publicKey) return;
    const novaInscricao = await registration.pushManager.subscribe({
      userVisibleOnly: true,
      applicationServerKey: base64UrlToBytes(configuracao.publicKey)
    });
    await enviarInscricao(novaInscricao);
  }
}
```

Todas as chamadas usam `credentials: "include"` porque as rotas guardam a inscrição na sessão autenticada da conta. As rotas implementadas são `GET /notificacoes/push/configuracao`, `POST /notificacoes/push/inscricoes`, `GET /notificacoes/push/inscricoes/status` e `DELETE /notificacoes/push/inscricoes`.

## 4. Aba Eventos

O backend incluído não possui entidade, tabela nem rotas para compromissos; o `EventoSchedulerService` atual é apenas um esqueleto vazio. Portanto, ainda não há dados de eventos que o backend possa agendar ou notificar. Para ligar as notificações à aba Eventos, é necessário conectar a tela à API de eventos (ou fornecer o frontend e sua estrutura de dados para implementar essa ligação sem presumir campos ou horários). Depois que os eventos forem salvos no backend com data/hora, o mesmo Web Push poderá notificar a conta vinculada sem Telegram.

## Limites que não podem ser prometidos como “vitalícios”

A integração não tem tarifa por notificação nem exige renovar um token de Telegram. A permissão costuma permanecer salva no navegador. Ainda assim, navegador ou sistema operacional podem limpar dados ou expirar inscrições, e a pessoa pode revogar a permissão. O envio também depende de o backend e o banco continuarem hospedados e disponíveis. Nenhuma implementação consegue garantir entrega vitalícia, e mudanças nas chaves VAPID invalidam inscrições anteriores.
