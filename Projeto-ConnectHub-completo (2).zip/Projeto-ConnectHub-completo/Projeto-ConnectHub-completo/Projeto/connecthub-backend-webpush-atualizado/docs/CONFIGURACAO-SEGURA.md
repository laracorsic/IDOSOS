# Executar localmente sem configurar variáveis no IntelliJ

O perfil padrão usa H2 em arquivo local (`connecthub-local.mv.db`) no modo de compatibilidade PostgreSQL. Basta abrir o projeto e executar `SimpleAuthApplication`; não é necessário preencher variáveis em **Run → Edit Configurations** nem instalar um servidor de banco. Os dados desse banco ficam no computador e continuam disponíveis depois de reiniciar a aplicação.

Esse banco local é independente do PostgreSQL do Render: dados criados localmente não aparecem no site publicado. Em produção, o Render continua usando PostgreSQL pelas variáveis `SPRING_DATASOURCE_URL`, `SPRING_DATASOURCE_USERNAME` e `SPRING_DATASOURCE_PASSWORD`, que sobrescrevem os padrões locais.

O perfil opcional `local` que já existia usa MySQL instalado localmente; não o ative se quiser iniciar sem configuração.

A chave do assistente de IA não é necessária para iniciar o backend. Sem `ASSISTENTE_IA_CHAVE`, o assistente usa as respostas locais limitadas.

O arquivo de banco local é ignorado pelo Git. Como credenciais do arquivo original foram compartilhadas, revogue-as e gere novas; não coloque novas credenciais no código ou em repositórios.
