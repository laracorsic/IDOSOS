# Assistente de IA Zelo no ConnectHub

O backend agora oferece a API do assistente em `/assistente/status` e `/assistente/conversar`, com conversa em português, respostas locais de contingência, entrada/saída por voz no widget e consulta de clima via Open-Meteo. As rotas da API usam a sessão autenticada existente do ConnectHub. Os arquivos de interface são publicados em `/zelo/assistente.js` e `/zelo/assistente.css`.

## Configurar o provedor de IA

A chave que veio embutida no `application.properties` do projeto Zelo anexado **não foi copiada** para o ConnectHub. Como ela estava exposta no código enviado, revogue-a no painel da Groq e crie uma nova.

No ambiente do backend, cadastre a nova chave como segredo `ASSISTENTE_IA_CHAVE`. O endpoint/modelo já têm valores padrão no `application.properties`; não coloque a chave no Git, em `application.properties`, no frontend nem no navegador. Opcionalmente, `ASSISTENTE_IA_URL`, `ASSISTENTE_IA_MODELO` e `ASSISTENTE_IA_REVISOR_ATIVO` podem sobrescrever os padrões. Sem chave, o assistente continua disponível com respostas locais limitadas, mas não haverá conversa generativa.

## Carregar o widget no frontend

O frontend ConnectHub não estava incluído nos ZIPs recebidos. Nas páginas autenticadas ou no layout compartilhado do frontend, adicione o seguinte carregamento, substituindo `https://URL-REAL-DO-BACKEND` pela URL pública do backend:

```html
<link rel="stylesheet" href="https://URL-REAL-DO-BACKEND/zelo/assistente.css">
<script>
  window.CONNECTHUB_API_BASE_URL = "https://URL-REAL-DO-BACKEND";
  // Opcional: URLs reais do frontend para permitir que o widget navegue.
  // Sem este mapa, Zelo orienta a pessoa a usar o menu e não finge ter navegado.
  window.CONNECTHUB_ZELO_DESTINATIONS = {
    remedios: "/caminho-real-da-tela-de-remedios",
    familia: "/caminho-real-da-tela-de-familia",
    medico: "/caminho-real-da-tela-de-medico",
    jogos: "/caminho-real-da-tela-de-jogos",
    inicio: "/"
  };
</script>
<script src="https://URL-REAL-DO-BACKEND/zelo/assistente.js" defer></script>
```

Remova do mapa as rotas que não existirem no frontend. Carregue CSS e JavaScript uma única vez pelo layout global. A interface não abre nem fala automaticamente ao carregar; a pessoa toca no botão “Falar com Zelo”. O microfone depende da permissão do navegador. As requisições de status e conversa usam `credentials: "include"` e, portanto, precisam ocorrer depois do login.

## Privacidade e limites

A integração não grava o histórico da conversa no banco. Para respostas com IA, envia ao provedor a mensagem atual, até oito mensagens recentes e o título da página; não envia o texto integral da tela. Mesmo assim, as mensagens conversacionais são processadas pelo provedor Groq. Oriente as pessoas a não enviarem senhas, códigos, dados bancários ou informações de saúde que não sejam necessárias. O assistente não substitui um profissional de saúde nem deve diagnosticar, prescrever ou alterar doses. A consulta do clima usa o serviço público Open-Meteo e requer conexão à internet.

A rota `/assistente/**` permanece protegida pelo interceptor de sessão do ConnectHub. Somente `/zelo/**` (os arquivos estáticos do widget) foi liberada para que o navegador consiga baixá-los antes de chamar as rotas autenticadas.
