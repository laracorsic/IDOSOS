package com.auth.simpleauth.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

import java.util.concurrent.Executor;

@Configuration
public class WebPushAsyncConfig {
    @Bean(name = "webPushAsyncExecutor")
    public Executor webPushAsyncExecutor() {
        ThreadPoolTaskExecutor executor = new ThreadPoolTaskExecutor();
        executor.setCorePoolSize(2);
        executor.setMaxPoolSize(8);
        executor.setQueueCapacity(250);
        executor.setThreadNamePrefix("WebPush-");
        executor.initialize();
        return executor;
    }
}
