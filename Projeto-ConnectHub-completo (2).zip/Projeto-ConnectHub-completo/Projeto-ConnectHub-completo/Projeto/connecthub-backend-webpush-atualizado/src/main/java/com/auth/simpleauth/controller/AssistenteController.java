package com.auth.simpleauth.controller;

import com.auth.simpleauth.service.ClimaAssistenteService;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestClient;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

@RestController
@RequestMapping("/assistente")
public class AssistenteController {
    private static final String SYSTEM_PROMPT = """
            Você é Zelo, um companheiro inteligente para pessoas idosas, falando português do Brasil.
            Interprete a intenção mesmo com erros de digitação, frases curtas e linguagem informal.
            Converse com naturalidade, acolhimento, paciência e respeito, sem infantilizar.
            Faça perguntas de esclarecimento quando faltar uma informação necessária.
            Use consultar_clima se perguntarem sobre tempo, temperatura, chuva ou condições para sair; não adivinhe a previsão.
            Para navegação, diga qual área a pessoa pode abrir, mas nunca afirme que abriu ou executou uma ação.
            Para remédios e saúde, dê apenas orientação geral; nunca diagnostique, prescreva ou altere doses.
            Em emergências, recomende ajuda humana imediata e o botão de socorro.
            Não peça senhas, códigos, dados bancários ou informações pessoais desnecessárias.
            Responda em até três parágrafos curtos e simples.
            """;

    private final ObjectMapper objectMapper;
    private final RestClient restClient;
    private final ClimaAssistenteService climaService;

    @Value("${assistente.ia.url:https://api.groq.com/openai/v1/chat/completions}")
    private String iaUrl;
    @Value("${assistente.ia.chave:}")
    private String iaChave;
    @Value("${assistente.ia.modelo:openai/gpt-oss-120b}")
    private String iaModelo;
    @Value("${assistente.ia.revisor.ativo:false}")
    private boolean revisorAtivo;

    public AssistenteController(ObjectMapper objectMapper, ClimaAssistenteService climaService) {
        this.objectMapper = objectMapper;
        this.restClient = RestClient.builder().build();
        this.climaService = climaService;
    }

    public record HistoricoMensagem(String role, String content) {}
    public record ConversaRequest(String message, String pageTitle, String pageContext, List<HistoricoMensagem> history) {}

    @GetMapping("/status")
    public ResponseEntity<Map<String, Object>> status() {
        boolean configurada = iaConfigurada();
        return ResponseEntity.ok(Map.of(
                "configurada", configurada,
                "agenteComFerramentas", configurada,
                "climaDisponivel", true,
                "modelo", iaModelo,
                "mensagem", configurada
                        ? "Zelo está pronto para conversar."
                        : "Zelo está no modo acolhedor local; configure a chave Groq no ambiente para conversa aberta."
        ));
    }

    @PostMapping(value = "/conversar", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Map<String, Object>> conversar(@RequestBody(required = false) ConversaRequest request) {
        String pergunta = limitar(textoSeguro(request == null ? null : request.message()), 1200);
        if (pergunta.isBlank()) {
            return ResponseEntity.badRequest().body(Map.of("reply", "Pode falar comigo. Estou ouvindo você.", "source", "validacao"));
        }
        if (!iaConfigurada()) return ResponseEntity.ok(respostaLocal(pergunta));

        try {
            List<Map<String, Object>> mensagens = new ArrayList<>();
            mensagens.add(mensagem("system", SYSTEM_PROMPT));
            if (request.history() != null) {
                List<HistoricoMensagem> historico = request.history().stream()
                        .filter(item -> item != null && item.content() != null).toList();
                historico.stream().skip(Math.max(0, historico.size() - 8L)).limit(8)
                        .forEach(item -> mensagens.add(mensagem(
                                "assistant".equalsIgnoreCase(item.role()) ? "assistant" : "user",
                                limitar(textoSeguro(item.content()), 800))));
            }
            // Por privacidade, não enviamos o texto da tela ou dados de saúde em pageContext.
            String secao = limitar(textoSeguro(request.pageTitle()), 120);
            if (!secao.isBlank()) mensagens.add(mensagem("system", "Área do aplicativo: " + secao));
            mensagens.add(mensagem("user", pergunta));

            String resposta = executarAgente(mensagens);
            if (resposta.isBlank()) resposta = "Não consegui formular uma resposta agora. Pode explicar de outro jeito?";
            return ResponseEntity.ok(Map.of("reply", limitar(resposta, 1800), "source", "ia-agente", "model", iaModelo, "available", true));
        } catch (Exception ex) {
            return ResponseEntity.ok(Map.of(
                    "reply", "Tive uma dificuldade momentânea para pensar na resposta. Ainda estou aqui com você; tente novamente em alguns instantes.",
                    "source", "contingencia", "available", true));
        }
    }

    private String executarAgente(List<Map<String, Object>> mensagens) throws Exception {
        JsonNode respostaInicial = objectMapper.readTree(chamarIA(payload(mensagens)));
        JsonNode escolha = respostaInicial.path("choices").path(0).path("message");
        JsonNode chamadas = escolha.path("tool_calls");
        if (!chamadas.isArray() || chamadas.isEmpty()) return revisarResposta(textoDaMensagem(escolha), mensagens);

        mensagens.add(mensagemComChamadas(escolha));
        for (JsonNode chamada : chamadas) {
            String nome = chamada.path("function").path("name").asText();
            String argumentos = chamada.path("function").path("arguments").asText("{}");
            String resultado = executarFerramenta(nome, objectMapper.readTree(argumentos));
            Map<String, Object> ferramenta = new HashMap<>();
            ferramenta.put("role", "tool");
            ferramenta.put("tool_call_id", chamada.path("id").asText());
            ferramenta.put("content", resultado);
            mensagens.add(ferramenta);
        }
        JsonNode respostaFinal = objectMapper.readTree(chamarIA(payload(mensagens)));
        return revisarResposta(textoDaMensagem(respostaFinal.path("choices").path(0).path("message")), mensagens);
    }

    private String revisarResposta(String rascunho, List<Map<String, Object>> mensagens) throws Exception {
        if (!revisorAtivo || rascunho.isBlank()) return rascunho;
        String pergunta = "";
        for (int i = mensagens.size() - 1; i >= 0; i--) {
            if ("user".equals(mensagens.get(i).get("role"))) {
                pergunta = String.valueOf(mensagens.get(i).get("content"));
                break;
            }
        }
        List<Map<String, Object>> revisao = new ArrayList<>();
        revisao.add(mensagem("system", "Você é o revisor final do Zelo. Preserve fatos e números. Corrija apenas erros, contradições, excesso de texto ou linguagem difícil. Não invente informações. Retorne somente a resposta em português do Brasil, em até três parágrafos curtos."));
        revisao.add(mensagem("user", "Pergunta original: " + limitar(pergunta, 1200) + "\n\nRascunho:\n" + limitar(rascunho, 1800)));
        Map<String, Object> pedido = new HashMap<>();
        pedido.put("model", iaModelo);
        pedido.put("messages", revisao);
        pedido.put("temperature", 0.2);
        pedido.put("max_tokens", 400);
        String corpo = chamarIA(pedido);
        String finalizado = textoDaMensagem(objectMapper.readTree(corpo).path("choices").path(0).path("message"));
        return finalizado.isBlank() ? rascunho : finalizado;
    }

    private String chamarIA(Map<String, Object> payload) {
        return restClient.post().uri(iaUrl)
                .contentType(MediaType.APPLICATION_JSON)
                .header("Authorization", "Bearer " + iaChave)
                .body(payload)
                .retrieve().body(String.class);
    }

    private Map<String, Object> payload(List<Map<String, Object>> mensagens) {
        Map<String, Object> payload = new HashMap<>();
        payload.put("model", iaModelo);
        payload.put("messages", mensagens);
        payload.put("tools", ferramentas());
        payload.put("tool_choice", "auto");
        payload.put("temperature", 0.5);
        payload.put("max_tokens", 600);
        return payload;
    }

    private List<Map<String, Object>> ferramentas() {
        Map<String, Object> funcao = new HashMap<>();
        funcao.put("name", "consultar_clima");
        funcao.put("description", "Consulta as condições meteorológicas atuais e a previsão para uma cidade. Use quando perguntarem sobre clima, tempo, temperatura, chuva ou se deve sair.");
        funcao.put("parameters", Map.of("type", "object", "properties", Map.of(
                "cidade", Map.of("type", "string", "description", "Nome da cidade, preferencialmente com estado e país")),
                "required", List.of("cidade"), "additionalProperties", false));
        return List.of(Map.of("type", "function", "function", funcao));
    }

    private String executarFerramenta(String nome, JsonNode argumentos) {
        if ("consultar_clima".equals(nome)) return climaService.previsao(argumentos.path("cidade").asText(""));
        return "Ferramenta não disponível. Responda sem inventar dados.";
    }

    private Map<String, Object> mensagem(String role, String content) { return Map.of("role", role, "content", content); }

    private Map<String, Object> mensagemComChamadas(JsonNode message) {
        Map<String, Object> resultado = new HashMap<>();
        resultado.put("role", "assistant");
        resultado.put("content", message.path("content").isNull() ? "" : message.path("content").asText(""));
        resultado.put("tool_calls", objectMapper.convertValue(message.path("tool_calls"), Object.class));
        return resultado;
    }

    private String textoDaMensagem(JsonNode message) {
        JsonNode content = message.path("content");
        return content.isTextual() ? content.asText().trim() : "";
    }

    private Map<String, Object> respostaLocal(String pergunta) {
        String texto = normalizar(pergunta);
        String resposta;
        if (texto.contains("socorro") || texto.contains("emergencia") || texto.contains("perigo")) {
            resposta = "Se você está em perigo ou passou mal, procure ajuda humana imediatamente e use o botão de socorro.";
        } else if (texto.contains("como voce esta") || texto.contains("como vc esta") || texto.contains("voce esta bem") || texto.contains("vc esta bem")) {
            resposta = "Estou bem e contente por conversar com você. Obrigado por perguntar. E você, como está se sentindo hoje?";
        } else if (texto.contains("o que voce pode") || texto.contains("o que posso perguntar")) {
            resposta = "Você pode conversar comigo, perguntar sobre o tempo, pedir ajuda com o aplicativo ou falar sobre como está se sentindo.";
        } else if (texto.contains("previsao") || texto.contains("temperatura") || texto.contains("clima") || texto.contains("vai chover")) {
            resposta = "Posso consultar o tempo quando a IA estiver conectada. Diga a cidade e o estado, por exemplo: previsão em São Carlos, SP.";
        } else if (texto.contains("hora")) {
            resposta = "Agora são " + LocalDateTime.now().format(DateTimeFormatter.ofPattern("HH 'horas e' mm 'minutos'")) + ".";
        } else if (texto.contains("data") || texto.contains("que dia")) {
            resposta = "Hoje é " + LocalDateTime.now().format(DateTimeFormatter.ofPattern("EEEE, dd/MM/yyyy", new Locale("pt", "BR"))) + ".";
        } else if (texto.contains("convers") || texto.contains("companhia") || texto.contains("papo")) {
            resposta = "Estou aqui com você. Podemos conversar sobre seu dia, suas lembranças, sua família ou qualquer assunto que queira compartilhar.";
        } else {
            resposta = "Estou aqui com você. Para conversar livremente, preciso estar conectado ao serviço de IA. Enquanto isso, posso responder algumas perguntas simples.";
        }
        return Map.of("reply", resposta, "source", "local", "available", true);
    }

    private String normalizar(String valor) {
        return java.text.Normalizer.normalize(textoSeguro(valor).toLowerCase(Locale.ROOT), java.text.Normalizer.Form.NFD)
                .replaceAll("\\p{M}", "");
    }
    private String textoSeguro(String valor) { return valor == null ? "" : valor.trim(); }
    private String limitar(String valor, int tamanho) { return valor.length() <= tamanho ? valor : valor.substring(0, tamanho); }
    private boolean iaConfigurada() { return iaUrl != null && !iaUrl.isBlank() && iaChave != null && !iaChave.isBlank(); }
}
