package com.auth.simpleauth.repository;

import com.auth.simpleauth.entity.WebPushVapidKey;
import org.springframework.data.jpa.repository.JpaRepository;

public interface WebPushVapidKeyRepository extends JpaRepository<WebPushVapidKey, Long> {}
