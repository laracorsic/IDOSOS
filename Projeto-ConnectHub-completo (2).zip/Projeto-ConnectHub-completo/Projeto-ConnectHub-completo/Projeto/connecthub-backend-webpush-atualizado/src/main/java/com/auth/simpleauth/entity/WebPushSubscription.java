package com.auth.simpleauth.entity;

import jakarta.persistence.*;

@Entity
@Table(name = "tbl_web_push_subscription")
public class WebPushSubscription {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "usuario_id", nullable = false)
    private Usuario usuario;

    @Column(name = "endpoint_hash", nullable = false, unique = true, length = 64)
    private String endpointHash;

    @Lob
    @Column(name = "endpoint", nullable = false, columnDefinition = "TEXT")
    private String endpoint;

    @Column(name = "p256dh", nullable = false, length = 256)
    private String p256dh;

    @Column(name = "auth_secret", nullable = false, length = 256)
    private String auth;

    protected WebPushSubscription() {}

    public WebPushSubscription(Usuario usuario, String endpointHash, String endpoint, String p256dh, String auth) {
        this.usuario = usuario;
        this.endpointHash = endpointHash;
        this.endpoint = endpoint;
        this.p256dh = p256dh;
        this.auth = auth;
    }

    public Long getId() { return id; }
    public Usuario getUsuario() { return usuario; }
    public String getEndpointHash() { return endpointHash; }
    public String getEndpoint() { return endpoint; }
    public String getP256dh() { return p256dh; }
    public String getAuth() { return auth; }

    public void atualizar(Usuario usuario, String endpoint, String p256dh, String auth) {
        this.usuario = usuario;
        this.endpoint = endpoint;
        this.p256dh = p256dh;
        this.auth = auth;
    }
}
