package com.auth.simpleauth.repository;

import com.auth.simpleauth.entity.WebPushSubscription;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface WebPushSubscriptionRepository extends JpaRepository<WebPushSubscription, Long> {
    Optional<WebPushSubscription> findByEndpointHash(String endpointHash);
    List<WebPushSubscription> findByUsuarioId(Long usuarioId);
    boolean existsByUsuarioId(Long usuarioId);
    void deleteByEndpointHash(String endpointHash);
    void deleteByUsuarioIdAndEndpointHash(Long usuarioId, String endpointHash);
}
