package com.auth.simpleauth.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "tbl_web_push_vapid_key")
public class WebPushVapidKey {
    @Id
    private Long id;

    @Column(name = "public_key", nullable = false, length = 128)
    private String publicKey;

    @Column(name = "private_key", nullable = false, length = 128)
    private String privateKey;

    protected WebPushVapidKey() {}

    public WebPushVapidKey(Long id, String publicKey, String privateKey) {
        this.id = id;
        this.publicKey = publicKey;
        this.privateKey = privateKey;
    }

    public String getPublicKey() { return publicKey; }
    public String getPrivateKey() { return privateKey; }
}
