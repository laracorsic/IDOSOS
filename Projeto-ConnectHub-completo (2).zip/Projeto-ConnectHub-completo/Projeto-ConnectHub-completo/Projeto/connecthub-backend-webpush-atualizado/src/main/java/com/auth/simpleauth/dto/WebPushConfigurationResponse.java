package com.auth.simpleauth.dto;

public record WebPushConfigurationResponse(boolean enabled, String publicKey) {}
