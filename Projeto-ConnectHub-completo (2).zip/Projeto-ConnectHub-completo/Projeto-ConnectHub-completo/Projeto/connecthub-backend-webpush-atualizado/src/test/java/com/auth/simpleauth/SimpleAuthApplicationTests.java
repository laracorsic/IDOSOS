package com.auth.simpleauth;

import com.auth.simpleauth.service.WebPushNotificationService;
import com.auth.simpleauth.controller.AssistenteController;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

@SpringBootTest(properties = "assistente.ia.chave=")
class SimpleAuthApplicationTests {
    @Autowired
    private WebPushNotificationService webPushNotificationService;
    @Autowired
    private AssistenteController assistenteController;

    @Test
    void contextLoads() {
    }

    @Test
    void vapidKeyIsCreatedAutomaticallyAndPublicPartIsAvailable() {
        assertTrue(webPushNotificationService.isEnabled());
        assertNotNull(webPushNotificationService.getPublicKey());
        assertTrue(webPushNotificationService.getPublicKey().length() > 40);
    }

    @Test
    void assistantReturnsLocalFallbackWithoutProviderSecret() {
        var response = assistenteController.conversar(
                new AssistenteController.ConversaRequest("Que horas são?", "ConnectHub", null, List.of()));
        assertEquals(200, response.getStatusCode().value());
        assertEquals("local", response.getBody().get("source"));
        assertTrue(((String) response.getBody().get("reply")).contains("Agora são"));
    }

}
