import { API_BASE_URL } from './config.js';

const api = `${API_BASE_URL}/notificacoes/push`;
const statusNode = document.getElementById('statusNotificacoesPush');
const activateButton = document.getElementById('btnAtivarNotificacoesPush');
const testButton = document.getElementById('btnTestarNotificacoesPush');

function showStatus(message, state = 'info') {
  if (!statusNode) return;
  statusNode.textContent = message;
  statusNode.dataset.state = state;
}

function vapidKeyBytes(value) {
  const padding = '='.repeat((4 - value.length % 4) % 4);
  const base64 = (value + padding).replace(/-/g, '+').replace(/_/g, '/');
  return Uint8Array.from(atob(base64), character => character.charCodeAt(0));
}

async function fetchWithTimeout(url, options = {}, timeoutMs = 12000) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    return await fetch(url, { ...options, signal: controller.signal });
  } catch (error) {
    if (error.name === 'AbortError') {
      throw new Error('O servidor demorou para responder. Tente novamente em alguns segundos.');
    }
    if (error instanceof TypeError) {
      throw new Error('Não foi possível conectar ao servidor. Verifique a internet e o endereço do site.');
    }
    throw error;
  } finally {
    clearTimeout(timer);
  }
}

async function errorMessage(response, fallback) {
  const text = await response.text();
  if (response.status === 401 || response.status === 403) {
    return 'Sua sessão expirou. Saia da conta, entre novamente e tente ativar as notificações.';
  }
  if (response.status === 409) return text || 'Ative as notificações antes de enviar um teste.';
  return text || `${fallback} (HTTP ${response.status})`;
}

async function loadServerStatus() {
  const response = await fetchWithTimeout(`${api}/inscricoes/status`, { credentials: 'include' });
  if (!response.ok) throw new Error(await errorMessage(response, 'Não foi possível consultar a inscrição'));
  return response.json();
}

export async function initializeWebPushControls() {
  if (!activateButton || !testButton || !statusNode || activateButton.dataset.initialized === 'true') return;
  activateButton.dataset.initialized = 'true';

  const supported = 'serviceWorker' in navigator && 'PushManager' in window && 'Notification' in window;
  if (!supported) {
    activateButton.disabled = true;
    testButton.disabled = true;
    showStatus('Este navegador não oferece suporte a notificações push. Use Chrome, Edge ou Firefox atualizado.', 'error');
    return;
  }
  if (!window.isSecureContext) {
    activateButton.disabled = true;
    testButton.disabled = true;
    showStatus('Push requer HTTPS (ou localhost). Abra o site por uma origem segura.', 'error');
    return;
  }

  let readyToTest = false;
  let registration;

  const refresh = async () => {
    showStatus('Verificando inscrição neste navegador...');
    registration = await navigator.serviceWorker.register('/service-worker.js', { scope: '/' });
    registration = await navigator.serviceWorker.ready;
    const localSubscription = await registration.pushManager.getSubscription();
    const remoteStatus = await loadServerStatus();
    readyToTest = Boolean(remoteStatus.inscrito && localSubscription);
    testButton.disabled = !readyToTest;

    if (Notification.permission === 'denied') {
      showStatus('As notificações estão bloqueadas. Clique no ícone de cadeado/configurações ao lado do endereço e permita notificações.', 'error');
    } else if (readyToTest) {
      showStatus('Notificações ativas neste navegador. Você pode enviar um teste.', 'success');
      activateButton.textContent = 'Atualizar inscrição';
    } else if (localSubscription && !remoteStatus.inscrito) {
      showStatus('A inscrição existe no navegador, mas ainda não foi vinculada à conta. Clique em Atualizar inscrição.', 'info');
      activateButton.textContent = 'Atualizar inscrição';
    } else {
      showStatus('Notificações ainda não estão ativas neste navegador.', 'info');
      activateButton.textContent = 'Ativar notificações';
    }
  };

  activateButton.addEventListener('click', async () => {
    activateButton.disabled = true;
    testButton.disabled = true;
    activateButton.setAttribute('aria-busy', 'true');
    try {
      if (Notification.permission === 'denied') {
        throw new Error('A permissão está bloqueada. Clique no cadeado ao lado do endereço, permita notificações e tente novamente.');
      }
      if (Notification.permission !== 'granted') {
        showStatus('Aguardando sua autorização para mostrar notificações...');
        const permission = await Notification.requestPermission();
        if (permission !== 'granted') {
          throw new Error(permission === 'denied'
            ? 'Permissão bloqueada. Libere as notificações nas configurações do navegador.'
            : 'Permissão não concedida. Clique em Ativar novamente quando estiver pronto.');
        }
      }

      showStatus('Conectando ao servidor de notificações...');
      const configResponse = await fetchWithTimeout(`${api}/configuracao`, { credentials: 'include' });
      if (!configResponse.ok) throw new Error(await errorMessage(configResponse, 'Falha ao consultar configuração Web Push'));
      const config = await configResponse.json();
      if (!config.enabled || !config.publicKey) throw new Error('O Web Push ainda não está habilitado no servidor.');

      showStatus('Preparando este navegador...');
      registration = await navigator.serviceWorker.register('/service-worker.js', { scope: '/' });
      registration = await navigator.serviceWorker.ready;
      let subscription = await registration.pushManager.getSubscription();
      if (!subscription) {
        subscription = await registration.pushManager.subscribe({
          userVisibleOnly: true,
          applicationServerKey: vapidKeyBytes(config.publicKey)
        });
      }

      showStatus('Salvando a inscrição na sua conta...');
      const saveResponse = await fetchWithTimeout(`${api}/inscricoes`, {
        method: 'POST',
        credentials: 'include',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(subscription.toJSON())
      });
      if (!saveResponse.ok) throw new Error(await errorMessage(saveResponse, 'Não foi possível salvar a inscrição'));

      await refresh();
      showStatus('Notificações ativadas com sucesso. Agora você pode enviar um teste.', 'success');
    } catch (error) {
      console.error('Falha na ativação do Web Push:', error);
      const detalhe = String(error?.message || '').toLowerCase();
      if (detalhe.includes('push service error') || detalhe.includes('registration failed')) {
        showStatus('O navegador não conseguiu acessar o serviço de Push. Use Chrome ou Edge atualizado, permita notificações para este site e tente novamente. Se continuar, limpe os dados do site e recarregue a página.', 'error');
      } else {
        showStatus(error.message || 'Não foi possível ativar as notificações.', 'error');
      }
    } finally {
      activateButton.disabled = false;
      activateButton.removeAttribute('aria-busy');
      testButton.disabled = !readyToTest;
    }
  });

  testButton.addEventListener('click', async () => {
    testButton.disabled = true;
    try {
      showStatus('Enviando notificação de teste...');
      const response = await fetchWithTimeout(`${api}/teste`, { method: 'POST', credentials: 'include' });
      if (!response.ok) throw new Error(await errorMessage(response, 'Falha ao solicitar notificação de teste'));
      const result = await response.json();
      showStatus(`${result.message || 'Teste solicitado.'} Confira a central de notificações.`, 'success');
    } catch (error) {
      console.error('Falha no teste de Web Push:', error);
      showStatus(error.message || 'Falha ao enviar teste.', 'error');
    } finally {
      testButton.disabled = !readyToTest;
    }
  });

  try {
    await refresh();
  } catch (error) {
    console.error('Falha ao consultar Web Push:', error);
    showStatus(error.message || 'Não foi possível consultar o estado das notificações.', 'error');
    activateButton.disabled = false;
    testButton.disabled = true;
  }
}
