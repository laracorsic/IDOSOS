(() => {
    const cestaEl = document.getElementById('cesta');
    const opcoesEl = document.getElementById('opcoes');
    const feedbackEl = document.getElementById('feedback');
    const novoBtn = document.getElementById('novoBtn');
    const acertosEl = document.getElementById('acertos');

    const FRUTAS = ["🍎","🍌","🍓","🍇","🍊","🍉"];
    let acertos = 0;
    let respostaCerta = 0;
    let travado = false;

    function novaRodada(){
        travado = false;
        feedbackEl.textContent = '';
        const fruta = FRUTAS[Math.floor(Math.random()*FRUTAS.length)];
        respostaCerta = 3 + Math.floor(Math.random()*6); // entre 3 e 8

        cestaEl.innerHTML = '';
        for (let i=0;i<respostaCerta;i++){
            const span = document.createElement('span');
            span.textContent = fruta;
            cestaEl.appendChild(span);
        }

        gerarOpcoes();
    }

    function gerarOpcoes(){
        const opcoes = new Set([respostaCerta]);
        while (opcoes.size < 3){
            const delta = Math.floor(Math.random()*5) - 2;
            const val = respostaCerta + delta;
            if (val > 0 && val !== respostaCerta) opcoes.add(val);
        }
        const lista = Array.from(opcoes);
        shuffle(lista);

        opcoesEl.innerHTML = '';
        lista.forEach(valor => {
            const btn = document.createElement('button');
            btn.textContent = valor;
            btn.addEventListener('click', () => verificar(valor, btn));
            opcoesEl.appendChild(btn);
        });
    }

    function verificar(valor, btn){
        if (travado) return;
        travado = true;
        if (valor === respostaCerta){
            btn.classList.add('certo');
            feedbackEl.style.color = '#22c55e';
            feedbackEl.textContent = 'Isso mesmo! Muito bem! 🎉';
            acertos++;
            acertosEl.textContent = `Acertos: ${acertos}`;
            setTimeout(novaRodada, 1200);
        } else {
            btn.classList.add('errado');
            feedbackEl.style.color = '#ef4444';
            feedbackEl.textContent = `Quase! A resposta certa era ${respostaCerta}.`;
            setTimeout(novaRodada, 1600);
        }
    }

    function shuffle(a){
        for (let i=a.length-1;i>0;i--){
            const j = Math.floor(Math.random()*(i+1));
            [a[i],a[j]]=[a[j],a[i]];
        }
    }

    novoBtn.addEventListener('click', novaRodada);

    novaRodada();
})();