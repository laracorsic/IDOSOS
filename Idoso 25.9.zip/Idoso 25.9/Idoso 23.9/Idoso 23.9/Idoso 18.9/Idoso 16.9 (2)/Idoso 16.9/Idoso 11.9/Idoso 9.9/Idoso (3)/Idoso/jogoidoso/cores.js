(() => {
    const palavraEl = document.getElementById('palavraCor');
    const opcoesEl = document.getElementById('opcoesCores');
    const feedbackEl = document.getElementById('feedback');
    const novoBtn = document.getElementById('novoBtn');
    const acertosEl = document.getElementById('acertos');

    const CORES = [
        { nome: 'VERMELHO', cor: '#ef4444' },
        { nome: 'AZUL', cor: '#3b82f6' },
        { nome: 'VERDE', cor: '#22c55e' },
        { nome: 'AMARELO', cor: '#eab308' },
        { nome: 'ROXO', cor: '#8b5cf6' },
        { nome: 'LARANJA', cor: '#f97316' },
    ];

    let acertos = 0;
    let corCerta = null;
    let travado = false;

    function novaRodada(){
        travado = false;
        feedbackEl.textContent = '';

        corCerta = CORES[Math.floor(Math.random()*CORES.length)];
        palavraEl.textContent = corCerta.nome;

        const opcoes = new Set([corCerta.nome]);
        while (opcoes.size < 4){
            const c = CORES[Math.floor(Math.random()*CORES.length)];
            opcoes.add(c.nome);
        }
        const lista = Array.from(opcoes).map(nome => CORES.find(c => c.nome === nome));
        shuffle(lista);

        opcoesEl.innerHTML = '';
        lista.forEach(c => {
            const btn = document.createElement('button');
            btn.style.backgroundColor = c.cor;
            btn.addEventListener('click', () => verificar(c, btn));
            opcoesEl.appendChild(btn);
        });
    }

    function verificar(c, btn){
        if (travado) return;
        travado = true;
        if (c.nome === corCerta.nome){
            btn.classList.add('certo');
            feedbackEl.style.color = '#22c55e';
            feedbackEl.textContent = 'Isso mesmo! Muito bem! 🎉';
            acertos++;
            acertosEl.textContent = `Acertos: ${acertos}`;
            setTimeout(novaRodada, 1200);
        } else {
            btn.classList.add('errado');
            feedbackEl.style.color = '#ef4444';
            feedbackEl.textContent = `Quase! A cor certa era ${corCerta.nome}.`;
            setTimeout(novaRodada, 1600);
        }
    }

    function shuffle(a){
        for (let i=a.length-1;i>0;i--){
            const j = Math.floor(Math.random()*(i+1));
            [a[i],a[j]]=[a[j],a[i]];
        }
    }

    novoBtn.addEventListener('click', novaRodada);

    novaRodada();
})();