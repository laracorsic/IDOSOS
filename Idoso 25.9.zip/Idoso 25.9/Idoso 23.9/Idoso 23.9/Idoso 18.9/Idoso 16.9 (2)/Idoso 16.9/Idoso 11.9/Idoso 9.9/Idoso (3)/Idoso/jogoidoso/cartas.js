(() => {
    const mesaEl = document.getElementById('mesa');
    const feedbackEl = document.getElementById('feedback');
    const novoBtn = document.getElementById('novoBtn');
    const acertosEl = document.getElementById('acertos');

    const NAIPES = [
        { simbolo: '♥', cor: 'vermelha' },
        { simbolo: '♦', cor: 'vermelha' },
        { simbolo: '♠', cor: 'preta' },
        { simbolo: '♣', cor: 'preta' },
    ];

    let acertos = 0;
    let maiorValor = 0;
    let travado = false;

    function novaRodada(){
        travado = false;
        feedbackEl.textContent = '';

        let valor1 = 1 + Math.floor(Math.random()*13);
        let valor2 = 1 + Math.floor(Math.random()*13);
        while (valor2 === valor1){
            valor2 = 1 + Math.floor(Math.random()*13);
        }
        maiorValor = Math.max(valor1, valor2);

        mesaEl.innerHTML = '';
        [valor1, valor2].forEach(valor => {
            const naipe = NAIPES[Math.floor(Math.random()*NAIPES.length)];
            const carta = document.createElement('div');
            carta.className = `carta ${naipe.cor}`;
            carta.innerHTML = `<span class="numero">${textoCarta(valor)}</span><span class="naipe">${naipe.simbolo}</span>`;
            carta.addEventListener('click', () => verificar(valor, carta));
            mesaEl.appendChild(carta);
        });
    }

    function textoCarta(valor){
        if (valor === 1) return 'A';
        if (valor === 11) return 'J';
        if (valor === 12) return 'Q';
        if (valor === 13) return 'K';
        return String(valor);
    }

    function verificar(valor, el){
        if (travado) return;
        travado = true;
        if (valor === maiorValor){
            el.classList.add('certo');
            feedbackEl.style.color = '#22c55e';
            feedbackEl.textContent = 'Isso mesmo! Muito bem! 🎉';
            acertos++;
            acertosEl.textContent = `Acertos: ${acertos}`;
            setTimeout(novaRodada, 1200);
        } else {
            el.classList.add('errado');
            feedbackEl.style.color = '#ef4444';
            feedbackEl.textContent = 'Quase! Tente ver qual número é maior.';
            setTimeout(novaRodada, 1600);
        }
    }

    novoBtn.addEventListener('click', novaRodada);

    novaRodada();
})();