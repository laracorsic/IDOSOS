// Variáveis globais
let video = null;
let canvas = null;
let canvasContext = null;
let isScanning = false;
let currentQRCode = null;

// URL base da API (ajustar conforme necessário)
const API_BASE_URL = 'http://localhost:8080'; 

// Inicializar quando o documento carrega
document.addEventListener('DOMContentLoaded', function() {
    video = document.getElementById('video');
    canvas = document.getElementById('canvas');
    canvasContext = canvas.getContext('2d', { willReadFrequently: true });
    
    // Tenta carregar o usuário do localStorage para ver se já está logado
    const currentUser = getFromLocalStorage('currentUser');
    if (!currentUser) {
        // Se não houver usuário, para testes, podemos criar um mock ou avisar
        console.warn('Usuário não identificado. Certifique-se de estar logado.');
    }
});

// Adicionamos o "async" antes da função para permitir o uso de "await"
async function selectOption(option) {
    const cards = document.querySelectorAll('.option-card');
    cards.forEach(card => card.classList.remove('active'));
    
    if (option === 'scan') {
        cards[0].classList.add('active');
        document.getElementById('scanSection').classList.add('active');
        document.getElementById('generateSection').classList.remove('active');
        clearQRData();

        // 🔥 MUDANÇA PARA TESTE: Garante que o usuário da sessão virou o Familiar antes de ler
        console.log('Trocando sessão para o Familiar de teste...');
        await criarFamiliarAutomatico();
        
    } else {
        cards[1].classList.add('active');
        document.getElementById('generateSection').classList.add('active');
        document.getElementById('scanSection').classList.remove('active');
        stopCamera();

        // 🔥 MUDANÇA PARA TESTE: Garante que o usuário virou o Idoso ANTES de pedir o QR Code
        console.log('Trocando sessão para o Idoso de teste...');
        await criarIdosoAutomatico();
        
        // Agora que o localStorage já foi atualizado com o Idoso, carrega com segurança
        loadQRCodeFromBackend();
    }
    
    hideResultMessage();
}


// ===== FUNÇÃO PARA LER QR CODE =====

// Iniciar câmera
async function startCamera() {
    try {
        const stream = await navigator.mediaDevices.getUserMedia({
            video: { 
                facingMode: 'environment',
                width: { ideal: 1280 },
                height: { ideal: 720 }
            }
        });
        
        video.srcObject = stream;
        video.onloadedmetadata = function() {
            video.play();
            isScanning = true;
            scanQRCode();
        };
        
        showResultMessage('Câmera iniciada. Aponte para o QR Code.', 'success');
    } catch (error) {
        console.error('Erro ao acessar câmera:', error);
        showResultMessage('Erro ao acessar a câmera. Verifique as permissões.', 'error');
    }
}


// Inicializar quando o documento carrega
document.addEventListener('DOMContentLoaded', async function() {
    video = document.getElementById('video');
    canvas = document.getElementById('canvas');
    canvasContext = canvas.getContext('2d', { willReadFrequently: true });
    
    // 1. Tenta buscar o usuário salvo no LocalStorage
    let currentUser = getFromLocalStorage('currentUser');
    
    // 2. Se não existir, cria o idoso automaticamente no banco de dados e salva a sessão
    if (!currentUser) {
        console.log('Criando usuário de teste automaticamente...');
        currentUser = await criarIdosoAutomatico();
    }
    
    console.log('Logado como:', currentUser);
});

// Exemplo de script de teste para garantir que o Familiar exista antes de vincular
async function criarFamiliarAutomatico() {
    try {
        const response = await fetch('http://localhost:8080/familiares', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ nome: "Familiar de Teste", idade: 40, telefone: "16 88888-9999" }) // Removido parentesco que não existe no DTO
        });
        
        if (!response.ok) throw new Error('Erro ao criar familiar');
        
        const dados = await response.json();
        console.log('Familiar criado:', dados);
        localStorage.setItem('currentUser', JSON.stringify(dados));
        return dados;
    } catch (e) {
        console.error('Erro ao criar familiar:', e);
        // Fallback para não quebrar o teste, mas avisar que pode falhar
        const fallback = { id: 1, nome: "Familiar (Fallback)" };
        localStorage.setItem('currentUser', JSON.stringify(fallback));
        return fallback;
    }
}


// Nova função auxiliar para automatizar o cadastro direto no JS
async function criarIdosoAutomatico() {
    try {
        const response = await fetch('http://localhost:8080/idosos', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                nome: "Idoso de Teste",
                idade: 75,
                telefone: "16 99999-9999"
            })
        });

        if (!response.ok) {
            throw new Error(`Erro no servidor: ${response.status}`);
        }

        const dados = await response.json();
        console.log('Idoso criado:', dados);
        
        localStorage.setItem('currentUser', JSON.stringify(dados));
        
        return dados;
    } catch (error) {
        console.error('Falha ao criar idoso automatizado:', error);
        const fallback = { id: 1, nome: "Idoso (Fallback)" };
        localStorage.setItem('currentUser', JSON.stringify(fallback));
        return fallback;
    }
}


// Parar câmera
function stopCamera() {
    isScanning = false;
    if (video && video.srcObject) {
        const tracks = video.srcObject.getTracks();
        tracks.forEach(track => track.stop());
        video.srcObject = null;
    }
    hideResultMessage();
}

// Função para escanear QR Code (Atualizada)
// Função para escanear QR Code (Atualizada com Vinculação Automática)
function scanQRCode() {
    if (!isScanning) return;
    
    if (video.readyState === video.HAVE_ENOUGH_DATA) {
        // Define o tamanho do canvas igual ao do vídeo para manter a proporção
        canvas.width = video.videoWidth;
        canvas.height = video.videoHeight;
        
        // Desenha o frame atual do vídeo no canvas
        canvasContext.drawImage(video, 0, 0, canvas.width, canvas.height);
        
        // Captura os dados da imagem
        const imageData = canvasContext.getImageData(0, 0, canvas.width, canvas.height);
        
        // Tenta ler o QR Code usando a biblioteca jsQR
        // Usamos "attemptBoth" para ser mais resiliente a cores invertidas ou reflexos
        const code = jsQR(imageData.data, imageData.width, imageData.height, {
            inversionAttempts: "attemptBoth"
        });
        
        if (code) {
            console.log("QR Lido com sucesso:", code.data);

            // 1. Para o escaneamento imediatamente
            isScanning = false;
            
            // 2. Processa o conteúdo lido
            let idosoId = code.data;
            
            try {
                // Tenta interpretar como JSON (formato do seu backend)
                const dadosIdoso = JSON.parse(code.data);
                idosoId = dadosIdoso.id || code.data;
                
                // Atualiza a interface com os dados encontrados
                if (dadosIdoso.nome) document.getElementById('infoNome').innerText = dadosIdoso.nome;
                if (dadosIdoso.idade) document.getElementById('infoIdade').innerText = dadosIdoso.idade;
                if (dadosIdoso.telefone) document.getElementById('infoTelefone').innerText = dadosIdoso.telefone;
                document.getElementById('dadosIdosoContainer').style.display = 'block';
            } catch (e) {
                console.log("Conteúdo do QR não é JSON, usando valor puro:", idosoId);
            }

            // Preenche o campo de texto visível
            document.getElementById('qrData').value = idosoId;
            
            // Feedback visual de sucesso
            showResultMessage('✓ QR Code detectado! Processando vínculo...', 'success');

            // 3. Finaliza a câmera e inicia a vinculação no backend
            stopCamera();
            processQRCode();

            return; 
        }
    }
    
    // Continua tentando ler no próximo frame
    if (isScanning) {
        requestAnimationFrame(scanQRCode);
    }
}


// Nova função para puxar os dados completos do Spring Boot
async function buscarInformacoesIdoso(id) {
    try {
        // Busca a lista na rota exata do seu IdosoController (/idosos)
        const response = await fetch('http://localhost:8080/idosos');
        if (!response.ok) throw new Error('Falha ao conectar ao servidor.');
        
        const idosos = await response.json();
        
        // Localiza o idoso pelo ID lido no código QR
        const idosoEncontrado = idosos.find(i => i.id == id);
        
        if (idosoEncontrado) {
            // Insere os dados nas novas tags do HTML
            document.getElementById('infoNome').innerText = idosoEncontrado.nome;
            document.getElementById('infoIdade').innerText = idosoEncontrado.idade || 'Não informada';
            document.getElementById('infoTelefone').innerText = idosoEncontrado.telefone || 'Não informada';
            
            // Exibe o painel visual com os dados
            document.getElementById('dadosIdosoContainer').style.display = 'block';
            showResultMessage('✓ Dados carregados! Clique em Vincular para confirmar.', 'success');
        } else {
            showResultMessage('Código lido (' + id + '), mas este idoso não existe no banco.', 'error');
        }
    } catch (error) {
        console.error('Erro ao buscar dados:', error);
        showResultMessage('Erro ao recuperar informações do servidor.', 'error');
    }
}

// Limpar dados do QR Code (Atualizada para limpar o painel também)
function clearQRData() {
    document.getElementById('qrData').value = '';
    currentQRCode = null;
    document.getElementById('dadosIdosoContainer').style.display = 'none';
    document.getElementById('infoNome').innerText = '-';
    document.getElementById('infoIdade').innerText = '-';
    document.getElementById('infoTelefone').innerText = '-';
    hideResultMessage();
}

// ===== PROCESSAMENTO DE VINCULAÇÃO =====

// Processar QR Code e vincular (via Backend Java)
async function processQRCode() {
    const qrData = document.getElementById('qrData').value.trim();

    if (!qrData) {
        showResultMessage('Por favor, escaneie um QR Code primeiro.', 'error');
        return;
    }

    try {
        const currentUser = getFromLocalStorage('currentUser');

        if (!currentUser || !currentUser.id) {
            showResultMessage('Erro: Usuário (Familiar) não identificado. Faça login.', 'error');
            return;
        }

        const response = await fetch(
            `${API_BASE_URL}/api/vinculo/vincular-automatico?familiarId=${currentUser.id}`,
            {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(qrData) // CORREÇÃO: Envia como JSON válido
            }
        );

        // Captura o JSON do erro ou do sucesso
        const result = await response.json();

        if (!response.ok) {
            // Se o Spring usar uma estrutura padrão de erro (como de um Custom Exception Handler),
            // a mensagem costuma vir no campo 'message' ou 'error'.
            throw new Error(result?.message || result?.error || `Erro HTTP: ${response.status}`);
        }

        // Sucesso: exibe o nome do idoso retornado se houver, senão o ID
        showResultMessage(
            `✓ Vinculado com sucesso ao idoso ${result.nome || result.id}`,
            'success'
        );

        setTimeout(() => {
            clearQRData();
            hideResultMessage();
        }, 4000);

    } catch (error) {
        console.error('Erro ao processar QR Code:', error);
        showResultMessage(
            `Erro ao processar a vinculação: ${error.message}`,
            'error'
        );
    }
}


// ===== FUNÇÃO PARA GERAR QR CODE (DO BACKEND) =====

// Carregar QR Code gerado pelo backend Java
async function loadQRCodeFromBackend() {
    try {

        const currentUser = getFromLocalStorage('currentUser');

        if (!currentUser || !currentUser.id) {
            showResultMessage(
                'Erro: Usuário (Idoso) não identificado. Faça login.',
                'error'
            );

            document.getElementById('qrPreview').innerHTML =
                '<p style="color:red;">Usuário não encontrado</p>';

            return;
        }

        const qrCodeUrl =
            `${API_BASE_URL}/api/vinculo/qrcode/${currentUser.id}`;

        console.log("URL do QR:", qrCodeUrl);

        const response = await fetch(qrCodeUrl);

        if (!response.ok) {
            throw new Error(
                `QR Code não encontrado. Status: ${response.status}`
            );
        }

        document.getElementById('qrPreview').innerHTML = `
            <img
                src="${qrCodeUrl}"
                alt="QR Code"
                style="
                    max-width:250px;
                    height:auto;
                    border:5px solid white;
                    border-radius:10px;
                    box-shadow:0 4px 10px rgba(0,0,0,0.1);
                "
            />
        `;

        showResultMessage(
            '✓ QR Code carregado com sucesso!',
            'success'
        );

    } catch (error) {

        console.error('Erro ao carregar QR Code:', error);

        showResultMessage(
            `Erro ao carregar QR Code: ${error.message}`,
            'error'
        );

        document.getElementById('qrPreview').innerHTML =
            '<p style="color:red;">Erro ao carregar QR Code</p>';
    }
}

// Atualizar/recarregar QR Code
function refreshQRCode() {
    document.getElementById('qrPreview').innerHTML = 'Carregando seu código QR...';
    loadQRCodeFromBackend();
}

// Baixar QR Code como imagem
function downloadQRCode() {
    const qrElement = document.querySelector('#qrPreview img');
    if (!qrElement) {
        showResultMessage('QR Code não encontrado.', 'error');
        return;
    }
    
    const link = document.createElement('a');
    link.href = qrElement.src;
    link.download = `qrcode_zelo_${new Date().getTime()}.png`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
}

// Imprimir QR Code
function printQRCode() {
    const qrElement = document.querySelector('#qrPreview img');
    if (!qrElement) return;
    
    const printWindow = window.open('', '', 'height=600,width=600');
    printWindow.document.write('<html><head><title>Imprimir QR Code - ZELO</title></head><body style="display:flex; flex-direction:column; align-items:center; justify-content:center; height:100vh; font-family:sans-serif;">');
    printWindow.document.write('<h2>Seu Código QR de Vinculação</h2>');
    printWindow.document.write('<img src="' + qrElement.src + '" style="max-width: 400px;"/>');
    printWindow.document.write('<p>Escaneie para vincular ao perfil no app ZELO</p>');
    printWindow.document.write('</body></html>');
    printWindow.document.close();
    setTimeout(() => { printWindow.print(); }, 500);
}

// ===== FUNÇÕES AUXILIARES =====

function showResultMessage(message, type) {
    const messageElement = document.getElementById('resultMessage');
    messageElement.textContent = message;
    messageElement.className = `result-message ${type}`;
    messageElement.style.display = 'block';
}

function hideResultMessage() {
    const messageElement = document.getElementById('resultMessage');
    messageElement.style.display = 'none';
}

function getFromLocalStorage(key) {
    try {
        const data = localStorage.getItem(key);
        return data ? JSON.parse(data) : null;
    } catch (error) {
        return null;
    }
}

// Limpar recursos ao sair
window.addEventListener('beforeunload', function() {
    stopCamera();
});
