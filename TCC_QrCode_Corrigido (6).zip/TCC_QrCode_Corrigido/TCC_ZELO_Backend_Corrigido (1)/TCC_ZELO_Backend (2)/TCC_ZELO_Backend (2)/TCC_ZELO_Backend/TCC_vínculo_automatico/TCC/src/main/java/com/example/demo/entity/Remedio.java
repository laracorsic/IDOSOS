package com.example.demo.entity;

import jakarta.persistence.*;

import java.time.LocalTime;

@Entity
@Table(name = "remedio")

public class Remedio {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "id_idoso")
    private Idoso idoso;

    private String nome;
    private float dosagem;
    private float intervalo;
    private LocalTime hora = LocalTime.now();

    protected Remedio() {}

    public Remedio(String nome, float dosagem, float intervalo, LocalTime hora) {
        this.nome = nome;
        this.dosagem = dosagem;
        this.intervalo = intervalo;
        this.hora = hora;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public float getDosagem() {
        return dosagem;
    }

    public void setDosagem(float dosagem) {
        this.dosagem = dosagem;
    }

    public float getIntervalo() {
        return intervalo;
    }

    public void setIntervalo(float intervalo) {
        this.intervalo = intervalo;
    }

    public LocalTime getHora() {
        return hora;
    }

    public void setHora(LocalTime hora) {
        this.hora = hora;
    }
}
