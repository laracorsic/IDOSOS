package com.example.demo.service;

import com.example.demo.dto.LembreteDTO;
import com.example.demo.entity.Lembrete;
import com.example.demo.repository.LembreteRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service

public class LembreteService {

    @Autowired

    private LembreteRepository repository;

    @Transactional

    public void cadastrar(LembreteDTO lembreteDTO){
        repository.save(new Lembrete(lembreteDTO.getDescricao(), lembreteDTO.getData_hora()));
    }

    public List<Lembrete> listar(){
        return repository.findAll();
    }

    @Transactional
    public void atualizar(Long id, LembreteDTO lembreteDTO){
        Lembrete lembreteEncontrado = repository.getReferenceById(id);
        if (lembreteEncontrado == null) {
            System.out.println("Lembrete não existe");
        }else{
            lembreteEncontrado.setDescricao(lembreteDTO.getDescricao());
            lembreteEncontrado.setData_hora(lembreteDTO.getData_hora());

        }
    }

    @Transactional
    public void remover(Long id) {
        Lembrete lembreteEncontrado = repository.getReferenceById(id);
        if (lembreteEncontrado != null) {
            repository.deleteById(id);
        } else {
            System.out.println("Lembrete não existe");
        }
    }
}