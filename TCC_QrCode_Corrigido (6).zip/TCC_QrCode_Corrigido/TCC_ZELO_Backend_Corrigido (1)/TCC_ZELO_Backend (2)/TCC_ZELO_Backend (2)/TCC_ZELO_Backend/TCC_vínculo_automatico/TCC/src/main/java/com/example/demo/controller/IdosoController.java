package com.example.demo.controller;

import com.example.demo.dto.IdosoDTO;
import com.example.demo.entity.Idoso;
import com.example.demo.service.IdosoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/idosos")
@CrossOrigin(origins = "*")
public class IdosoController {

    @Autowired
    private IdosoService service;

    @PostMapping
    public ResponseEntity<Idoso> cadastrar(@RequestBody IdosoDTO dto){
        Idoso idoso = service.cadastrar(dto);
        return ResponseEntity.ok(idoso);
    }


    @GetMapping
    public ResponseEntity<List<Idoso>> listar(){
        List<Idoso> lista = service.listar();
        return ResponseEntity.ok(lista);
    }

    @PutMapping("/{id}")
    public void atualizar(@PathVariable Long id, @RequestBody IdosoDTO dto){

        service.atualizar(id, dto);
    }

    @DeleteMapping("/{id}")
    public void remover(@PathVariable Long id){
        service.remover(id);
    }

    @GetMapping("/{id}/qrcode")
    public ResponseEntity<byte[]> obterQrCode(@PathVariable Long id) {
        Idoso idoso = service.buscarPorId(id);
        System.out.println("=== Conteudo ====" + idoso.getNome() + idoso.getIdade() + idoso.getId() + idoso.getTelefone());



        if (idoso != null && idoso.getQrCode() != null) {
            return ResponseEntity.ok().contentType(MediaType.IMAGE_PNG).body(idoso.getQrCode());
        }
        return ResponseEntity.notFound().build();
    }
}