package com.example.demo.service;

import com.example.demo.dto.RemedioDTO;
import com.example.demo.entity.Remedio;
import com.example.demo.repository.RemedioRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service

public class RemedioService {

    @Autowired

    private RemedioRepository repository;

    @Transactional

    public void cadastrar(RemedioDTO remedioDTO){
        repository.save(new Remedio(remedioDTO.getNome(), remedioDTO.getDosagem(),remedioDTO.getIntervalo(), remedioDTO.getHora()));
    }

    public List<Remedio> listar(){
        return repository.findAll();
    }

    @Transactional
    public void atualizar(Long id, RemedioDTO remedioDTO){
       Remedio remedioEncontrado = repository.getReferenceById(id);
        if (remedioEncontrado == null) {
            System.out.println("Remedio não existe");
        }else{
            remedioEncontrado.setNome(remedioDTO.getNome());
            remedioEncontrado.setDosagem(remedioDTO.getDosagem());
            remedioEncontrado.setIntervalo(remedioDTO.getIntervalo());
            remedioEncontrado.setHora(remedioDTO.getHora());
        }
    }

    @Transactional
    public void remover(Long id) {
       Remedio remedioEncontrado = repository.getReferenceById(id);
        if (remedioEncontrado != null) {
            repository.deleteById(id);
        } else {
            System.out.println("Remédio não existe");
        }
    }
}