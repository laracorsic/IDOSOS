package com.example.demo.dto;

import java.time.LocalTime;

public class LembreteDTO {
    private String descricao;
    private LocalTime data_hora = LocalTime.now();


    public LembreteDTO(String descricao, LocalTime data_hora) {
        this.descricao = descricao;
        this.data_hora = data_hora;
    }

    public String getDescricao() {
        return descricao;
    }

    public LocalTime getData_hora() {
        return data_hora;
    }
}






