package com.example.demo.entity;

import jakarta.persistence.*;

import java.time.LocalTime;

@Entity
@Table(name = "lembrete")

public class Lembrete {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "id_idoso")
    private Idoso idoso;


    private String descricao;
    private LocalTime data_hora = LocalTime.now();

    protected Lembrete() {}

    public Lembrete( String descricao, LocalTime data_hora) {

        this.descricao = descricao;
        this.data_hora = data_hora;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public LocalTime getData_hora() {
        return data_hora;
    }

    public void setData_hora(LocalTime data_hora) {
        this.data_hora = data_hora;
    }
}
