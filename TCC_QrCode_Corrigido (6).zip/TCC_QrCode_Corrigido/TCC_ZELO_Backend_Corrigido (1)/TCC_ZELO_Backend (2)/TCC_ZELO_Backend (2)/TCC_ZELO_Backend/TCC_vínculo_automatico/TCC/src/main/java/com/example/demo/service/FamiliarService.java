package com.example.demo.service;

import com.example.demo.dto.FamiliarDTO;
import com.example.demo.entity.Familiar;
import com.example.demo.entity.Idoso;
import com.example.demo.repository.FamiliarRepository;
import com.example.demo.repository.IdosoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;

@Service

public class FamiliarService {

        @Autowired
    private FamiliarRepository repository;

    @Autowired
    private IdosoRepository idosoRepository;

    @Transactional
    public Familiar cadastrar(FamiliarDTO familiarDTO){
        return repository.save(new Familiar(familiarDTO.getNome(), familiarDTO.getIdade(), familiarDTO.getTelefone()));
    }

    @Transactional
    public void vincularIdoso(Long familiarId, String qrCodeContent) {
        Familiar familiar = repository.findById(familiarId).orElseThrow(() -> new RuntimeException("Familiar não encontrado"));
        Long idosoId = Long.parseLong(qrCodeContent);
        Idoso idoso = idosoRepository.findById(idosoId).orElseThrow(() -> new RuntimeException("Idoso não encontrado"));

        if (idoso.getFamiliares() == null) {
            idoso.setFamiliares(new ArrayList<>());
        }

        if (!idoso.getFamiliares().contains(familiar)) {
            idoso.getFamiliares().add(familiar);
            idosoRepository.save(idoso);
        }
    }

    public List<Familiar> listar(){
        return repository.findAll();
    }

    @Transactional
    public void atualizar(Long id, FamiliarDTO familiarDTO){
        Familiar familiarEncontrado = repository.getReferenceById(id);
        if (familiarEncontrado == null) {
            System.out.println("familiar não existe");
        }else{
            familiarEncontrado.setNome(familiarDTO.getNome());
            familiarEncontrado.setIdade(familiarDTO.getIdade());
            familiarEncontrado.setTelefone(familiarDTO.getTelefone());
        }
    }

    @Transactional
    public void remover(Long id) {
        Familiar familiarEncontrado = repository.getReferenceById(id);
        if (familiarEncontrado != null) {
            repository.deleteById(id);
        } else {
            System.out.println("Familiar não existe");
        }
    }
}