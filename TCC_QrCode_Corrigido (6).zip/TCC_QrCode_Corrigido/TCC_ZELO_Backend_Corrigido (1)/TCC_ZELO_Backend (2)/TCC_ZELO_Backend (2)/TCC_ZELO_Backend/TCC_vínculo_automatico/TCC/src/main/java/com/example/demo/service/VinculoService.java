package com.example.demo.service;

import com.example.demo.entity.Familiar;
import com.example.demo.entity.Idoso;
import com.example.demo.repository.FamiliarRepository;
import com.example.demo.repository.IdosoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;

@Service
public class VinculoService {

    @Autowired
    private FamiliarRepository familiarRepository;

    @Autowired
    private IdosoRepository idosoRepository;


    @Transactional
    public Idoso realizarVinculo(Long familiarId, String idosoIdString) {

        Long idosoId;

        try {
            idosoId = Long.parseLong(idosoIdString.replace("\"", "").trim());
        } catch (NumberFormatException e) {
            throw new RuntimeException("Código do QR Code inválido: " + idosoIdString);
        }

        Familiar familiar = familiarRepository.findById(familiarId)
                .orElseThrow(() ->
                        new RuntimeException("Familiar com ID " + familiarId + " não encontrado."));

        Idoso idoso = idosoRepository.findById(idosoId)
                .orElseThrow(() ->
                        new RuntimeException("Idoso com ID " + idosoId + " não encontrado."));

        if (idoso.getFamiliares() == null) {
            idoso.setFamiliares(new ArrayList<>());
        }

        if (!idoso.getFamiliares().contains(familiar)) {
            idoso.getFamiliares().add(familiar);
            idoso = idosoRepository.save(idoso);
        }

        return idoso;
    }
}
