package com.example.demo.dto;

import java.time.LocalTime;

public class RemedioDTO {
    private String nome;
    private float dosagem;
    private float intervalo;
    private LocalTime hora = LocalTime.now();


    public RemedioDTO(String nome, float dosagem, float intervalo, LocalTime hora) {
        this.nome = nome;
        this.dosagem = dosagem;
        this.intervalo = intervalo;
        this.hora = hora;
    }

    public String getNome() {
        return nome;
    }

    public float getDosagem() {
        return dosagem;
    }

    public float getIntervalo() {
        return intervalo;
    }

    public LocalTime getHora() {
        return hora;
    }
}






