package com.example.demo.service;

import com.example.demo.dto.CuidadorDTO;
import com.example.demo.entity.Cuidador;
import com.example.demo.entity.Idoso;
import com.example.demo.repository.CuidadorRepository;
import com.example.demo.repository.IdosoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;

@Service
public class CuidadorService {

    @Autowired
    private CuidadorRepository repository;

    @Autowired
    private IdosoRepository idosoRepository;

    @Transactional
    public Cuidador cadastrar(CuidadorDTO dto) {
        return repository.save(new Cuidador(dto.getNome(), dto.getCpf(), dto.getTelefone()));
    }

    public List<Cuidador> listar() {
        return repository.findAll();
    }

    @Transactional
    public void vincularIdoso(Long cuidadorId, String qrCodeContent) {
        Cuidador cuidador = repository.findById(cuidadorId).orElseThrow(() -> new RuntimeException("Cuidador não encontrado"));
        
        // O conteúdo do QR Code agora será o ID do Idoso (ou um identificador único)
        Long idosoId = Long.parseLong(qrCodeContent);
        Idoso idoso = idosoRepository.findById(idosoId).orElseThrow(() -> new RuntimeException("Idoso não encontrado"));

        if (cuidador.getIdosos() == null) {
            cuidador.setIdosos(new ArrayList<>());
        }
        
        if (!cuidador.getIdosos().contains(idoso)) {
            cuidador.getIdosos().add(idoso);
            repository.save(cuidador);
        }
    }
}
