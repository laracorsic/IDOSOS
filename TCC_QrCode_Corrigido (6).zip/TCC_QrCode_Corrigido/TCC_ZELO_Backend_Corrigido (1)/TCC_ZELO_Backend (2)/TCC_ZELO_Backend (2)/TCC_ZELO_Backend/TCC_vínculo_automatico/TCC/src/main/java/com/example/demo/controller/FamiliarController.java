package com.example.demo.controller;

import com.example.demo.dto.FamiliarDTO;
import com.example.demo.dto.IdosoDTO;
import com.example.demo.entity.Familiar;
import com.example.demo.entity.Idoso;
import com.example.demo.service.FamiliarService;
import com.example.demo.service.IdosoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/familiares")
@CrossOrigin(origins = "*")
public class FamiliarController {

    @Autowired
    private FamiliarService service;

    @PostMapping
    public ResponseEntity<Familiar> cadastrar(@RequestBody FamiliarDTO dto){
        Familiar familiar = service.cadastrar(dto);
        return ResponseEntity.ok(familiar);
    }

    @GetMapping
    public ResponseEntity<List<Familiar>> listar(){
        List<Familiar> lista = service.listar();
        return ResponseEntity.ok(lista);
    }

    @PutMapping("/{id}")
    public void atualizar(@PathVariable Long id, @RequestBody FamiliarDTO dto){

        service.atualizar(id, dto);
    }

    @DeleteMapping("/{id}")
    public void remover(@PathVariable Long id){
        service.remover(id);
    }

    @PostMapping("/{id}/vincular")
    public ResponseEntity<String> vincularIdoso(@PathVariable Long id, @RequestBody String qrCodeContent) {
        try {
            service.vincularIdoso(id, qrCodeContent);
            return ResponseEntity.ok("Idoso vinculado com sucesso ao familiar.");
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }
}