package com.example.demo.controller;

import com.example.demo.entity.Idoso;
import com.example.demo.service.IdosoService;
import com.example.demo.service.VinculoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/vinculo")
@CrossOrigin(origins = "*")
public class VinculoController {

    @Autowired
    private IdosoService idosoService;

    @Autowired
    private VinculoService vinculoService;

    @GetMapping(value = "/qrcode/{idosoId}", produces = MediaType.IMAGE_PNG_VALUE)
    public ResponseEntity<byte[]> visualizarQrCode(@PathVariable Long idosoId) {
        Idoso idoso = idosoService.buscarPorId(idosoId);
        if (idoso != null && idoso.getQrCode() != null) {
            return ResponseEntity.ok().body(idoso.getQrCode());
        }
        return ResponseEntity.notFound().build();
    }


    @PostMapping("/vincular-automatico")
    public ResponseEntity<Idoso> vincularAutomatico(
            @RequestParam Long familiarId,
            @RequestBody String qrCodeContent) {

        Idoso idoso = vinculoService.realizarVinculo(
                familiarId,
                qrCodeContent
        );

        return ResponseEntity.ok(idoso);
    }
}
