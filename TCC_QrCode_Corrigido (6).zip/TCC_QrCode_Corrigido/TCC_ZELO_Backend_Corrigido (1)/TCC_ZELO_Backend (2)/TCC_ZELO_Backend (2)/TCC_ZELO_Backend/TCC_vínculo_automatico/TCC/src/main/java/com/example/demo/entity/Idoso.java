package com.example.demo.entity;

import jakarta.persistence.*;
import java.util.List;

@Entity
@Table(name = "idoso")
public class Idoso {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String nome;
    private int idade;
    private String telefone;

    @Lob
    @Column(name = "qrcode", columnDefinition="LONGBLOB")
    private byte[] qrCode;

    @OneToMany(mappedBy = "idoso", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<Remedio> remedios;

    @OneToMany(mappedBy = "idoso", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<Lembrete> lembretes;

    @ManyToMany
    @JoinTable(
            name = "idoso_familiar",
            joinColumns = @JoinColumn(name = "id_idoso"),
            inverseJoinColumns = @JoinColumn(name = "id_familiar")
    )
    private List<Familiar> familiares;

    @ManyToMany(mappedBy = "idosos")
    private List<Cuidador> cuidadores;

    protected Idoso() {}

    public Idoso(String nome, int idade, String telefone) {
        this.nome = nome;
        this.idade = idade;
        this.telefone = telefone;
    }

    public String getTelefone() {
        return telefone;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }

    public Long getId() {
        return id;
    }

    public String getNome() {
        return nome;
    }

    public int getIdade() {
        return idade;
    }

    public List<Remedio> getRemedios() {
        return remedios;
    }

    public List<Lembrete> getLembretes() {
        return lembretes;
    }

    public List<Familiar> getFamiliares() {
        return familiares;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public void setIdade(int idade) {
        this.idade = idade;
    }

    public byte[] getQrCode() {
        return qrCode;
    }

    public void setQrCode(byte[] qrCode) {
        this.qrCode = qrCode;
    }

    public void setRemedios(List<Remedio> remedios) {
        this.remedios = remedios;
    }

    public void setLembretes(List<Lembrete> lembretes) {
        this.lembretes = lembretes;
    }

    public void setFamiliares(List<Familiar> familiares) {
        this.familiares = familiares;
    }

    public List<Cuidador> getCuidadores() {
        return cuidadores;
    }

    public void setCuidadores(List<Cuidador> cuidadores) {
        this.cuidadores = cuidadores;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Idoso idoso = (Idoso) o;
        return id != null && id.equals(idoso.id);
    }

    @Override
    public int hashCode() {
        return id != null ? id.hashCode() : 0;
    }
}