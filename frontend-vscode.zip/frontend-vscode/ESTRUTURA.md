# Estrutura do frontend

O frontend é estático e está organizado por funcionalidade. Cada módulo pode conter sua página HTML, CSS, JavaScript e imagens próprias.

- `assets/css/`: estilos compartilhados entre páginas.
- `assets/js/`: scripts compartilhados, configuração da API, sessão, login, chat, acessibilidade e Web Push.
- `assistente/`: assistente Zelo e renderização de Markdown.
- `jogoidoso/`, `remedioidoso/`, `remediofamiliar/`, `inicioidoso/`, `iniciofamiliar/` etc.: módulos funcionais independentes.
- `sw.js`: service worker mantido na raiz para preservar o escopo das notificações do site.
- `paginainicial/`, `login.html` e `configuracoes.html`: entradas principais do fluxo.

Ao criar uma nova página, mantenha os arquivos específicos dentro do módulo correspondente e coloque apenas recursos reutilizados por vários módulos em `assets/css/` ou `assets/js/`.
