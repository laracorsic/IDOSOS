document.addEventListener("DOMContentLoaded", () => {
    // 1. Carrega dados do idoso selecionado
    const selectedIdoso = JSON.parse(localStorage.getItem("selectedIdoso")) || {};
    const currentUser = JSON.parse(localStorage.getItem("currentUser")) || {};

    const idDisplay = document.getElementById("idoso-id-display");
    if (idDisplay) {
        idDisplay.innerText = selectedIdoso.id || currentUser.idIdoso || "38299";
    }

    // 2. Atualiza a data atual dinamicamente
    const dateTitle = document.getElementById("current-date-title");
    if (dateTitle) {
        const agora = new Date();
        const opcoes = { day: '2-digit', month: 'long', year: 'numeric' };
        const dataFormatada = agora.toLocaleDateString('pt-BR', opcoes).toUpperCase();
        dateTitle.innerText = `HOJE, DIA ${dataFormatada}`;
    }
    carregarQrCodeIdoso();
});

async function carregarQrCodeIdoso() {
    const imagem = document.getElementById('qrCodeIdoso');
    const status = document.getElementById('qrCodeStatus');
    if (!imagem || !status) return;
    let usuario;
    try { usuario = JSON.parse(localStorage.getItem('currentUser') || '{}'); } catch (_) { usuario = {}; }
    const idosoId = usuario.id;
    if (!idosoId) {
        status.textContent = 'Não foi possível identificar este perfil.';
        return;
    }
    status.textContent = 'Carregando seu QR Code...';
    imagem.hidden = true;
    try {
        const base = window.ZELO_API_BASE_URL || 'http://localhost:8080';
        const resposta = await fetch(`${base}/api/qrcode/${encodeURIComponent(idosoId)}?atualizado=${Date.now()}`, {
            credentials: 'include',
            cache: 'no-store'
        });
        if (!resposta.ok) throw new Error(`servidor respondeu ${resposta.status}`);
        const blob = await resposta.blob();
        if (imagem.dataset.url) URL.revokeObjectURL(imagem.dataset.url);
        const url = URL.createObjectURL(blob);
        imagem.dataset.url = url;
        imagem.src = url;
        imagem.hidden = false;
        status.textContent = 'Pronto. Mostre o código ao familiar.';
    } catch (erro) {
        console.error('Falha ao carregar QR Code:', erro);
        status.textContent = 'Não foi possível carregar agora. Toque em “Atualizar QR Code”.';
    }
}