(() => {
    'use strict';
    async function carregarCompromissosIdoso() {
        const lista = document.getElementById('lista-compromissos-idoso');
        if (!lista) return;
        let usuario = {};
        try { usuario = JSON.parse(localStorage.getItem('currentUser') || '{}'); } catch (_) {}
        const idosoId = usuario.id || (JSON.parse(localStorage.getItem('selectedIdoso') || '{}').id);
        if (!idosoId) { lista.textContent = 'Não foi possível identificar o perfil do idoso.'; return; }
        const base = window.ZELO_API_BASE_URL || 'http://localhost:8080';
        try {
            const resposta = await fetch(`${base}/api/compromissos/idoso/${encodeURIComponent(idosoId)}`, {
                credentials: 'include', cache: 'no-store'
            });
            if (!resposta.ok) throw new Error(resposta.status === 401 ? 'Sua sessão expirou. Entre novamente.' : 'Não foi possível carregar os compromissos.');
            const compromissos = await resposta.json();
            lista.replaceChildren();
            if (!compromissos.length) { lista.textContent = 'Nenhum compromisso futuro cadastrado.'; return; }
            compromissos.forEach(compromisso => {
                const item = document.createElement('li');
                const data = new Date(compromisso.dataHora);
                const dataFmt = Number.isNaN(data.getTime()) ? '' : data.toLocaleString('pt-BR', { dateStyle: 'full', timeStyle: 'short' });
                const categoria = compromisso.categoria ? `[${compromisso.categoria}] ` : '';
                const origem = compromisso.criadoPeloIdoso ? ' (cadastrado por você)' : '';
                item.textContent = `${categoria}${compromisso.titulo}${origem} — ${dataFmt}${compromisso.local ? ` — ${compromisso.local}` : ''}${compromisso.observacao ? ` — Lembrete: ${compromisso.observacao}` : ''}`;
                lista.appendChild(item);
            });
        } catch (erro) { lista.textContent = erro.message || 'Não foi possível conectar ao calendário.'; }
    }
    document.addEventListener('DOMContentLoaded', carregarCompromissosIdoso, { once: true });
    window.addEventListener('pageshow', carregarCompromissosIdoso);
})();
