(() => {
    'use strict';
    const API_BASE_URL = window.ZELO_API_BASE_URL || 'http://localhost:8080';
    let compromissos = [];

    function obterIdosoAtual() {
        try {
            const escolhido = JSON.parse(localStorage.getItem('selectedIdoso') || 'null');
            if (escolhido && escolhido.id) return escolhido;
        } catch (_) {}
        try {
            const usuario = JSON.parse(localStorage.getItem('currentUser') || 'null');
            if (usuario && usuario.idIdoso) return { id: usuario.idIdoso, nome: usuario.nomeIdoso || 'Idoso vinculado' };
        } catch (_) {}
        return null;
    }
    function obterChaveCompromissos() {
        const idoso = obterIdosoAtual();
        return idoso ? `zelo_compromissos_${idoso.id}` : null;
    }
    function mostrarErro(mensagem) {
        const lista = document.getElementById('lista-visualizar');
        if (lista) lista.textContent = mensagem;
    }
    async function carregarCompromissos() {
        const idoso = obterIdosoAtual();
        if (!idoso) {
            mostrarErro('Selecione um idoso vinculado para gerenciar os compromissos.');
            return [];
        }
        try {
            const resposta = await fetch(`${API_BASE_URL}/api/compromissos/idoso/${encodeURIComponent(idoso.id)}`, {
                credentials: 'include', cache: 'no-store'
            });
            if (!resposta.ok) throw new Error(resposta.status === 401 ? 'Sua sessão expirou. Entre novamente.' : `Erro ${resposta.status} ao carregar compromissos.`);
            compromissos = await resposta.json();
            const chave = obterChaveCompromissos();
            if (chave) localStorage.setItem(chave, JSON.stringify(compromissos));
            return compromissos;
        } catch (erro) {
            mostrarErro(erro.message || 'Não foi possível sincronizar os compromissos.');
            return [];
        }
    }
    window.abrirModal = async function(modalId) {
        const modal = document.getElementById(modalId);
        if (!modal) return;
        modal.classList.remove('hidden');
        if (modalId !== 'modal-adicionar') await carregarCompromissos();
        if (modalId === 'modal-remover') carregarListaRemover();
        if (modalId === 'modal-listar') carregarListaVisualizar();
    };
    window.fecharModal = function(modalId) {
        const modal = document.getElementById(modalId);
        if (modal) modal.classList.add('hidden');
    };
    window.adicionarCompromisso = async function(event) {
        event.preventDefault();
        const idoso = obterIdosoAtual();
        if (!idoso) return alert('Antes, selecione um idoso vinculado à sua conta.');
        const form = document.getElementById('form-adicionar');
        const titulo = document.getElementById('titulo').value.trim();
        const data = document.getElementById('data').value;
        const hora = document.getElementById('hora').value;
        const local = document.getElementById('local').value.trim();
        if (!titulo || !data || !hora) return alert('Preencha título, data e horário.');
        const dataHora = `${data}T${hora}:00`;
        const botao = form.querySelector('[type="submit"]');
        botao.disabled = true;
        try {
            const resposta = await fetch(`${API_BASE_URL}/api/compromissos`, {
                method: 'POST', credentials: 'include',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ titulo, dataHora, local, idIdoso: Number(idoso.id) })
            });
            if (!resposta.ok) throw new Error(await resposta.text() || `Erro ${resposta.status} ao salvar.`);
            await resposta.json();
            form.reset();
            window.fecharModal('modal-adicionar');
            await carregarCompromissos();
            alert('Compromisso salvo e sincronizado. O idoso e os familiares vinculados receberão uma notificação push, se ativada neste dispositivo.');
        } catch (erro) {
            alert(erro.message || 'Não foi possível salvar o compromisso. Verifique a conexão e o vínculo familiar.');
        } finally { botao.disabled = false; }
    };
    function formatarData(dataHora) {
        const data = new Date(dataHora);
        return Number.isNaN(data.getTime()) ? '' : data.toLocaleString('pt-BR', { dateStyle: 'short', timeStyle: 'short' });
    }
    function criarItem(c, comBotao = false) {
        const li = document.createElement('li');
        const box = document.createElement('div');
        const titulo = document.createElement('strong');
        const origem = c.criadoPeloIdoso ? ' (cadastrado pelo idoso)' : '';
        titulo.textContent = `${c.categoria ? `[${c.categoria}] ` : ''}${c.titulo || 'Compromisso'}${origem}`;
        const detalhes = document.createElement('small');
        detalhes.textContent = `📅 ${formatarData(c.dataHora)}${c.local ? ` | 📍 ${c.local}` : ''}${c.observacao ? ` | 📝 ${c.observacao}` : ''}`;
        box.append(titulo, document.createElement('br'), detalhes);
        li.appendChild(box);
        if (comBotao) {
            const botao = document.createElement('button');
            botao.type = 'button';
            botao.className = 'btn-delete-item';
            botao.textContent = 'Excluir';
            botao.addEventListener('click', () => window.removerCompromisso(c.id));
            li.appendChild(botao);
        }
        return li;
    }
    function carregarListaVisualizar() {
        const lista = document.getElementById('lista-visualizar');
        if (!lista) return;
        lista.replaceChildren();
        if (!compromissos.length) { lista.textContent = 'Nenhum compromisso futuro cadastrado.'; return; }
        compromissos.forEach(c => lista.appendChild(criarItem(c)));
    }
    function carregarListaRemover() {
        const lista = document.getElementById('lista-remover');
        if (!lista) return;
        lista.replaceChildren();
        if (!compromissos.length) { lista.textContent = 'Nenhum compromisso para remover.'; return; }
        compromissos.forEach(c => lista.appendChild(criarItem(c, true)));
    }
    window.removerCompromisso = async function(id) {
        if (!confirm('Deseja excluir este compromisso de todos os dispositivos?')) return;
        try {
            const resposta = await fetch(`${API_BASE_URL}/api/compromissos/${encodeURIComponent(id)}`, {
                method: 'DELETE', credentials: 'include'
            });
            if (!resposta.ok) throw new Error(await resposta.text() || `Erro ${resposta.status} ao excluir.`);
            await carregarCompromissos();
            carregarListaRemover();
        } catch (erro) { alert(erro.message || 'Não foi possível excluir o compromisso.'); }
    };
    document.addEventListener('DOMContentLoaded', async () => {
        const idoso = obterIdosoAtual();
        const nome = idoso && idoso.nome ? idoso.nome : 'idoso vinculado';
        const label = document.getElementById('nome-idoso-label');
        const header = document.getElementById('header-nome-idoso');
        if (label) label.textContent = nome;
        if (header) header.textContent = nome;
        await carregarCompromissos();
        const data = document.getElementById('data');
        if (data) {
            const hoje = new Date();
            data.min = `${hoje.getFullYear()}-${String(hoje.getMonth() + 1).padStart(2, '0')}-${String(hoje.getDate()).padStart(2, '0')}`;
        }
    });
})();
