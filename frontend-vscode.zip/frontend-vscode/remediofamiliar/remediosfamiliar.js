document.addEventListener("DOMContentLoaded", () => {

    const API_BASE_URL = window.ZELO_API_BASE_URL || "http://localhost:8080";

    /* =====================================================
       ELEMENTOS
       ===================================================== */

    const btnAdicionar = document.getElementById("btn-adicionar");
    const btnRemover = document.getElementById("btn-remover");
    const btnCorGaveta = document.getElementById("btn-cor-gaveta");
    const btnLista = document.getElementById("btn-lista");

    const nomeIdosoElement = document.getElementById("nome-idoso");
    const idosoLabel = document.getElementById("idoso-label");
    const nomeFamiliar = document.getElementById("nome-familiar");


    /* =====================================================
       PEGAR IDOSO ATUAL
       ===================================================== */

    function pegarIdosoAtual() {

        const selecionado = JSON.parse(
            localStorage.getItem("selectedIdoso")
        );

        const usuario = JSON.parse(
            localStorage.getItem("currentUser")
        ) || {};


        if (selecionado && selecionado.id) {
            return {
                id: selecionado.id,
                nome: selecionado.nome || "Idoso vinculado"
            };
        }

        if (usuario.idIdoso) return { id: usuario.idIdoso, nome: usuario.nomeIdoso || "Idoso vinculado" };
        return { id: null, nome: "Idoso não selecionado" };
    }


    const idoso = pegarIdosoAtual();


    /* =====================================================
       ATUALIZAR NOME
       ===================================================== */

    nomeIdosoElement.textContent = idoso.nome.split(" ")[0];

    idosoLabel.textContent =
        `Idoso: ${idoso.nome} (ID: #${idoso.id})`;


    const usuarioAtual = JSON.parse(
        localStorage.getItem("currentUser")
    ) || {};

    nomeFamiliar.textContent =
        usuarioAtual.nome || "Familiar";


    /* =====================================================
       CHAVES DO LOCALSTORAGE
       ===================================================== */

    const chaveRemedios =
        `zelo_remedios_${idoso.id}`;

    const chaveGavetas =
        `zelo_gavetas_${idoso.id}`;


    /* =====================================================
       PEGAR REMÉDIOS
       ===================================================== */

    function pegarRemedios() {

        return JSON.parse(
            localStorage.getItem(chaveRemedios)
        ) || [];
    }


    /* =====================================================
       SALVAR REMÉDIOS
       ===================================================== */

    function salvarRemedios(remedios) {

        localStorage.setItem(
            chaveRemedios,
            JSON.stringify(remedios)
        );

        atualizarDadosDashboard();
    }


    /* =====================================================
       PEGAR GAVETAS
       ===================================================== */

    function pegarGavetas() {

        return JSON.parse(
            localStorage.getItem(chaveGavetas)
        ) || {};
    }


    /* =====================================================
       SALVAR GAVETAS
       ===================================================== */

    function salvarGavetas(gavetas) {

        localStorage.setItem(
            chaveGavetas,
            JSON.stringify(gavetas)
        );
    }


    /* =====================================================
       CRIAR MODAL
       ===================================================== */

    function criarModal(conteudo) {

        const overlay = document.createElement("div");

        overlay.className = "modal-overlay";

        overlay.innerHTML = `
            <div class="modal">
                ${conteudo}
            </div>
        `;

        document.body.appendChild(overlay);

        return overlay;
    }


    /* =====================================================
       FECHAR MODAL
       ===================================================== */

    function fecharModal(modal) {

        if (modal) {
            modal.remove();
        }
    }


    /* =====================================================
       ADICIONAR REMÉDIO
       ===================================================== */

    function adicionarRemedio() {

        if (!idoso.id) {
            alert("Selecione um idoso vinculado antes de cadastrar um remédio.");
            return;
        }

        const modal = criarModal(`

            <h2>Adicionar remédio</h2>

            <label for="nome-remedio">
                Nome do remédio
            </label>

            <input
                id="nome-remedio"
                type="text"
                placeholder="Ex.: Remédio"
            >


            <label for="dosagem-remedio">
                Dosagem
            </label>

            <input
                id="dosagem-remedio"
                type="text"
                placeholder="Ex.: 1 comprimido"
            >


            <label for="horario-remedio">
                Horário
            </label>

            <input
                id="horario-remedio"
                type="time"
            >


            <label for="intervalo-remedio">
                Repetir a cada quantas horas?
            </label>
            <input id="intervalo-remedio" type="number" min="1" max="24" value="24" inputmode="numeric">

            <label for="tipo-tratamento">Tipo de tratamento</label>
            <select id="tipo-tratamento">
                <option value="CONTINUO">Contínuo</option>
                <option value="TEMPORARIO">Temporário (excluir ao terminar)</option>
            </select>
            <div id="duracao-temporaria" hidden>
                <label for="valor-duracao">Duração do tratamento</label>
                <input id="valor-duracao" type="number" min="1" value="7" inputmode="numeric">
                <label for="unidade-duracao">Unidade de tempo</label>
                <select id="unidade-duracao">
                    <option value="DIAS">Dias</option>
                    <option value="MESES">Meses</option>
                    <option value="ANOS">Anos</option>
                </select>
            </div>

            <label for="gaveta-remedio">
                Número da gaveta
            </label>

            <select id="gaveta-remedio">

                <option value="1">
                    Gaveta 1
                </option>

                <option value="2">
                    Gaveta 2
                </option>

                <option value="3">
                    Gaveta 3
                </option>

                <option value="4">
                    Gaveta 4
                </option>

                <option value="5">
                    Gaveta 5
                </option>

                <option value="6">
                    Gaveta 6
                </option>

            </select>


            <div class="modal-buttons">

                <button
                    class="modal-btn cancel"
                    id="cancelar-adicionar">
                    Cancelar
                </button>

                <button
                    class="modal-btn confirm"
                    id="confirmar-adicionar">
                    Adicionar
                </button>

            </div>
        `);


        modal.querySelector(
            "#cancelar-adicionar"
        ).addEventListener("click", () => {

            fecharModal(modal);

        });


        modal.querySelector("#tipo-tratamento").addEventListener("change", event => {
            modal.querySelector("#duracao-temporaria").hidden = event.target.value !== "TEMPORARIO";
        });
        modal.querySelector(
            "#confirmar-adicionar"
        ).addEventListener("click", async () => {

            const nome =
                modal.querySelector("#nome-remedio")
                    .value.trim();

            const dosagem =
                modal.querySelector("#dosagem-remedio")
                    .value.trim();

            const horario =
                modal.querySelector("#horario-remedio")
                    .value;

            const intervaloHoras = Math.max(1, Math.min(24, Number.parseInt(
                modal.querySelector("#intervalo-remedio").value, 10
            ) || 24));
            const tipoTratamento = modal.querySelector("#tipo-tratamento").value;
            const valorDuracao = Number.parseInt(modal.querySelector("#valor-duracao").value, 10);
            const unidadeDuracao = modal.querySelector("#unidade-duracao").value;

            const gaveta =
                modal.querySelector("#gaveta-remedio")
                    .value;


            if (!nome) {

                alert(
                    "Digite o nome do remédio."
                );

                return;
            }


            if (tipoTratamento === "TEMPORARIO" && (!Number.isInteger(valorDuracao) || valorDuracao < 1)) {
                alert("Informe uma duração válida para o tratamento temporário.");
                return;
            }

            const agora = new Date();
            const horarioFinal = horario || agora.toTimeString().slice(0, 5);
            const dataHoje = `${agora.getFullYear()}-${String(agora.getMonth() + 1).padStart(2, '0')}-${String(agora.getDate()).padStart(2, '0')}`;
            const numeroDosagem = Number.parseFloat((dosagem.match(/[0-9]+([,.][0-9]+)?/) || ["1"])[0].replace(',', '.')) || 1;
            const textoDosagem = dosagem.toLocaleLowerCase('pt-BR');
            const unidade = textoDosagem.includes('gota') ? 'GOTAS' : textoDosagem.includes('ml') ? 'ML' : textoDosagem.includes('mg') ? 'MG' : textoDosagem.includes('g') ? 'G' : 'COMPRIMIDO';
            const payload = {
                nome, dosagem: numeroDosagem, unidade,
                quantidadePorDose: numeroDosagem,
                primeiroHorario: `${dataHoje}T${horarioFinal}:00`,
                intervaloHoras, idIdoso: Number(idoso.id),
                corCaixa: '#c4d0ff', identificadorCaixa: gaveta,
                tipoTratamento,
                unidadeDuracao: tipoTratamento === 'TEMPORARIO' ? unidadeDuracao : 'ILIMITADO',
                valorDuracao: tipoTratamento === 'TEMPORARIO' ? valorDuracao : null
            };
            try {
                const resposta = await fetch(`${API_BASE_URL}/medicamentos`, {
                    method: 'POST', credentials: 'include',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(payload)
                });
                if (!resposta.ok) throw new Error(await resposta.text() || `Erro ${resposta.status}`);
                const salvo = await resposta.json();
                const remedios = pegarRemedios();
                remedios.push({ id: salvo.id, nome, dosagem: dosagem || `${numeroDosagem} ${unidade.toLowerCase()}`, horario: horarioFinal, gaveta, tomado: false, backend: true, tipoTratamento: salvo.tipoTratamento, dataFimTratamento: salvo.dataFimTratamento });
                salvarRemedios(remedios);
                fecharModal(modal);
                alert(tipoTratamento === 'TEMPORARIO'
                    ? `Remédio temporário cadastrado. Ele será removido automaticamente do banco após ${valorDuracao} ${unidadeDuracao.toLowerCase()}.`
                    : 'Remédio cadastrado. O idoso verá o horário imediatamente.');
            } catch (erro) {
                console.error('Falha ao cadastrar remédio no backend:', erro);
                alert(`Não foi possível salvar o remédio para o idoso: ${erro.message}`);
            }

        });

    }


    /* =====================================================
       REMOVER REMÉDIO
       ===================================================== */

    function removerRemedio() {

        const remedios = pegarRemedios();


        if (remedios.length === 0) {

            alert(
                "Não existem remédios cadastrados."
            );

            return;
        }


        let listaHTML = "";


        remedios.forEach((remedio, index) => {

            listaHTML += `

                <div class="remedio-item">

                    <div class="remedio-info">

                        <strong>
                            ${index + 1}.
                            ${escaparHTML(remedio.nome)}
                        </strong>

                        <span>
                            ${escaparHTML(remedio.dosagem)}
                            |
                            Horário:
                            ${escaparHTML(remedio.horario)}
                        </span>

                        <span>
                            Gaveta ${remedio.gaveta}
                        </span>

                    </div>

                    <button
                        class="modal-btn confirm"
                        data-remedio-id="${remedio.id}">

                        Remover

                    </button>

                </div>

            `;
        });


        const modal = criarModal(`

            <h2>
                Remover remédio
            </h2>

            <p style="margin-bottom:20px;">
                Escolha qual remédio deseja remover:
            </p>

            <div>
                ${listaHTML}
            </div>

            <div class="modal-buttons">

                <button
                    class="modal-btn cancel"
                    id="fechar-remover">

                    Fechar

                </button>

            </div>

        `);


        modal.querySelector(
            "#fechar-remover"
        ).addEventListener("click", () => {

            fecharModal(modal);

        });


        modal.querySelectorAll(
            "[data-remedio-id]"
        ).forEach(botao => {

            botao.addEventListener(
                "click",
                async () => {

                    const id =
                        Number(
                            botao.dataset.remedioId
                        );


                    const remedio =
                        pegarRemedios()
                        .find(r => r.id === id);


                    if (!remedio) {
                        return;
                    }


                    const confirmou =
                        confirm(
                            `Deseja remover "${remedio.nome}"?`
                        );


                    if (!confirmou) {
                        return;
                    }


                    if (remedio.backend) {
                        try {
                            const resposta = await fetch(`${API_BASE_URL}/medicamentos/${encodeURIComponent(id)}`, {
                                method: "DELETE", credentials: "include"
                            });
                            if (!resposta.ok) throw new Error(await resposta.text() || `Erro ${resposta.status}`);
                        } catch (erro) {
                            alert(`Não foi possível remover do servidor: ${erro.message}`);
                            return;
                        }
                    }
                    const novaLista = pegarRemedios().filter(r => r.id !== id);
                    salvarRemedios(novaLista);

                    fecharModal(modal);


                    alert(
                        "Remédio removido com sucesso!"
                    );

                }
            );

        });

    }


    /* =====================================================
       DEFINIR COR DA GAVETA
       ===================================================== */

    function definirCorGaveta() {

        const gavetas = pegarGavetas();


        const modal = criarModal(`

            <h2>
                Definir cor de gaveta
            </h2>

            <label for="numero-gaveta">
                Escolha a gaveta
            </label>

            <select id="numero-gaveta">

                <option value="1">
                    Gaveta 1
                </option>

                <option value="2">
                    Gaveta 2
                </option>

                <option value="3">
                    Gaveta 3
                </option>

                <option value="4">
                    Gaveta 4
                </option>

                <option value="5">
                    Gaveta 5
                </option>

                <option value="6">
                    Gaveta 6
                </option>

            </select>


            <label for="cor-gaveta">
                Escolha a cor
            </label>

            <input
                id="cor-gaveta"
                type="color"
                value="#c4d0ff"
                style="height:60px; padding:5px;"
            >


            <div class="modal-buttons">

                <button
                    class="modal-btn cancel"
                    id="cancelar-cor">

                    Cancelar

                </button>

                <button
                    class="modal-btn confirm"
                    id="salvar-cor">

                    Salvar cor

                </button>

            </div>

        `);


        const selectGaveta =
            modal.querySelector("#numero-gaveta");

        const inputCor =
            modal.querySelector("#cor-gaveta");


        function carregarCorAtual() {

            const gaveta =
                selectGaveta.value;

            if (gavetas[gaveta]) {

                inputCor.value =
                    gavetas[gaveta];

            }

        }


        selectGaveta.addEventListener(
            "change",
            carregarCorAtual
        );


        carregarCorAtual();


        modal.querySelector(
            "#cancelar-cor"
        ).addEventListener("click", () => {

            fecharModal(modal);

        });


        modal.querySelector(
            "#salvar-cor"
        ).addEventListener("click", () => {

            const gaveta =
                selectGaveta.value;

            const cor =
                inputCor.value;


            gavetas[gaveta] = cor;

            salvarGavetas(gavetas);

            fecharModal(modal);


            alert(
                `Cor da gaveta ${gaveta} definida!`
            );

        });

    }


    /* =====================================================
       VER LISTA
       ===================================================== */

    function verLista() {

        const remedios = pegarRemedios();

        const gavetas = pegarGavetas();


        let conteudo = "";


        if (remedios.length === 0) {

            conteudo = `

                <div class="lista-vazia">

                    <div style="font-size:45px;">
                        💊
                    </div>

                    <p>
                        Nenhum remédio cadastrado.
                    </p>

                </div>

            `;

        } else {

            remedios.forEach(remedio => {

                const cor =
                    gavetas[remedio.gaveta]
                    || "#c4d0ff";


                conteudo += `

                    <div class="remedio-item">

                        <div class="remedio-info">

                            <strong>
                                💊
                                ${escaparHTML(remedio.nome)}
                            </strong>

                            <span>
                                Dosagem:
                                ${escaparHTML(remedio.dosagem)}
                            </span>

                            <span>
                                Horário:
                                ${escaparHTML(remedio.horario)}
                            </span>

                            <span>
                                Gaveta:
                                ${remedio.gaveta}
                            </span>

                        </div>

                        <div
                            class="remedio-gaveta"
                            title="Cor da gaveta ${remedio.gaveta}"
                            style="background-color:${cor};">
                        </div>

                    </div>

                `;

            });

        }


        const modal = criarModal(`

            <h2>
                Lista de remédios
            </h2>

            <p style="margin-bottom:20px; color:#555;">
                Remédios cadastrados para
                <strong>
                    ${escaparHTML(idoso.nome)}
                </strong>
            </p>

            ${conteudo}

            <div class="modal-buttons">

                <button
                    class="modal-btn cancel"
                    id="fechar-lista">

                    Fechar

                </button>

            </div>

        `);


        modal.querySelector(
            "#fechar-lista"
        ).addEventListener("click", () => {

            fecharModal(modal);

        });

    }


    /* =====================================================
       ESCAPAR HTML
       Evita que texto digitado pelo usuário vire HTML.
       ===================================================== */

    function escaparHTML(texto) {

        const div =
            document.createElement("div");

        div.textContent =
            texto ?? "";

        return div.innerHTML;

    }


    /* =====================================================
       ATUALIZAR DASHBOARD
       ===================================================== */

    async function sincronizarRemediosDoBackend() {
        if (!idoso.id || !Number.isFinite(Number(idoso.id))) return;
        try {
            const resposta = await fetch(`${API_BASE_URL}/medicamentos/idoso/${encodeURIComponent(idoso.id)}`, {
                credentials: "include", cache: "no-store"
            });
            if (!resposta.ok) throw new Error(`Erro ${resposta.status}`);
            const atuais = await resposta.json();
            const legados = pegarRemedios().filter(r => !r.backend);
            const sincronizados = atuais.map(m => ({
                id: m.id, nome: m.nome, dosagem: `${m.dosagem ?? ""} ${(m.unidade || "").toLowerCase()}`.trim(),
                horario: m.primeiroHorario ? m.primeiroHorario.slice(11, 16) : "",
                gaveta: m.identificadorCaixa || "1", tomado: false, backend: true,
                tipoTratamento: m.tipoTratamento, dataFimTratamento: m.dataFimTratamento
            }));
            salvarRemedios([...sincronizados, ...legados]);
        } catch (erro) {
            console.warn("Não foi possível sincronizar medicamentos com o servidor:", erro);
        }
    }

    function atualizarDadosDashboard() {

        const remedios = pegarRemedios();

        localStorage.setItem(
            `zelo_total_remedios_${idoso.id}`,
            remedios.length
        );

        /*
         * Dispara um evento para outras partes do sistema.
         */
        window.dispatchEvent(
            new CustomEvent(
                "zeloRemediosAtualizados",
                {
                    detail: {
                        idosoId: idoso.id,
                        total: remedios.length
                    }
                }
            )
        );

    }


    /* =====================================================
       EVENTOS DOS BOTÕES
       ===================================================== */

    btnAdicionar.addEventListener(
        "click",
        adicionarRemedio
    );

    btnRemover.addEventListener(
        "click",
        removerRemedio
    );

    btnCorGaveta.addEventListener(
        "click",
        definirCorGaveta
    );

    btnLista.addEventListener(
        "click",
        verLista
    );


    /* =====================================================
       SAIR
       ===================================================== */

    window.sair = async function(event) {

        event.preventDefault();

        try {
            await fetch(`${API_BASE_URL}/login/logout`, { method: "POST", credentials: "include" });
        } catch (erro) {
            console.warn("Não foi possível encerrar a sessão no servidor:", erro);
        }

        localStorage.removeItem(
            "currentUser"
        );

        localStorage.removeItem(
            "selectedIdoso"
        );

        window.location.href =
            "../paginainicial/paginainicial.html";

    };


    /* =====================================================
       NOTIFICAÇÕES
       ===================================================== */

    const btnSininho =
        document.getElementById("btn-sininho");

    const notifDropdown =
        document.getElementById("notif-dropdown");

    const notifLista =
        document.getElementById("notif-lista");

    const notifBadge =
        document.getElementById("notif-badge");

    const btnLimpar =
        document.getElementById("btn-limpar-notif");


    let notificacoes = [];
    let carregandoNotificacoes = false;

    function formatarHorarioNotificacao(valor) {
        if (!valor) return '';
        const data = Array.isArray(valor)
            ? new Date(valor[0], (valor[1] || 1) - 1, valor[2] || 1, valor[3] || 0, valor[4] || 0, valor[5] || 0)
            : new Date(valor);
        return Number.isNaN(data.getTime()) ? String(valor) : data.toLocaleString('pt-BR', {
            day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit'
        });
    }

    function renderizarNotificacoes(erro = '') {
        if (!notifLista || !notifBadge) return;
        notifLista.replaceChildren();
        if (erro) {
            const mensagem = document.createElement('p');
            mensagem.className = 'notif-empty';
            mensagem.textContent = erro;
            notifLista.appendChild(mensagem);
            notifBadge.style.display = 'none';
            return;
        }
        if (!notificacoes.length) {
            const vazio = document.createElement('p');
            vazio.className = 'notif-empty';
            vazio.textContent = carregandoNotificacoes ? 'Carregando notificações...' : 'Nenhuma notificação no momento.';
            notifLista.appendChild(vazio);
            notifBadge.style.display = 'none';
            return;
        }
        notifBadge.textContent = String(notificacoes.length);
        notifBadge.style.display = 'block';
        notificacoes.forEach(notificacao => {
            const item = document.createElement('div');
            item.className = 'notif-item';
            const texto = document.createElement('div');
            texto.className = 'notif-item-text';
            texto.textContent = `${notificacao.titulo ? `${notificacao.titulo}: ` : ''}${notificacao.mensagem || 'Nova notificação.'}`;
            const horario = document.createElement('div');
            horario.className = 'notif-item-time';
            horario.textContent = formatarHorarioNotificacao(notificacao.criadaEm || notificacao.hora);
            item.append(texto, horario);
            notifLista.appendChild(item);
        });
    }

    async function carregarNotificacoes() {
        if (carregandoNotificacoes) return;
        carregandoNotificacoes = true;
        renderizarNotificacoes();
        try {
            const resposta = await fetch(`${API_BASE_URL}/notificacoes`, {
                credentials: 'include', cache: 'no-store'
            });
            if (!resposta.ok) throw new Error(resposta.status === 401 ? 'Sua sessão expirou. Entre novamente.' : `Não foi possível carregar (HTTP ${resposta.status}).`);
            notificacoes = await resposta.json();
            localStorage.removeItem('zelo_notificacoes_salvas');
            renderizarNotificacoes();
        } catch (erro) {
            renderizarNotificacoes(erro.message || 'Falha ao carregar notificações do servidor.');
        } finally {
            carregandoNotificacoes = false;
        }
    }

    if (btnSininho) {
        btnSininho.addEventListener('click', async event => {
            event.stopPropagation();
            notifDropdown.classList.toggle('is-open');
            if (notifDropdown.classList.contains('is-open')) await carregarNotificacoes();
        });
    }
    document.addEventListener('click', () => {
        if (notifDropdown) notifDropdown.classList.remove('is-open');
    });
    if (btnLimpar) {
        btnLimpar.addEventListener('click', async event => {
            event.stopPropagation();
            btnLimpar.disabled = true;
            try {
                const resposta = await fetch(`${API_BASE_URL}/notificacoes`, {
                    method: 'DELETE', credentials: 'include'
                });
                if (!resposta.ok) throw new Error(await resposta.text() || `Erro ${resposta.status} ao limpar notificações.`);
                notificacoes = [];
                renderizarNotificacoes();
            } catch (erro) {
                alert(erro.message || 'Não foi possível limpar as notificações.');
            } finally {
                btnLimpar.disabled = false;
            }
        });
    }
    window.addEventListener('zelo-web-push', () => {
        // O servidor registra o aviso antes de enviar o push; recarregar a fonte oficial evita duplicatas.
        window.setTimeout(carregarNotificacoes, 250);
    });
    window.addEventListener('focus', carregarNotificacoes);
    document.addEventListener('visibilitychange', () => {
        if (document.visibilityState === 'visible') carregarNotificacoes();
    });
    renderizarNotificacoes();
    carregarNotificacoes();

    atualizarDadosDashboard();
    sincronizarRemediosDoBackend();

});
