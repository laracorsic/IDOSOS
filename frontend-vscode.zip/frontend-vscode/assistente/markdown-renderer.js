/* Renderizador Markdown enxuto para mensagens do Zelo. Não interpreta HTML fornecido pela IA. */
(() => {
    'use strict';

    const escapeHtml = (value) => String(value)
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#39;');

    const safeUrl = (value) => {
        const url = String(value || '').trim();
        if (!url || /[\u0000-\u001f]/.test(url)) return null;
        if (/^(https?:|mailto:|tel:)/i.test(url)) return url;
        if (/^[a-z][a-z\d+.-]*:/i.test(url)) return null;
        if (url.startsWith('//') || url.startsWith('\\\\')) return null;
        if (url.startsWith('#') || url.startsWith('/') || /^[^\s]+$/.test(url)) return url;
        return null;
    };

    const inline = (source, depth = 0) => {
        if (depth > 5) return escapeHtml(source);
        let text = String(source || '');
        const tokens = [];
        const stash = (html) => {
            const token = `\uE000${tokens.length}\uE001`;
            tokens.push(html);
            return token;
        };

        text = text.replace(/(`+)(.+?)\1/g, (_match, _ticks, code) =>
            stash(`<code>${escapeHtml(code)}</code>`));
        text = text.replace(/!\[([^\]]*)\]\(([^)\s]+)(?:\s+"([^"]*)")?\)/g,
            (_match, alt, target, title) => {
                const url = safeUrl(target);
                if (!url || !/^https?:/i.test(url)) return escapeHtml(_match);
                const titleAttribute = title ? ` title="${escapeHtml(title)}"` : '';
                return stash(`<img src="${escapeHtml(url)}" alt="${escapeHtml(alt)}"${titleAttribute} loading="lazy">`);
            });
        text = text.replace(/\[([^\]]+)\]\(([^)\s]+)(?:\s+"([^"]*)")?\)/g,
            (_match, label, target, title) => {
                const url = safeUrl(target);
                if (!url) return escapeHtml(_match);
                const titleAttribute = title ? ` title="${escapeHtml(title)}"` : '';
                return stash(`<a href="${escapeHtml(url)}"${titleAttribute} target="_blank" rel="noopener noreferrer">${inline(label, depth + 1)}</a>`);
            });

        text = escapeHtml(text);
        text = text
            .replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>')
            .replace(/__(.+?)__/g, '<strong>$1</strong>')
            .replace(/~~(.+?)~~/g, '<del>$1</del>')
            .replace(/(^|[^\w*])\*(?!\s)(.+?)(?<!\s)\*(?!\*)/g, '$1<em>$2</em>')
            .replace(/(^|[^\w_])_(?!\s)(.+?)(?<!\s)_(?!\w)/g, '$1<em>$2</em>')
            .replace(/\n/g, '<br>');
        return text.replace(/\uE000(\d+)\uE001/g, (_match, index) => tokens[Number(index)] || '');
    };

    const splitTableRow = (line) => line.trim().replace(/^\|/, '').replace(/\|$/, '').split(/(?<!\\)\|/).map((cell) => cell.replace(/\\\|/g, '|').trim());
    const isTableDivider = (line) => /^\s*\|?\s*:?-{3,}:?\s*(?:\|\s*:?-{3,}:?\s*)+\|?\s*$/.test(line);

    const renderBlocks = (lines, depth = 0) => {
        if (depth > 8) return `<p>${inline(lines.join('\n'))}</p>`;
        const output = [];
        let i = 0;

        while (i < lines.length) {
            const line = lines[i];
            if (!line.trim()) { i += 1; continue; }

            const fence = line.match(/^\s*(```+|~~~+)\s*([\w+-]*)\s*$/);
            if (fence) {
                const codeLines = [];
                i += 1;
                while (i < lines.length && !new RegExp(`^\\s*${fence[1][0]}{${fence[1].length},}\\s*$`).test(lines[i])) {
                    codeLines.push(lines[i]);
                    i += 1;
                }
                if (i < lines.length) i += 1;
                const language = fence[2] ? ` class="language-${escapeHtml(fence[2])}"` : '';
                output.push(`<pre><code${language}>${escapeHtml(codeLines.join('\n'))}</code></pre>`);
                continue;
            }

            const heading = line.match(/^\s{0,3}(#{1,6})\s+(.+?)\s*#*\s*$/);
            if (heading) {
                const level = heading[1].length;
                output.push(`<h${level}>${inline(heading[2])}</h${level}>`);
                i += 1;
                continue;
            }

            if (/^\s{0,3}(?:(?:\*\s*){3,}|(?:-\s*){3,}|(?:_\s*){3,})$/.test(line)) {
                output.push('<hr>');
                i += 1;
                continue;
            }

            if (i + 1 < lines.length && line.includes('|') && isTableDivider(lines[i + 1])) {
                const headers = splitTableRow(line);
                i += 2;
                const rows = [];
                while (i < lines.length && lines[i].trim() && lines[i].includes('|')) {
                    rows.push(splitTableRow(lines[i]));
                    i += 1;
                }
                const headerHtml = headers.map((cell) => `<th>${inline(cell)}</th>`).join('');
                const bodyHtml = rows.map((row) => `<tr>${headers.map((_cell, index) => `<td>${inline(row[index] || '')}</td>`).join('')}</tr>`).join('');
                output.push(`<div class="zelo-table-wrap"><table><thead><tr>${headerHtml}</tr></thead><tbody>${bodyHtml}</tbody></table></div>`);
                continue;
            }

            if (/^\s{0,3}>/.test(line)) {
                const quoteLines = [];
                while (i < lines.length && /^\s{0,3}>/.test(lines[i])) {
                    quoteLines.push(lines[i].replace(/^\s{0,3}>\s?/, ''));
                    i += 1;
                }
                output.push(`<blockquote>${renderBlocks(quoteLines, depth + 1)}</blockquote>`);
                continue;
            }

            const listMatch = line.match(/^(\s*)([-+*]|\d+[.)])\s+(.+)$/);
            if (listMatch) {
                const indent = listMatch[1].length;
                const ordered = /^\d/.test(listMatch[2]);
                const tag = ordered ? 'ol' : 'ul';
                const items = [];
                while (i < lines.length) {
                    const current = lines[i].match(/^(\s*)([-+*]|\d+[.)])\s+(.+)$/);
                    if (!current || current[1].length !== indent || /^\d/.test(current[2]) !== ordered) break;
                    const item = [current[3]];
                    i += 1;
                    while (i < lines.length) {
                        const next = lines[i];
                        const nextItem = next.match(/^(\s*)([-+*]|\d+[.)])\s+(.+)$/);
                        if (nextItem && nextItem[1].length <= indent) break;
                        if (nextItem && nextItem[1].length > indent) {
                            item.push(next);
                            i += 1;
                            continue;
                        }
                        if (next.trim() && /^\s+/.test(next)) {
                            item.push(next.trim());
                            i += 1;
                            continue;
                        }
                        break;
                    }
                    const primary = inline(item.shift() || '');
                    const nested = item.length ? renderBlocks(item, depth + 1) : '';
                    items.push(`<li>${primary}${nested}</li>`);
                }
                output.push(`<${tag}>${items.join('')}</${tag}>`);
                continue;
            }

            const paragraph = [line.trim()];
            i += 1;
            while (i < lines.length && lines[i].trim()) {
                if (/^\s{0,3}(?:#{1,6}\s|>|```|~~~)/.test(lines[i]) || /^(\s*)([-+*]|\d+[.)])\s+/.test(lines[i])) break;
                if (i + 1 < lines.length && isTableDivider(lines[i + 1]) && lines[i].includes('|')) break;
                paragraph.push(lines[i].trim());
                i += 1;
            }
            output.push(`<p>${inline(paragraph.join('\n'))}</p>`);
        }
        return output.join('\n');
    };

    const renderMarkdown = (source) => renderBlocks(String(source || '').replace(/\r\n?/g, '\n').split('\n'));
    window.ZeloMarkdown = Object.freeze({ render: renderMarkdown });
})();
