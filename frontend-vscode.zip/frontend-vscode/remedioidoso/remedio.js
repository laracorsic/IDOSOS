const API_BASE_URL = window.ZELO_API_BASE_URL || 'http://localhost:8080';
let doseAtual = null;
let doses = [];

function obterIdosoId() {
    try {
        const usuario = JSON.parse(localStorage.getItem('currentUser') || '{}');
        const selecionado = JSON.parse(localStorage.getItem('selectedIdoso') || '{}');
        return Number(usuario.id || selecionado.id || usuario.idIdoso);
    } catch (_) { return 0; }
}
function escaparHTML(valor) { const div = document.createElement('div'); div.textContent = valor ?? ''; return div.innerHTML; }
function horarioDaDose(dose) { const data = new Date(dose.horarioProgramado); return Number.isNaN(data.getTime()) ? 0 : data.getTime(); }
function formatarHorario(valor) { const data = new Date(valor); return Number.isNaN(data.getTime()) ? String(valor || '').slice(11, 16) : data.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' }); }
function formatarContagem(millis) {
    const total = Math.max(0, Math.floor(millis / 1000));
    return `${String(Math.floor(total / 3600)).padStart(2, '0')}:${String(Math.floor((total % 3600) / 60)).padStart(2, '0')}:${String(total % 60).padStart(2, '0')}`;
}
function escolherProximaDose() {
    const agora = Date.now();
    const pendentes = doses.filter(dose => dose.status === 'PENDENTE' || dose.status === 'NOTIFICADO');
    doseAtual = pendentes.sort((a, b) => {
        const aFuturo = horarioDaDose(a) >= agora, bFuturo = horarioDaDose(b) >= agora;
        if (aFuturo !== bFuturo) return aFuturo ? -1 : 1;
        return horarioDaDose(a) - horarioDaDose(b);
    })[0] || null;
}
function atualizarContador() {
    const contador = document.getElementById('med-countdown');
    if (!contador || !doseAtual) return;
    const restante = horarioDaDose(doseAtual) - Date.now();
    contador.textContent = restante > 0 ? `Faltam ${formatarContagem(restante)}` : 'É hora do remédio';
}
function renderizarLista(medicamentos) {
    const lista = document.getElementById('medication-list');
    if (!lista) return;
    lista.innerHTML = medicamentos.length ? medicamentos.map(medicamento => {
        const dose = doses.filter(item => item.idMedicamento === medicamento.id).sort((a, b) => horarioDaDose(a) - horarioDaDose(b))[0];
        return `<article class="medication-item"><strong>💊 ${escaparHTML(medicamento.nome)}</strong><span>${escaparHTML(String(medicamento.dosagem ?? ''))} ${escaparHTML(medicamento.unidade || '')} · ${dose ? formatarHorario(dose.horarioProgramado) : 'horário em atualização'}</span></article>`;
    }).join('') : '<p>Nenhum remédio foi cadastrado ainda pelo familiar.</p>';
}
function atualizarPainel(medicamentos) {
    escolherProximaDose();
    const detalhes = document.getElementById('next-med-details');
    const contador = document.getElementById('med-countdown');
    const status = document.getElementById('status-badge');
    const botao = document.getElementById('btn-notify');
    if (!doseAtual) {
        detalhes.textContent = medicamentos.length ? 'Nenhum horário pendente.' : 'Nenhum remédio cadastrado.';
        contador.textContent = 'Aguardando cadastro ou atualização do familiar.';
        status.textContent = '✅ NENHUMA DOSE PENDENTE';
        status.className = 'status-badge status-taken';
        botao.disabled = true;
        return;
    }
    detalhes.textContent = `${doseAtual.nomeMedicamento} às ${formatarHorario(doseAtual.horarioProgramado)}`;
    status.textContent = doseAtual.status === 'NOTIFICADO' ? '🔔 LEMBRETE ENVIADO' : '⚠️ AINDA NÃO TOMADO!';
    status.className = 'status-badge status-not-taken';
    botao.disabled = false;
    atualizarContador();
}
async function carregarMedicamentos() {
    const idosoId = obterIdosoId();
    if (!idosoId) return;
    try {
        const [medicamentosResposta, dosesResposta] = await Promise.all([
            fetch(`${API_BASE_URL}/medicamentos/idoso/${idosoId}`, { credentials: 'include', cache: 'no-store' }),
            fetch(`${API_BASE_URL}/doses/idoso/${idosoId}`, { credentials: 'include', cache: 'no-store' })
        ]);
        if (!medicamentosResposta.ok || !dosesResposta.ok) throw new Error('Não foi possível consultar os medicamentos.');
        const medicamentos = await medicamentosResposta.json();
        doses = await dosesResposta.json();
        renderizarLista(medicamentos);
        atualizarPainel(medicamentos);
    } catch (erro) {
        console.error('Erro ao carregar remédios do idoso:', erro);
        document.getElementById('next-med-details').textContent = 'Não foi possível carregar os remédios agora.';
        document.getElementById('med-countdown').textContent = 'Verifique se o backend está conectado.';
    }
}
async function confirmarDoseAtual() {
    if (!doseAtual) return;
    const botao = document.getElementById('btn-notify');
    botao.disabled = true;
    try {
        const resposta = await fetch(`${API_BASE_URL}/doses/${doseAtual.id}/confirmar`, { method: 'PUT', credentials: 'include' });
        if (!resposta.ok) throw new Error(await resposta.text() || 'Não foi possível confirmar a dose.');
        document.getElementById('status-badge').textContent = '✅ O REMÉDIO FOI TOMADO!';
        document.getElementById('status-badge').className = 'status-badge status-taken';
        botao.textContent = 'DOSE CONFIRMADA';
        if (typeof ZeloSync !== 'undefined') ZeloSync.emitirEvento('REMEDIO_TOMADO', { mensagem: `${doseAtual.nomeMedicamento} foi tomado.`, idoso: 'Idoso' });
        await carregarMedicamentos();
    } catch (erro) { botao.disabled = false; alert(erro.message); }
}
document.addEventListener('DOMContentLoaded', () => {
    document.getElementById('btn-notify')?.addEventListener('click', confirmarDoseAtual);
    carregarMedicamentos();
    window.setInterval(atualizarContador, 1000);
    window.setInterval(carregarMedicamentos, 30000);
});
