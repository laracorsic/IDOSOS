(() => {
    'use strict';
    const API_BASE_URL = window.ZELO_API_BASE_URL || 'http://localhost:8080';

    function obterIdosoAtual() {
        try {
            const salvo = JSON.parse(localStorage.getItem('selectedIdoso') || 'null');
            if (salvo && salvo.id) return salvo;
        } catch (_) {}
        const usuario = JSON.parse(localStorage.getItem('currentUser') || '{}');
        if (usuario.idIdoso) return { id: usuario.idIdoso, nome: usuario.nomeIdoso || 'Idoso vinculado' };
        return null;
    }
    function obterDataAtualLocal() {
        const agora = new Date();
        return `${agora.getFullYear()}-${String(agora.getMonth() + 1).padStart(2, '0')}-${String(agora.getDate()).padStart(2, '0')}`;
    }
    async function carregarIdososVinculados() {
        const usuario = JSON.parse(localStorage.getItem('currentUser') || '{}');
        const lista = document.getElementById('linked-idosos-list');
        if (!lista || !usuario.id) return;
        try {
            const resposta = await fetch(`${API_BASE_URL}/api/vinculos/familiar/${usuario.id}/idosos`, { credentials: 'include', cache: 'no-store' });
            if (!resposta.ok) throw new Error('Não foi possível carregar os vínculos.');
            const idosos = await resposta.json();
            lista.innerHTML = idosos.length ? idosos.map(idoso => `<li><button type="button" class="chat-open" onclick="localStorage.setItem('selectedIdoso', JSON.stringify({id:${idoso.id},nome:'Idoso'})); location.reload();">${idoso.nome} · ID ${idoso.id}</button></li>`).join('') : '<li>Nenhum idoso vinculado ainda.</li>';
        } catch (erro) { lista.innerHTML = '<li>Não foi possível atualizar os vínculos agora.</li>'; }
    }
    async function atualizarTotaisDashboard() {
        const idoso = obterIdosoAtual();
        const idosoLabel = document.getElementById('current-idoso-label');
        if (idosoLabel) idosoLabel.textContent = idoso ? `Idoso: ${idoso.nome}` : 'Vincule ou selecione um idoso';
        if (!idoso) return;
        const chaveLembretes = `zelo_lembretes_${idoso.id}`;
        const lembretes = JSON.parse(localStorage.getItem(chaveLembretes) || '[]');
        const totalLembretesCard = document.getElementById('total-lembretes-card');
        if (totalLembretesCard) totalLembretesCard.textContent = `${lembretes.length} ${lembretes.length === 1 ? 'cadastrado' : 'cadastrados'}`;

        const chaveCompromissos = `zelo_compromissos_${idoso.id}`;
        let compromissos = JSON.parse(localStorage.getItem(chaveCompromissos) || '[]');
        try {
            const resposta = await fetch(`${API_BASE_URL}/api/compromissos/idoso/${encodeURIComponent(idoso.id)}`, {
                credentials: 'include', cache: 'no-store'
            });
            if (resposta.ok) {
                compromissos = await resposta.json();
                localStorage.setItem(chaveCompromissos, JSON.stringify(compromissos));
            }
        } catch (erro) { console.warn('Não foi possível atualizar compromissos do painel:', erro); }
        const hoje = obterDataAtualLocal();
        const hojeLista = compromissos.filter(c => (c.dataHora ? c.dataHora.slice(0, 10) : c.data) === hoje);
        const cardCompromissos = document.getElementById('card-compromissos');
        const descricao = document.getElementById('card-compromisso-desc');
        if (cardCompromissos) cardCompromissos.textContent = hojeLista.length;
        if (descricao) descricao.textContent = hojeLista.length === 1 ? 'Compromisso hoje' : hojeLista.length > 1 ? 'Compromissos hoje' : 'Nenhum hoje';
        const total = document.getElementById('total-compromissos-card');
        if (total) total.textContent = `${compromissos.length} ${compromissos.length === 1 ? 'cadastrado' : 'cadastrados'}`;
        try {
            const resposta = await fetch(`${API_BASE_URL}/medicamentos/idoso/${encodeURIComponent(idoso.id)}`, {
                credentials: 'include', cache: 'no-store'
            });
            if (resposta.ok) {
                const medicamentos = await resposta.json();
                const totalRemedios = document.getElementById('total-remedios-card');
                if (totalRemedios) totalRemedios.textContent = `${medicamentos.length} ${medicamentos.length === 1 ? 'cadastrado' : 'cadastrados'}`;
                localStorage.setItem(`zelo_total_remedios_${idoso.id}`, String(medicamentos.length));
            }
        } catch (erro) { console.warn('Não foi possível atualizar remédios do painel:', erro); }
    }
    document.addEventListener('DOMContentLoaded', () => {
        atualizarTotaisDashboard();
        carregarIdososVinculados();
        window.setInterval(() => {
            atualizarTotaisDashboard();
            carregarIdososVinculados();
        }, 5000);
    });
    window.addEventListener('pageshow', atualizarTotaisDashboard);
})();
