(() => {
    'use strict';

    const API_BASE_URL = window.ZELO_API_BASE_URL || 'http://localhost:8080';
    // Os painéis ficam em subpastas; configurações fica na raiz do frontend.
    const telaEmSubpasta = /\/(?:inicioidoso|iniciofamiliar)\//.test(window.location.pathname);
    const SW_URL = new URL(telaEmSubpasta ? '../sw.js' : 'sw.js', document.baseURI).toString();
    const SW_SCOPE = new URL('.', SW_URL).pathname;

    function usuarioLogado() {
        try {
            return JSON.parse(localStorage.getItem('currentUser') || 'null');
        } catch (_) {
            return null;
        }
    }

    function base64ParaBytes(valor) {
        const preenchido = valor.replace(/-/g, '+').replace(/_/g, '/');
        const padding = '='.repeat((4 - (preenchido.length % 4)) % 4);
        const binario = atob(preenchido + padding);
        return Uint8Array.from(binario, (caractere) => caractere.charCodeAt(0));
    }

    function mostrarAviso(mensagem, tipo = 'info') {
        let aviso = document.getElementById('zelo-push-aviso');
        if (!aviso) {
            aviso = document.createElement('div');
            aviso.id = 'zelo-push-aviso';
            aviso.setAttribute('role', 'status');
            aviso.style.cssText = 'position:fixed;z-index:10000;left:20px;right:20px;bottom:20px;padding:18px 20px;border-radius:14px;background:#fff;box-shadow:0 6px 24px rgba(0,0,0,.2);font:600 16px/1.4 Arial,sans-serif;color:#17324d;display:flex;gap:14px;align-items:center;justify-content:space-between;';
            document.body.appendChild(aviso);
        }
        aviso.style.borderLeft = `7px solid ${tipo === 'erro' ? '#c0392b' : '#2676d9'}`;
        aviso.innerHTML = `<span>${mensagem}</span><button type="button" aria-label="Fechar aviso" style="border:0;background:transparent;font-size:26px;cursor:pointer;padding:8px 12px">×</button>`;
        aviso.querySelector('button').onclick = () => aviso.remove();
    }

    async function registrarInscricao() {
        if (!('serviceWorker' in navigator) || !('PushManager' in window) || !('Notification' in window)) return;
        if (!usuarioLogado()) return;

        const configResponse = await fetch(`${API_BASE_URL}/notificacoes/push/configuracao`, { credentials: 'include' });
        if (!configResponse.ok) throw new Error(`Configuração de notificações indisponível (${configResponse.status})`);
        const config = await configResponse.json();
        if (!config.enabled || !config.publicKey) throw new Error('Web Push não está configurado no servidor.');

        const registro = await navigator.serviceWorker.register(SW_URL, { scope: SW_SCOPE });
        await navigator.serviceWorker.ready;
        let inscricao = await registro.pushManager.getSubscription();
        if (!inscricao) {
            if (Notification.permission === 'denied') throw new Error('As notificações estão bloqueadas no navegador. Libere-as nas configurações do site.');
            const permissao = await Notification.requestPermission();
            if (permissao !== 'granted') throw new Error('Permissão para notificações não concedida.');
            inscricao = await registro.pushManager.subscribe({
                userVisibleOnly: true,
                applicationServerKey: base64ParaBytes(config.publicKey)
            });
        }

        const resposta = await fetch(`${API_BASE_URL}/notificacoes/push/inscricoes`, {
            method: 'POST',
            credentials: 'include',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(inscricao.toJSON())
        });
        if (!resposta.ok) throw new Error(`Não foi possível salvar a inscrição (${resposta.status}).`);
        localStorage.setItem('zeloPushAtivo', 'true');
        return true;
    }

    function adicionarBotaoAtivacao() {
        if (document.getElementById('zelo-ativar-push')) return;
        const botao = document.createElement('button');
        botao.id = 'zelo-ativar-push';
        botao.type = 'button';
        botao.textContent = 'Ativar notificações neste computador';
        botao.setAttribute('aria-label', 'Ativar notificações neste computador');
        botao.style.cssText = 'position:fixed;z-index:9999;right:20px;bottom:20px;padding:16px 22px;border:0;border-radius:14px;background:#1d70d6;color:white;font:700 16px Arial,sans-serif;cursor:pointer;box-shadow:0 4px 14px rgba(0,0,0,.25);min-height:52px;';
        botao.onclick = async () => {
            botao.disabled = true;
            botao.textContent = 'Ativando...';
            try {
                await registrarInscricao();
                botao.remove();
                mostrarAviso('Notificações ativadas neste computador.', 'info');
            } catch (erro) {
                botao.disabled = false;
                botao.textContent = 'Tentar ativar notificações novamente';
                mostrarAviso(erro.message || 'Não foi possível ativar as notificações.', 'erro');
            }
        };
        document.body.appendChild(botao);
    }

    async function iniciar() {
        if (!usuarioLogado()) return;
        try {
            if (Notification.permission === 'granted') {
                await registrarInscricao();
                return;
            }
            adicionarBotaoAtivacao();
        } catch (erro) {
            console.warn('[Zelo Web Push]', erro);
            adicionarBotaoAtivacao();
        }
    }

    window.zeloAtivarNotificacoes = registrarInscricao;
    if ('serviceWorker' in navigator) {
        navigator.serviceWorker.addEventListener('message', (evento) => {
            if (evento.data && evento.data.tipo === 'WEB_PUSH_RECEBIDO') {
                window.dispatchEvent(new CustomEvent('zelo-web-push', { detail: evento.data }));
            }
        });
    }
    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', iniciar, { once: true });
    else iniciar();
})();
