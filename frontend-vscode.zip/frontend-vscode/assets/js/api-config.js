// Endereço da API. Em localhost/127.0.0.1 mantemos o mesmo host do frontend
// para que o cookie SameSite=Lax de desenvolvimento acompanhe as requisições.
(() => {
    const hostname = window.location.hostname;
    const hostApi = hostname === '127.0.0.1' || hostname === 'localhost' ? hostname : 'localhost';
    window.ZELO_API_BASE_URL = window.ZELO_API_BASE_URL || `http://${hostApi}:8080`;
})();
