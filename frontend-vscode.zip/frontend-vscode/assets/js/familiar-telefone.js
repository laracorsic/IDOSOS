(() => {
  const API = window.ZELO_API_BASE_URL || 'http://localhost:8080';
  document.addEventListener('DOMContentLoaded', () => {
    const form = document.getElementById('form-adicionar-familiar-telefone');
    const status = document.getElementById('adicionar-familiar-status');
    if (!form || !status) return;
    form.addEventListener('submit', async event => {
      event.preventDefault();
      let usuario = {};
      try { usuario = JSON.parse(localStorage.getItem('currentUser') || '{}'); } catch (_) {}
      const telefone = form.telefone.value.trim();
      if (!usuario.id || !telefone) return;
      const botao = form.querySelector('button[type="submit"]');
      botao.disabled = true;
      status.textContent = 'Procurando familiar...';
      try {
        const resposta = await fetch(`${API}/api/vinculos/adicionar-por-telefone`, {
          method: 'POST', credentials: 'include', headers: {'Content-Type': 'application/json'},
          body: JSON.stringify({idIdoso: Number(usuario.id), telefone})
        });
        const texto = await resposta.text();
        if (!resposta.ok) throw new Error(texto || 'Não encontramos um familiar com esse telefone.');
        status.textContent = texto || 'Familiar adicionado! Ele recebeu uma notificação.';
        form.reset();
        window.dispatchEvent(new Event('zelo-vinculo-atualizado'));
      } catch (erro) { status.textContent = erro.message || 'Não foi possível adicionar o familiar.'; }
      finally { botao.disabled = false; }
    });
  });
})();
