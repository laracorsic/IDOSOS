(() => {
  'use strict';
  const API = window.ZELO_API_BASE_URL || 'http://localhost:8080';
  function lerUsuario() {
    try { return JSON.parse(localStorage.getItem('currentUser') || 'null'); } catch (_) { return null; }
  }
  function desenhar(usuario) {
    if (!usuario) return;
    const nome = usuario.nome || 'Usuário';
    const nomeEl = document.getElementById('user-name');
    if (nomeEl) nomeEl.textContent = nome;
    const candidata = usuario.imagemUrl || '';
    const foto = typeof candidata === 'string' && candidata.length <= 500000 &&
      (candidata.startsWith('data:image/jpeg;base64,') || candidata.startsWith('https://')) ? candidata : '';
    ['user-avatar-photo', 'home-profile-photo'].forEach((id) => {
      const img = document.getElementById(id);
      if (!img) return;
      if (foto) {
        img.src = foto;
        img.hidden = false;
        const fallback = document.getElementById(id === 'user-avatar-photo' ? 'user-avatar-fallback' : 'home-profile-fallback');
        if (fallback) fallback.hidden = true;
      }
    });
  }
  async function atualizar() {
    const usuario = lerUsuario();
    desenhar(usuario);
    if (!usuario?.id) return;
    try {
      const response = await fetch(`${API}/usuarios/${encodeURIComponent(usuario.id)}`, { credentials: 'include', cache: 'no-store' });
      if (!response.ok) return;
      const perfil = await response.json();
      const atualizado = { ...usuario, ...perfil, userType: String(perfil.perfil || usuario.userType || '').toLowerCase() };
      localStorage.setItem('currentUser', JSON.stringify(atualizado));
      desenhar(atualizado);
    } catch (_) {}
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', atualizar, { once: true });
  else atualizar();
})();
