(() => {
  'use strict';
  const API = window.ZELO_API_BASE_URL || 'http://localhost:8080';
  const $ = (selector) => document.querySelector(selector);
  let usuario = null;
  let perfil = null;

  function status(mensagem, erro = false) {
    const el = $('#page-status');
    if (!el) return;
    el.textContent = mensagem;
    el.classList.toggle('error', erro);
  }
  async function request(url, options = {}) {
    const response = await fetch(`${API}${url}`, {
      credentials: 'include', cache: 'no-store', ...options,
      headers: { ...(options.body ? { 'Content-Type': 'application/json' } : {}), ...(options.headers || {}) }
    });
    const text = await response.text();
    let data = text;
    try { data = text ? JSON.parse(text) : {}; } catch (_) {}
    if (!response.ok) {
      const message = typeof data === 'string' ? data : (data.message || data.errors?.join(' ') || `Não foi possível concluir (${response.status}).`);
      throw new Error(message);
    }
    return data;
  }
  function salvarUsuarioLocal() {
    const merged = { ...(usuario || {}), ...(perfil || {}) };
    merged.userType = String(merged.perfil || merged.tipo || usuario?.userType || '').toLowerCase();
    localStorage.setItem('currentUser', JSON.stringify(merged));
    usuario = merged;
  }
  function destinoPainel() {
    return usuario?.userType === 'familiar' ? 'iniciofamiliar/iniciofamiliar.html' : 'inicioidoso/inicioidoso.html';
  }
  function definirFoto(dataUrl) {
    const image = $('#profile-photo');
    const initials = $('#profile-initials');
    const remove = $('#remove-photo');
    const fotoSegura = typeof dataUrl === 'string' && dataUrl.length <= 500000 &&
      (dataUrl.startsWith('data:image/jpeg;base64,') || dataUrl.startsWith('https://'));
    if (fotoSegura) {
      image.src = dataUrl;
      image.hidden = false;
      initials.hidden = true;
      remove.hidden = false;
    } else {
      image.removeAttribute('src');
      image.hidden = true;
      initials.hidden = false;
      remove.hidden = true;
      const nome = perfil?.nome || usuario?.nome || 'Zelo';
      initials.textContent = nome.trim().split(/\s+/).slice(0, 2).map(p => p[0]?.toUpperCase()).join('') || 'Z';
    }
  }
  async function carregarPerfil() {
    let sessao;
    try { sessao = await request('/login'); }
    catch (_) {
      localStorage.removeItem('currentUser');
      window.location.replace('login.html');
      return false;
    }
    usuario = sessao;
    usuario.userType = String(sessao.perfil || sessao.tipo || '').toLowerCase();
    if (!['idoso', 'familiar'].includes(usuario.userType)) {
      window.location.replace('login.html');
      return false;
    }
    perfil = await request(`/usuarios/${encodeURIComponent(usuario.id)}`);
    $('#profile-name').textContent = perfil.nome || 'Minha conta';
    $('#profile-email-summary').textContent = perfil.email || '';
    $('#profile-kind').textContent = usuario.userType === 'idoso' ? 'Perfil idoso' : 'Perfil familiar';
    $('#name').value = perfil.nome || '';
    $('#email').value = perfil.email || '';
    $('#phone').value = perfil.telefone || '';
    $('#voltar-painel').href = destinoPainel();
    $('#footer-back').href = destinoPainel();
    $('#audio-home-link').href = destinoPainel();
    definirFoto(perfil.imagemUrl || '');
    salvarUsuarioLocal();
    return true;
  }
  function aplicarImagemRedimensionada(file) {
    return new Promise((resolve, reject) => {
      if (!file || !/^image\/(jpeg|png|webp)$/.test(file.type)) return reject(new Error('Escolha uma foto JPEG, PNG ou WebP.'));
      if (file.size > 8 * 1024 * 1024) return reject(new Error('A foto original precisa ter menos de 8 MB.'));
      const reader = new FileReader();
      reader.onerror = () => reject(new Error('Não foi possível ler esta imagem.'));
      reader.onload = () => {
        const image = new Image();
        image.onerror = () => reject(new Error('O arquivo selecionado não parece ser uma imagem válida.'));
        image.onload = () => {
          const limite = 512;
          const escala = Math.min(1, limite / Math.max(image.naturalWidth, image.naturalHeight));
          const canvas = document.createElement('canvas');
          canvas.width = Math.max(1, Math.round(image.naturalWidth * escala));
          canvas.height = Math.max(1, Math.round(image.naturalHeight * escala));
          const context = canvas.getContext('2d', { alpha: false });
          context.fillStyle = '#ffffff';
          context.fillRect(0, 0, canvas.width, canvas.height);
          context.drawImage(image, 0, 0, canvas.width, canvas.height);
          const dataUrl = canvas.toDataURL('image/jpeg', 0.78);
          if (dataUrl.length > 410000) return reject(new Error('A foto ficou grande demais. Escolha outra imagem com menos detalhes.'));
          resolve(dataUrl);
        };
        image.src = String(reader.result);
      };
      reader.readAsDataURL(file);
    });
  }
  async function atualizarCampo(campo, valor) {
    const atualizado = await request(`/usuarios/${usuario.id}/${campo}`, {
      method: 'PUT', body: JSON.stringify({ [campo === 'nome' ? 'nome' : campo]: valor })
    });
    perfil = { ...perfil, ...atualizado };
    salvarUsuarioLocal();
  }
  function configurarFormularios() {
    $('#profile-form').addEventListener('submit', async (event) => {
      event.preventDefault();
      const form = event.currentTarget;
      if (!form.reportValidity()) return;
      const email = $('#email').value.trim().toLowerCase();
      const phone = $('#phone').value.trim();
      const name = $('#name').value.trim();
      const digits = phone.replace(/\D/g, '').replace(/^55(?=\d{10,11})/, '');
      if (![10, 11].includes(digits.length)) return status('Informe um telefone válido com DDD.', true);
      const button = form.querySelector('[type=submit]');
      button.disabled = true;
      try {
        if (name !== perfil.nome) await atualizarCampo('nome', name);
        if (email !== perfil.email) await atualizarCampo('email', email);
        if (phone !== perfil.telefone) await atualizarCampo('telefone', phone);
        $('#profile-name').textContent = perfil.nome;
        $('#profile-email-summary').textContent = perfil.email;
        definirFoto(perfil.imagemUrl || '');
        status('Seus dados foram atualizados.');
      } catch (error) { status(error.message, true); }
      finally { button.disabled = false; }
    });

    $('#password-form').addEventListener('submit', async (event) => {
      event.preventDefault();
      const form = event.currentTarget;
      if (!form.reportValidity()) return;
      if ($('#new-password').value !== $('#confirm-password').value) return status('A confirmação da nova senha não confere.', true);
      if ($('#current-password').value === $('#new-password').value) return status('Escolha uma senha diferente da atual.', true);
      const button = form.querySelector('[type=submit]');
      button.disabled = true;
      try {
        const result = await request(`/usuarios/${usuario.id}/senha`, {
          method: 'PUT', body: JSON.stringify({ senhaAtual: $('#current-password').value, novaSenha: $('#new-password').value })
        });
        form.reset();
        status(result.message || 'Senha atualizada. Este aparelho continuará conectado.');
      } catch (error) { status(error.message, true); }
      finally { button.disabled = false; }
    });

    $('#photo-file').addEventListener('change', async (event) => {
      const file = event.currentTarget.files?.[0];
      if (!file) return;
      status('Preparando sua foto…');
      try {
        const imagemUrl = await aplicarImagemRedimensionada(file);
        const atualizado = await request(`/usuarios/${usuario.id}/foto`, {
          method: 'PUT', body: JSON.stringify({ imagemUrl })
        });
        perfil = { ...perfil, ...atualizado };
        definirFoto(perfil.imagemUrl);
        salvarUsuarioLocal();
        status('Foto de perfil atualizada.');
      } catch (error) { status(error.message, true); }
      finally { event.currentTarget.value = ''; }
    });

    $('#remove-photo').addEventListener('click', async () => {
      if (!confirm('Remover a foto de perfil?')) return;
      try {
        const atualizado = await request(`/usuarios/${usuario.id}/foto`, { method: 'PUT', body: JSON.stringify({ imagemUrl: null }) });
        perfil = { ...perfil, ...atualizado };
        definirFoto('');
        salvarUsuarioLocal();
        status('Foto removida.');
      } catch (error) { status(error.message, true); }
    });

    document.querySelectorAll('[data-font-choice]').forEach((button) => button.addEventListener('click', () => {
      window.zeloAcessibilidade?.salvar({ fonte: button.dataset.fontChoice });
    }));
    $('#contrast-toggle').addEventListener('change', (event) => window.zeloAcessibilidade?.salvar({ contraste: event.currentTarget.checked }));

    atualizarEstadoNotificacoes();
    $('#enable-notifications').addEventListener('click', async (event) => {
      const button = event.currentTarget;
      button.disabled = true;
      try {
        if (typeof window.zeloAtivarNotificacoes !== 'function') throw new Error('Não foi possível carregar o serviço de notificações. Atualize a página e tente novamente.');
        await window.zeloAtivarNotificacoes();
        localStorage.setItem('zeloPushAtivo', 'true');
        status('Notificações ativadas neste navegador.');
      } catch (error) { status(error.message, true); }
      finally { button.disabled = false; atualizarEstadoNotificacoes(); }
    });
    $('#disable-notifications').addEventListener('click', async (event) => {
      const button = event.currentTarget;
      button.disabled = true;
      try {
        if (!('serviceWorker' in navigator)) throw new Error('Este navegador não oferece notificações push.');
        const scope = new URL('.', new URL(/\/(?:inicioidoso|iniciofamiliar)\//.test(location.pathname) ? '../sw.js' : 'sw.js', document.baseURI)).pathname;
        const registration = await navigator.serviceWorker.getRegistration(scope);
        const subscription = await registration?.pushManager.getSubscription();
        if (subscription) {
          await request('/notificacoes/push/inscricoes', {
            method: 'DELETE', body: JSON.stringify({ endpoint: subscription.endpoint })
          });
          await subscription.unsubscribe();
        }
        localStorage.removeItem('zeloPushAtivo');
        status('Notificações desativadas neste navegador.');
      } catch (error) { status(error.message, true); }
      finally { button.disabled = false; atualizarEstadoNotificacoes(); }
    });

    $('#logout-all').addEventListener('click', async (event) => {
      if (!confirm('Sair de todos os aparelhos? Os acessos lembrados serão revogados e você voltará à tela de entrada.')) return;
      event.currentTarget.disabled = true;
      try {
        await request(`/usuarios/${usuario.id}/acessos-lembrados`, { method: 'DELETE' });
        localStorage.removeItem('currentUser');
        localStorage.removeItem('selectedIdoso');
        window.location.replace('login.html');
      } catch (error) { status(error.message, true); event.currentTarget.disabled = false; }
    });
    $('#logout-current').addEventListener('click', () => window.sairDaConta());

    $('#delete-form').addEventListener('submit', async (event) => {
      event.preventDefault();
      if (!event.currentTarget.reportValidity()) return;
      if (!confirm('Esta ação é permanente. Tem certeza de que deseja excluir sua conta?')) return;
      const button = event.currentTarget.querySelector('[type=submit]');
      button.disabled = true;
      try {
        await request(`/usuarios/${usuario.id}`, { method: 'DELETE', body: JSON.stringify({ senha: $('#delete-password').value }) });
        localStorage.removeItem('currentUser');
        localStorage.removeItem('selectedIdoso');
        alert('Sua conta foi excluída.');
        window.location.replace('paginainicial/paginainicial.html');
      } catch (error) { status(error.message, true); button.disabled = false; }
    });
  }
  function atualizarEstadoNotificacoes() {
    const state = $('#notification-state');
    const button = $('#enable-notifications');
    const disableButton = $('#disable-notifications');
    if (disableButton) disableButton.hidden = localStorage.getItem('zeloPushAtivo') !== 'true';
    if (!('Notification' in window)) {
      state.textContent = 'Este navegador não oferece notificações push.';
      button.disabled = true;
      return;
    }
    const permission = Notification.permission;
    if (permission === 'granted' && localStorage.getItem('zeloPushAtivo') === 'true') {
      state.textContent = 'Notificações estão ativadas neste aparelho.';
      button.textContent = 'Atualizar inscrição de notificações';
    } else if (permission === 'denied') {
      state.textContent = 'As notificações estão bloqueadas. Libere a permissão nas configurações do navegador para ativá-las.';
      button.textContent = 'Permissão bloqueada no navegador';
      button.disabled = true;
    } else {
      state.textContent = 'As notificações estão desativadas neste aparelho.';
    }
  }
  window.sairDaConta = async () => {
    try { await request('/login/logout', { method: 'POST' }); } catch (_) {}
    localStorage.removeItem('currentUser');
    localStorage.removeItem('selectedIdoso');
    window.location.replace('login.html');
  };
  document.addEventListener('DOMContentLoaded', async () => {
    try {
      const ok = await carregarPerfil();
      if (!ok) return;
      configurarFormularios();
    } catch (error) { status(error.message || 'Não foi possível carregar suas configurações.', true); }
  });
})();
