(() => {
  'use strict';
  const STORAGE_KEY = 'zeloAcessibilidade';
  function obterPreferencias() {
    try { return JSON.parse(localStorage.getItem(STORAGE_KEY) || '{}'); }
    catch (_) { return {}; }
  }
  function aplicar() {
    const preferencias = obterPreferencias();
    const root = document.documentElement;
    root.dataset.fonte = preferencias.fonte === 'grande' ? 'grande' : 'normal';
    root.dataset.contraste = preferencias.contraste ? 'alto' : 'normal';
    const toggle = document.getElementById('contrast-toggle');
    if (toggle) toggle.checked = Boolean(preferencias.contraste);
    document.querySelectorAll('[data-font-choice]').forEach((button) => {
      button.setAttribute('aria-pressed', String(button.dataset.fontChoice === root.dataset.fonte));
    });
  }
  window.zeloAcessibilidade = {
    obter: obterPreferencias,
    salvar(parcial) {
      localStorage.setItem(STORAGE_KEY, JSON.stringify({ ...obterPreferencias(), ...parcial }));
      aplicar();
    },
    aplicar
  };
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', aplicar, { once: true });
  else aplicar();
})();
