(() => {
  const API = window.ZELO_API_BASE_URL || 'http://localhost:8080';
  let contatos = [], conversaIdoso = null, ultimaMensagem = 0, conversaInicializada = false, timer, reconhecimento;
  const user = () => { try { return JSON.parse(localStorage.getItem('currentUser') || '{}'); } catch (_) { return {}; } };
  const selected = () => { try { return JSON.parse(localStorage.getItem('selectedIdoso') || 'null'); } catch (_) { return null; } };
  const el = id => document.getElementById(id);
  const escapeHtml = value => String(value ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[c]));
  async function carregarContatos() {
    const u = user(); if (!u.id) return;
    try {
      const familiar = String(u.userType || u.perfil || '').toLowerCase() === 'familiar';
      const r = await fetch(`${API}/api/vinculos/${familiar ? `familiar/${u.id}/idosos` : `idoso/${u.id}/familiares`}`, {credentials:'include', cache:'no-store'});
      contatos = r.ok ? await r.json() : [];
      const select = el('chat-contact-select'); if (!select) return;
      const valorAtual = select.value;
      select.innerHTML = contatos.length ? contatos.map(c => `<option value="${c.id}">${escapeHtml(c.nome || `Perfil ${c.id}`)}</option>`).join('') : '<option value="">Nenhum vínculo aprovado</option>';
      const s = selected();
      const alvo = familiar ? (s?.id || contatos[0]?.id) : contatos[0]?.id;
      if (alvo) { conversaIdoso = String(familiar ? alvo : u.id); select.value = familiar ? String(alvo) : (valorAtual || String(contatos[0].id)); await carregarMensagens(); }
    } catch (e) { console.warn('Não foi possível carregar os vínculos:', e); }
  }
  async function carregarMensagens() {
    if (!conversaIdoso) return;
    const r = await fetch(`${API}/api/chat/mensagens?idosoId=${encodeURIComponent(conversaIdoso)}`, {credentials:'include', cache:'no-store'});
    if (!r.ok) return;
    const lista = await r.json(); const box = el('chat-messages'); if (!box) return;
    box.innerHTML = lista.length ? lista.map(m => `<div class="chat-message ${m.remetenteId === user().id ? 'mine' : ''}"><strong>${escapeHtml(m.remetenteNome)}</strong><span>${escapeHtml(m.texto)}</span><div class="chat-message-actions"><button type="button" class="chat-speak" data-text="${escapeHtml(m.texto)}" aria-label="Ouvir esta mensagem">🔊 Ouvir</button><time>${new Date(m.enviadaEm).toLocaleString('pt-BR',{hour:'2-digit',minute:'2-digit'})}</time></div></div>`).join('') : '<p class="chat-empty">Ainda não há mensagens. Envie um oi!</p>';
    box.querySelectorAll('.chat-speak').forEach(button => button.addEventListener('click', () => window.lerMensagemChat(button.dataset.text)));
    const ultimo = lista[lista.length - 1];
    if (ultimo && ultimo.id !== ultimaMensagem) {
      const eraNova = conversaInicializada && ultimo.remetenteId !== user().id;
      ultimaMensagem = ultimo.id; box.scrollTop = box.scrollHeight;
      if (eraNova && el('chat-auto-audio')?.checked) window.lerMensagemChat(`${ultimo.remetenteNome} disse: ${ultimo.texto}`);
    }
    conversaInicializada = true;
  }
  async function enviar(e) { e.preventDefault(); const input = el('chat-input'); const texto = input?.value.trim(); if (!texto || !conversaIdoso) return;
    const r = await fetch(`${API}/api/chat/mensagens`, {method:'POST', credentials:'include', headers:{'Content-Type':'application/json'}, body:JSON.stringify({idosoId:Number(conversaIdoso), texto})});
    if (r.ok) { input.value = ''; await carregarMensagens(); } else alert(await r.text() || 'Não foi possível enviar a mensagem.');
  }
  window.lerMensagemChat = texto => { if (!('speechSynthesis' in window) || !texto) return; window.speechSynthesis.cancel(); const fala = new SpeechSynthesisUtterance(texto); fala.lang = 'pt-BR'; fala.rate = 0.88; fala.pitch = 1; window.speechSynthesis.speak(fala); };
  function iniciarDitado() {
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SpeechRecognition) { alert('O ditado por voz não está disponível neste navegador.'); return; }
    if (reconhecimento) { reconhecimento.stop(); reconhecimento = null; return; }
    reconhecimento = new SpeechRecognition(); reconhecimento.lang = 'pt-BR'; reconhecimento.interimResults = false; reconhecimento.maxAlternatives = 1;
    reconhecimento.onstart = () => { const b = el('chat-mic'); if (b) b.textContent = '⏹️ Parar'; };
    reconhecimento.onresult = event => { const input = el('chat-input'); if (input) input.value = `${input.value ? `${input.value} ` : ''}${event.results[0][0].transcript}`; };
    reconhecimento.onerror = () => { const b = el('chat-mic'); if (b) b.textContent = '🎙️ Falar'; };
    reconhecimento.onend = () => { const b = el('chat-mic'); if (b) b.textContent = '🎙️ Falar'; reconhecimento = null; };
    reconhecimento.start();
  }
  async function carregarNotificacoes() { const badge = el('notif-badge'); const list = el('notif-list'); if (!badge || !list) return;
    try { const r = await fetch(`${API}/notificacoes`, {credentials:'include', cache:'no-store'}); if (!r.ok) return; const n = await r.json(); badge.textContent = n.length; badge.classList.toggle('hidden', !n.length); list.innerHTML = n.length ? n.map(x => `<li class="notif-item new"><strong>${escapeHtml(x.titulo)}</strong><span>${escapeHtml(x.mensagem)}</span><small>${new Date(x.criadaEm).toLocaleString('pt-BR')}</small></li>`).join('') : '<li class="notif-item">Nenhuma notificação no momento.</li>'; } catch (_) {}
  }
  window.toggleNotificacoes = () => el('notif-drawer')?.classList.toggle('hidden');
  window.limparNotificacoes = async () => { await fetch(`${API}/notificacoes`, {method:'DELETE',credentials:'include'}); carregarNotificacoes(); };
  window.abrirConversa = id => { conversaIdoso = String(id); conversaInicializada = false; carregarMensagens(); el('chat-panel')?.scrollIntoView({behavior:'smooth'}); };
  document.addEventListener('DOMContentLoaded', () => {
    const form = el('chat-form'); form?.addEventListener('submit', enviar);
    el('chat-contact-select')?.addEventListener('change', e => { const u=user(); const familiar=String(u.userType||u.perfil).toLowerCase()==='familiar'; conversaIdoso=String(familiar ? e.target.value : u.id); ultimaMensagem=0; conversaInicializada=false; carregarMensagens(); });
    el('chat-mic')?.addEventListener('click', iniciarDitado);
    const auto = el('chat-auto-audio'); if (auto) { auto.checked = localStorage.getItem('zelo-audio-auto') === 'true'; auto.addEventListener('change', () => localStorage.setItem('zelo-audio-auto', String(auto.checked))); }
    el('chat-read-last')?.addEventListener('click', () => { const messages = el('chat-messages')?.querySelectorAll('.chat-message span'); if (messages?.length) window.lerMensagemChat(messages[messages.length - 1].textContent); });
    carregarContatos(); carregarNotificacoes(); timer=setInterval(() => { carregarContatos(); carregarMensagens(); carregarNotificacoes(); window.dispatchEvent(new Event('zelo-dados-atualizados')); }, 2000);
  });
  window.addEventListener('zelo-vinculo-atualizado', () => { carregarContatos(); carregarNotificacoes(); });
  window.addEventListener('beforeunload', () => clearInterval(timer));
})();
