document.addEventListener("DOMContentLoaded", () => {
  const form = document.getElementById("login-form");
  const status = document.getElementById("login-status");
  if (!form || !status) return;

  form.addEventListener("submit", async (event) => {
    event.preventDefault();
    if (!form.reportValidity()) return;
    const button = form.querySelector("button[type=submit]");
    button.disabled = true;
    status.textContent = "Verificando seus dados...";

    try {
      const response = await fetch(`${window.ZELO_API_BASE_URL}/login`, {
        method: "POST",
        credentials: "include",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          email: form.elements.email.value.trim().toLowerCase(),
          senha: form.elements.senha.value,
          lembrarMe: form.elements.lembrarMe.checked
        })
      });
      if (!response.ok) {
        const raw = await response.text();
        let message = raw;
        try { message = JSON.parse(raw).message || raw; } catch (_) {}
        throw new Error(message || "Não foi possível entrar. Confira seus dados.");
      }

      const usuario = await response.json();
      const perfil = String(usuario.perfil || usuario.tipo || "").trim().toLowerCase();
      if (perfil !== "idoso" && perfil !== "familiar") {
        throw new Error("Não foi possível identificar o perfil desta conta. Entre em contato com o suporte.");
      }
      usuario.userType = perfil;
      localStorage.setItem("currentUser", JSON.stringify(usuario));

      if (perfil === "idoso") {
        localStorage.setItem("selectedIdoso", JSON.stringify({ id: usuario.id, nome: usuario.nome }));
        window.location.href = "inicioidoso/inicioidoso.html";
      } else {
        localStorage.removeItem("selectedIdoso");
        window.location.href = "iniciofamiliar/iniciofamiliar.html";
      }
    } catch (error) {
      status.textContent = error.message || "Não foi possível conectar ao servidor. Tente novamente.";
    } finally {
      button.disabled = false;
    }
  });
});
