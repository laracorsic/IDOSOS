(() => {
    'use strict';
    const API_BASE_URL = window.ZELO_API_BASE_URL || 'http://localhost:8080';

    function destinoDoPerfil(usuario) {
        const familiar = String(usuario.perfil || usuario.tipo || usuario.userType || '').toLowerCase() === 'familiar';
        const arquivo = familiar ? 'iniciofamiliar/iniciofamiliar.html' : 'inicioidoso/inicioidoso.html';
        const vindoDePastaPublica = /\/(paginainicial\/paginainicial|entrarcomo\/entrarcomo)\.html$/.test(window.location.pathname);
        const prefixo = vindoDePastaPublica ? '../' : './';
        return new URL(prefixo + arquivo, window.location.href).href;
    }

    window.sair = async function(event) {
        if (event) event.preventDefault();
        try {
            await fetch(`${API_BASE_URL}/login/logout`, { method: 'POST', credentials: 'include' });
        } catch (erro) {
            console.warn('Não foi possível avisar o servidor sobre a saída:', erro);
        }
        localStorage.removeItem('currentUser');
        localStorage.removeItem('selectedIdoso');
        const daTelaInicial = /\/paginainicial\/paginainicial\.html$/.test(window.location.pathname);
        const destino = daTelaInicial ? 'paginainicial.html' : '../paginainicial/paginainicial.html';
        window.location.href = new URL(destino, window.location.href).href;
    };

    async function restaurarSessaoSeAplicavel() {
        const pathname = window.location.pathname;
        const telaLogin = /\/login\.html$/.test(pathname);
        const telaInicial = /\/paginainicial\/paginainicial\.html$/.test(pathname);
        const telaSelecaoPerfil = /\/entrarcomo\/entrarcomo\.html$/.test(pathname);
        if (!telaLogin && !telaInicial && !telaSelecaoPerfil) return;
        try {
            const resposta = await fetch(`${API_BASE_URL}/login`, { credentials: 'include', cache: 'no-store' });
            if (!resposta.ok) return;
            const usuario = await resposta.json();
            usuario.userType = String(usuario.perfil || usuario.tipo || '').toLowerCase();
            localStorage.setItem('currentUser', JSON.stringify(usuario));
            if (usuario.userType === 'idoso') {
                localStorage.setItem('selectedIdoso', JSON.stringify({ id: usuario.id, nome: usuario.nome }));
            }
            window.location.replace(destinoDoPerfil(usuario));
        } catch (erro) {
            // Backend fora do ar: não bloqueia o acesso à página de entrada.
            console.info('Sessão não pôde ser validada agora.');
        }
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', restaurarSessaoSeAplicavel, { once: true });
    } else {
        restaurarSessaoSeAplicavel();
    }
})();
