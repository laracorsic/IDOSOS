(() => {
  function lerInicio() {
    if (!('speechSynthesis' in window)) { alert('A leitura em voz alta não está disponível neste navegador.'); return; }
    const botao = document.getElementById('btn-ouvir-inicio');
    const texto = botao?.dataset.text || document.querySelector('.inicio-intro p')?.textContent || 'Escolha uma opção no menu principal.';
    window.speechSynthesis.cancel();
    const fala = new SpeechSynthesisUtterance(texto);
    fala.lang = 'pt-BR'; fala.rate = 0.86; fala.pitch = 1;
    window.speechSynthesis.speak(fala);
    if (botao) { botao.textContent = '⏹️ Parar leitura'; botao.dataset.lendo = 'true'; fala.onend = () => { botao.textContent = '🔊 Ouvir instruções'; botao.dataset.lendo = 'false'; }; }
  }
  window.lerInicio = () => { const botao = document.getElementById('btn-ouvir-inicio'); if (botao?.dataset.lendo === 'true') { window.speechSynthesis.cancel(); botao.textContent = '🔊 Ouvir instruções'; botao.dataset.lendo = 'false'; } else lerInicio(); };
})();
