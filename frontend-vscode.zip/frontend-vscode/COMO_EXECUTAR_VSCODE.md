# Executar o frontend no VS Code

O backend Spring Boot deve estar executando separadamente no IntelliJ em:

```text
http://localhost:8080
```

No VS Code, abra a pasta `frontend-vscode` e instale a extensão **Live Server**. Depois, clique com o botão direito em `paginainicial/paginainicial.html` e selecione **Open with Live Server**.

Não abra o arquivo diretamente com `file://`. O servidor local evita bloqueios do navegador e permite que o assistente faça chamadas para o backend.

O frontend lê a URL da API em `assets/js/api-config.js`; o valor padrão é:

```javascript
window.ZELO_API_BASE_URL = 'http://localhost:8080';
```

O assistente usa os endpoints:

```text
GET  http://localhost:8080/assistente/status
POST http://localhost:8080/assistente/conversar
```

## Ordem de inicialização

Primeiro, inicie o backend no IntelliJ com o perfil `local` ativo. A chave `ASSISTENTE_IA_CHAVE` é opcional: sem ela, o backend funciona em modo acolhedor local; com uma chave válida configurada apenas no ambiente do IntelliJ, oferece respostas generativas. Depois, abra a página inicial no Live Server, cadastre-se ou entre e clique em **Falar com Zelo**.

Se o status indicar modo acolhedor, o backend está funcionando, mas a chave Groq não foi configurada. Se o navegador mostrar erro de conexão, confirme se o Spring Boot está em `localhost:8080` e se a porta não está sendo usada por outro programa.

O painel do idoso inclui **Compras → Lista de Casa**, uma página estática separada. Use **Voltar ao Zelo** para retornar. A lista e os áudios ficam no navegador e não são sincronizados com o backend. As respostas da IA exibem Markdown formatado, incluindo títulos, ênfase, listas, links, citações, tabelas e blocos de código.
