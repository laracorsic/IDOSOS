const API_BASE_URL = window.ZELO_API_BASE_URL || 'http://localhost:8080';


document.addEventListener("DOMContentLoaded", () => {


    // ==========================================
    // 1. BOTÃO VOLTAR
    // ==========================================

    const btnVoltar = document.getElementById("btnVoltar");

    if (btnVoltar) {

        btnVoltar.addEventListener("click", () => {

            window.history.back();

        });

    }


    // ==========================================
    // 2. JANELA "PRECISA DE AJUDA?"
    // ==========================================

    const btnAjuda = document.getElementById("btnAjuda");

    const modalAjuda = document.getElementById("modalAjuda");

    const fecharAjuda = document.getElementById("fecharAjuda");


    // Abrir a ajuda

    if (btnAjuda && modalAjuda) {

        btnAjuda.addEventListener("click", () => {

            modalAjuda.classList.add("aberto");

        });

    }


    // Fechar a ajuda pelo botão ENTENDI

    if (fecharAjuda && modalAjuda) {

        fecharAjuda.addEventListener("click", () => {

            modalAjuda.classList.remove("aberto");

        });

    }


    // Fechar também quando clicar fora da caixa

    if (modalAjuda) {

        modalAjuda.addEventListener("click", (event) => {

            if (event.target === modalAjuda) {

                modalAjuda.classList.remove("aberto");

            }

        });

    }


    // ==========================================
    // 3. MÁSCARA DO TELEFONE
    // ==========================================

    const inputTelefone =
        document.getElementById("telefone");


    if (inputTelefone) {

        inputTelefone.setAttribute(
            "maxlength",
            "15"
        );


        inputTelefone.addEventListener(
            "input",
            (event) => {

                let valor = event.target.value;


                // Remove tudo que não for número

                valor = valor.replace(/\D/g, "");


                // Limita aos 11 números do telefone

                valor = valor.substring(0, 11);


                // Coloca o (

                if (valor.length > 0) {

                    valor = "(" + valor;

                }


                // Coloca o )

                if (valor.length > 3) {

                    valor =
                        valor.slice(0, 3) +
                        ") " +
                        valor.slice(3);

                }


                // Coloca o -

                if (valor.length > 10) {

                    valor =
                        valor.slice(0, 10) +
                        "-" +
                        valor.slice(10);

                }


                event.target.value = valor;

            }
        );

    }


    // 4. Cadastro da conta no backend e abertura de sessão
    const formFamiliar = document.getElementById("formCadastroFamiliar");
    if (formFamiliar) {
        formFamiliar.addEventListener("submit", async (event) => {
            event.preventDefault();
            if (!formFamiliar.reportValidity()) return;
            const submitButton = formFamiliar.querySelector('[type="submit"]');
            const nome = document.getElementById("nome").value.trim();
            const telefone = document.getElementById("telefone").value.trim();
            const email = document.getElementById("email").value.trim().toLowerCase();
            const senha = document.getElementById("senha").value;
            const lembrarMe = formFamiliar.elements.lembrarMe.checked;
            const mensagem = document.getElementById("cadastro-status");
            submitButton.disabled = true;
            if (mensagem) mensagem.textContent = "Criando sua conta...";
            try {
                const cadastro = await fetch(`${API_BASE_URL}/login/register`, {
                    method: "POST", credentials: "include",
                    headers: { "Content-Type": "application/json" },
                    body: JSON.stringify({ nome, email, senha, telefone, perfil: "FAMILIAR" })
                });
                if (!cadastro.ok) {
                    const raw = await cadastro.text();
                    let detalhe = raw;
                    try { detalhe = JSON.parse(raw).message || raw; } catch (_) {}
                    throw new Error(cadastro.status === 409 ? "Este e-mail já está cadastrado. Use a opção Entrar." : (detalhe || `Erro ${cadastro.status} ao cadastrar.`));
                }
                const login = await fetch(`${API_BASE_URL}/login`, {
                    method: "POST", credentials: "include",
                    headers: { "Content-Type": "application/json" },
                    body: JSON.stringify({ email, senha, lembrarMe })
                });
                if (!login.ok) throw new Error("A conta foi criada, mas não foi possível iniciar a sessão. Entre usando seu e-mail e senha.");
                const usuario = await login.json();
                usuario.userType = "familiar";
                localStorage.setItem("currentUser", JSON.stringify(usuario));
                if (mensagem) mensagem.textContent = "Conta criada. Vamos abrir o vínculo com o idoso.";
                window.location.href = "../vinculo/vinculo.html";
            } catch (error) {
                console.error("Falha no cadastro familiar:", error);
                if (mensagem) mensagem.textContent = error.message || "Não foi possível cadastrar. Confirme se o backend está ativo.";
                else alert(error.message || "Não foi possível cadastrar. Confirme se o backend está ativo.");
            } finally {
                submitButton.disabled = false;
            }
        });
    }
});
