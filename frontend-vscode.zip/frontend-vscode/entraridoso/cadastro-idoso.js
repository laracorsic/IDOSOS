document.addEventListener("DOMContentLoaded", () => {
    const form = document.getElementById("formCadastroIdoso");
    if (!form) return;

    form.addEventListener("submit", async (event) => {
        event.preventDefault();
        if (!form.reportValidity()) return;

        const button = form.querySelector('[type="submit"]');
        const status = document.getElementById("cadastro-status");
        const nome = form.elements.nome.value.trim();
        const telefone = form.elements.telefone.value.trim();
        const email = form.elements.email.value.trim().toLowerCase();
        const senha = form.elements.senha.value;
        const idade = Number(form.elements.idade.value);
        const lembrarMe = form.elements.lembrarMe.checked;
        button.disabled = true;
        status.textContent = "Criando sua conta...";

        try {
            const cadastro = await fetch(`${window.ZELO_API_BASE_URL}/login/register`, {
                method: "POST",
                credentials: "include",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ nome, email, senha, telefone, idade, perfil: "IDOSO" })
            });
            if (!cadastro.ok) {
                const raw = await cadastro.text();
                let message = raw;
                try { message = JSON.parse(raw).message || raw; } catch (_) {}
                throw new Error(cadastro.status === 409 ? "Este e-mail já está cadastrado. Use a opção Entrar." : (message || `Erro ${cadastro.status} ao cadastrar.`));
            }

            const login = await fetch(`${window.ZELO_API_BASE_URL}/login`, {
                method: "POST",
                credentials: "include",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ email, senha, lembrarMe })
            });
            if (!login.ok) throw new Error("A conta foi criada, mas não foi possível iniciar a sessão. Entre usando seu e-mail e senha.");

            const usuario = await login.json();
            usuario.userType = "idoso";
            localStorage.setItem("currentUser", JSON.stringify(usuario));
            localStorage.setItem("selectedIdoso", JSON.stringify({ id: usuario.id, nome: usuario.nome, telefone, idade }));
            status.textContent = "Conta criada. Bem-vindo ao Zelo!";
            window.location.href = "../inicioidoso/inicioidoso.html";
        } catch (error) {
            console.error("Falha no cadastro do idoso:", error);
            status.textContent = error.message || "Não foi possível cadastrar. Confirme se o backend está ativo.";
        } finally {
            button.disabled = false;
        }
    });
});
