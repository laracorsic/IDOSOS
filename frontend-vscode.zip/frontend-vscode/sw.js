/* Service Worker do Zelo: precisa ficar na raiz do frontend para controlar todas as páginas. */
self.addEventListener('push', (event) => {
    let dados = {};
    try {
        dados = event.data ? event.data.json() : {};
    } catch (_) {
        dados = { body: event.data ? event.data.text() : '' };
    }

    const titulo = dados.title || 'Zelo';
    const opcoes = {
        body: dados.body || 'Você tem uma nova notificação.',
        icon: new URL('inicioidoso/zelo.png', self.registration.scope).href,
        badge: new URL('inicioidoso/zelo.png', self.registration.scope).href,
        tag: dados.tag || 'zelo-notificacao',
        renotify: true,
        requireInteraction: true,
        data: { url: dados.url || '/' }
    };

    event.waitUntil(Promise.all([
        self.registration.showNotification(titulo, opcoes),
        self.clients.matchAll({ type: 'window', includeUncontrolled: true }).then((janelas) =>
            Promise.all(janelas.map((janela) => janela.postMessage({
                tipo: 'WEB_PUSH_RECEBIDO',
                titulo,
                mensagem: dados.body || 'Você tem uma nova notificação.',
                url: dados.url || '/',
                timestamp: new Date().toISOString()
            })))
        )
    ]));
});

self.addEventListener('notificationclick', (event) => {
    event.notification.close();
    const destino = event.notification.data && event.notification.data.url
        ? event.notification.data.url
        : '/';
    event.waitUntil(clients.matchAll({ type: 'window', includeUncontrolled: true }).then((janelas) => {
        const janela = janelas.find((item) => 'focus' in item);
        if (janela) {
            janela.navigate(destino);
            return janela.focus();
        }
        return clients.openWindow(destino);
    }));
});
