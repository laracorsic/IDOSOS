package com.auth.simpleauth.entity;

import com.auth.simpleauth.enums.Perfil;
import jakarta.persistence.DiscriminatorValue;
import jakarta.persistence.Entity;
import jakarta.persistence.OneToMany;

import java.util.ArrayList;
import java.util.List;

@Entity
@DiscriminatorValue("FAMILIAR")
public class Familiar extends Usuario {

    // Lista de idosos vinculados a este familiar (1 Familiar -> Muitos Idosos)
    @OneToMany(mappedBy = "familiar")
    private List<Idoso> idosos = new ArrayList<>();

    @OneToMany(mappedBy = "familiar")
    private List<Remedio> remediosCadastrados = new ArrayList<>();

    public Familiar() {
        setPerfil(Perfil.FAMILIAR);
    }

    public Familiar(String nome, String email, String senha, String telefone) {
        super(nome, email, senha, telefone, Perfil.FAMILIAR);
    }

    // Getters e Setters
    public List<Idoso> getIdosos() { return idosos; }
    public void setIdosos(List<Idoso> idosos) { this.idosos = idosos; }

    public List<Remedio> getRemediosCadastrados() { return remediosCadastrados; }
    public void setRemediosCadastrados(List<Remedio> remediosCadastrados) { this.remediosCadastrados = remediosCadastrados; }
}