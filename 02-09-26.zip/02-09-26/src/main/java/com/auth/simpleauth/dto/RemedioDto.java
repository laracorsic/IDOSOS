package com.auth.simpleauth.dto;

import java.time.LocalDateTime;

public class RemedioDto {
    private String nome;
    private LocalDateTime primeiroHorario;
    private Integer intervaloHoras;
    private Long idIdoso;
    private Long idFamiliar;

    public RemedioDto() {}

    public RemedioDto(String nome, LocalDateTime primeiroHorario, Integer intervaloHoras, Long idIdoso, Long idFamiliar) {
        this.nome = nome;
        this.primeiroHorario = primeiroHorario;
        this.intervaloHoras = intervaloHoras;
        this.idIdoso = idIdoso;
        this.idFamiliar = idFamiliar;
    }

    public String getNome() { return nome; }
    public void setNome(String nome) { this.nome = nome; }

    public LocalDateTime getPrimeiroHorario() { return primeiroHorario; }
    public void setPrimeiroHorario(LocalDateTime primeiroHorario) { this.primeiroHorario = primeiroHorario; }

    public Integer getIntervaloHoras() { return intervaloHoras; }
    public void setIntervaloHoras(Integer intervaloHoras) { this.intervaloHoras = intervaloHoras; }

    public Long getIdIdoso() { return idIdoso; }
    public void setIdIdoso(Long idIdoso) { this.idIdoso = idIdoso; }

    public Long getIdFamiliar() { return idFamiliar; }
    public void setIdFamiliar(Long idFamiliar) { this.idFamiliar = idFamiliar; }
}