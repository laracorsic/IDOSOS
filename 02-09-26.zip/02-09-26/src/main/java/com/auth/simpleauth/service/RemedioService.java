package com.auth.simpleauth.service;

import com.auth.simpleauth.dto.RemedioDto;
import com.auth.simpleauth.entity.Familiar;
import com.auth.simpleauth.entity.Idoso;
import com.auth.simpleauth.entity.Remedio;
import com.auth.simpleauth.repository.FamiliarRepository;
import com.auth.simpleauth.repository.IdosoRepository;
import com.auth.simpleauth.repository.RemedioRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.format.DateTimeFormatter;
import java.util.List;

@Service
public class RemedioService {

    private final RemedioRepository remedioRepository;
    private final IdosoRepository idosoRepository;
    private final FamiliarRepository familiarRepository;
    private final TelegramService telegramService;

    public RemedioService(RemedioRepository remedioRepository,
                          IdosoRepository idosoRepository,
                          FamiliarRepository familiarRepository,
                          TelegramService telegramService) {
        this.remedioRepository = remedioRepository;
        this.idosoRepository = idosoRepository;
        this.familiarRepository = familiarRepository;
        this.telegramService = telegramService;
    }

    @Transactional
    public Remedio cadastrar(RemedioDto dto) {
        Idoso idoso = idosoRepository.findById(dto.getIdIdoso())
                .orElseThrow(() -> new RuntimeException("Idoso não encontrado com ID: " + dto.getIdIdoso()));

        Familiar familiar = familiarRepository.findById(dto.getIdFamiliar())
                .orElseThrow(() -> new RuntimeException("Familiar não encontrado com ID: " + dto.getIdFamiliar()));

        Remedio novoRemedio = new Remedio(
                dto.getNome(),
                dto.getPrimeiroHorario(),
                dto.getIntervaloHoras(),
                idoso,
                familiar
        );

        Remedio remedioSalvo = remedioRepository.save(novoRemedio);

        // Notifica o Familiar no Telegram informando novo cadastro
        String msg = String.format(" Novo remédio cadastrado!\n\nRemédio: %s\nIdoso: %s\nPrimeira Tomada: %s\nIntervalo: de %dh em %dh",
                remedioSalvo.getNome(),
                idoso.getNome(),
                remedioSalvo.getPrimeiroHorario().format(DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm")),
                remedioSalvo.getIntervaloHoras());

        telegramService.enviarNotificacao(msg);

        return remedioSalvo;
    }

    @Transactional
    public Remedio confirmarTomada(Long id) {
        Remedio remedio = remedioRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Remédio não encontrado com ID: " + id));

        remedio.agendarProximaTomada();
        Remedio atualizado = remedioRepository.save(remedio);

        // Notifica o Familiar pelo Telegram sobre a confirmação realizada pelo idoso
        String msg = String.format(" Remédio Tomado!\n\nO idoso %s confirmou a tomada de: %s.\nPróxima tomada agendada para: %s",
                remedio.getIdoso().getNome(),
                remedio.getNome(),
                remedio.getProximoHorario().format(DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm")));

        telegramService.enviarNotificacao(msg);

        return atualizado;
    }

    public List<Remedio> listarPorIdoso(Long idosoId) {
        return remedioRepository.findByIdosoId(idosoId);
    }

    public List<Remedio> listarTodos() {
        return remedioRepository.findAll();
    }
}