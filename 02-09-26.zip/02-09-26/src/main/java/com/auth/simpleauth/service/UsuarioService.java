package com.auth.simpleauth.service;

import com.auth.simpleauth.entity.Usuario;
import com.auth.simpleauth.repository.UsuarioRepository;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class UsuarioService {

    private final UsuarioRepository loginRepository;

    public UsuarioService(UsuarioRepository loginRepository) {
        this.loginRepository = loginRepository;
    }

    public Optional<Usuario> findByEmailAndSenha(String email, String senha) {
        return this.loginRepository.findByEmailAndSenha(email, senha);
    }

    public Optional<Usuario> findByEmail(String email) {
        return this.loginRepository.findByEmail(email);
    }

    public void criaNovoUsuario(Usuario novoUsuario) {
        this.loginRepository.save(novoUsuario);
    }

    public void deletarUsuario(Usuario usuario) {
        this.loginRepository.delete(usuario);
    }

    // Método que estava faltando:
    public void deletarPorId(Long id) {
        this.loginRepository.deleteById(id);
    }
}