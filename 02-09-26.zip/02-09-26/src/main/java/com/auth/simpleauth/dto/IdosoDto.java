package com.auth.simpleauth.dto;

public class IdosoDto {
    private String nome;
    private String email;
    private String senha;
    private String telefone;
    private Long idFamiliar;

    public IdosoDto() {}

    public IdosoDto(String nome, String email, String senha, String telefone, Long idFamiliar) {
        this.nome = nome;
        this.email = email;
        this.senha = senha;
        this.telefone = telefone;
        this.idFamiliar = idFamiliar;
    }

    public String getNome() { return nome; }
    public void setNome(String nome) { this.nome = nome; }

    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }

    public String getSenha() { return senha; }
    public void setSenha(String senha) { this.senha = senha; }

    public String getTelefone() { return telefone; }
    public void setTelefone(String telefone) { this.telefone = telefone; }

    public Long getIdFamiliar() { return idFamiliar; }
    public void setIdFamiliar(Long idFamiliar) { this.idFamiliar = idFamiliar; }
}