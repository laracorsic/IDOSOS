package com.auth.simpleauth.dto;

import com.auth.simpleauth.entity.Usuario;
import com.auth.simpleauth.enums.Perfil;

public class UsuarioCadastroDto {
    private String nome;
    private String email;
    private String senha;
    private String telefone;
    private Perfil perfil;

    public UsuarioCadastroDto() {}

    public UsuarioCadastroDto(String nome, String email, String senha, String telefone, Perfil perfil) {
        this.nome = nome;
        this.email = email;
        this.senha = senha;
        this.telefone = telefone;
        this.perfil = perfil;
    }

    // Método utilitário para converter o DTO na Entidade JPA
    public Usuario toEntity() {
        return new Usuario(this.nome, this.email, this.senha, this.telefone, this.perfil);
    }

    public String getNome() { return nome; }
    public void setNome(String nome) { this.nome = nome; }

    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }

    public String getSenha() { return senha; }
    public void setSenha(String senha) { this.senha = senha; }

    public String getTelefone() { return telefone; }
    public void setTelefone(String telefone) { this.telefone = telefone; }

    public Perfil getPerfil() { return perfil; }
    public void setPerfil(Perfil perfil) { this.perfil = perfil; }
}