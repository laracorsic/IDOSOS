package com.auth.simpleauth.dto;

import com.auth.simpleauth.entity.Remedio;
import java.time.LocalDateTime;
import java.time.ZoneId;

public class RemedioResponseDto {
    private Long id;
    private String nome;
    private LocalDateTime primeiroHorario;
    private Integer intervaloHoras;
    private LocalDateTime proximoHorario;
    private Boolean tomado;
    private Long idIdoso;
    private String nomeIdoso;
    private Long idFamiliar;
    private long millisAteProximoHorario;

    public RemedioResponseDto(Remedio remedio) {
        this.id = remedio.getId();
        this.nome = remedio.getNome();
        this.primeiroHorario = remedio.getPrimeiroHorario();
        this.intervaloHoras = remedio.getIntervaloHoras();
        this.proximoHorario = remedio.getProximoHorario();
        this.tomado = remedio.getTomado();

        if (remedio.getIdoso() != null) {
            this.idIdoso = remedio.getIdoso().getId();
            this.nomeIdoso = remedio.getIdoso().getNome();
        }

        if (remedio.getFamiliar() != null) {
            this.idFamiliar = remedio.getFamiliar().getId();
        }

        // Calcula os milissegundos restantes para alimentar o CountDownTimer/WorkManager do Android
        long targetMillis = remedio.getProximoHorario().atZone(ZoneId.systemDefault()).toInstant().toEpochMilli();
        long nowMillis = System.currentTimeMillis();
        this.millisAteProximoHorario = Math.max(0, targetMillis - nowMillis);
    }

    public Long getId() { return id; }
    public String getNome() { return nome; }
    public LocalDateTime getPrimeiroHorario() { return primeiroHorario; }
    public Integer getIntervaloHoras() { return intervaloHoras; }
    public LocalDateTime getProximoHorario() { return proximoHorario; }
    public Boolean getTomado() { return tomado; }
    public Long getIdIdoso() { return idIdoso; }
    public String getNomeIdoso() { return nomeIdoso; }
    public Long getIdFamiliar() { return idFamiliar; }
    public long getMillisAteProximoHorario() { return millisAteProximoHorario; }
}