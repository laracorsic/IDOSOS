package com.auth.simpleauth.entity;

import com.auth.simpleauth.enums.Perfil;
import jakarta.persistence.*;

import java.util.ArrayList;
import java.util.List;

@Entity
@DiscriminatorValue("IDOSO")
public class Idoso extends Usuario {

    // Vinculo com o Familiar responsavel (Muitos Idosos -> 1 Familiar)
    @ManyToOne
    @JoinColumn(name = "id_familiar", nullable = true)
    private Familiar familiar;

    // Lista de remedios atribuidos a este idoso
    @OneToMany(mappedBy = "idoso")
    private List<Remedio> remedios = new ArrayList<>();

    public Idoso() {
        setPerfil(Perfil.IDOSO);
    }

    public Idoso(String nome, String email, String senha, String telefone, Familiar familiar) {
        super(nome, email, senha, telefone, Perfil.IDOSO);
        this.familiar = familiar;
    }

    // Getters e Setters
    public Familiar getFamiliar() { return familiar; }
    public void setFamiliar(Familiar familiar) { this.familiar = familiar; }

    public List<Remedio> getRemedios() { return remedios; }
    public void setRemedios(List<Remedio> remedios) { this.remedios = remedios; }
}