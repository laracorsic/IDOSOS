package com.auth.simpleauth.entity;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "remedios")
public class Remedio {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String nome;

    @Column(nullable = false)
    private LocalDateTime primeiroHorario;

    @Column(nullable = false)
    private Integer intervaloHoras;

    @Column(nullable = false)
    private LocalDateTime proximoHorario;

    @Column(nullable = false)
    private Boolean tomado;

    @ManyToOne
    @JoinColumn(name = "id_idoso", nullable = false)
    private Idoso idoso;

    @ManyToOne
    @JoinColumn(name = "id_familiar", nullable = false)
    private Familiar familiar;

    public Remedio() {}

    public Remedio(String nome, LocalDateTime primeiroHorario, Integer intervaloHoras, Idoso idoso, Familiar familiar) {
        this.nome = nome;
        this.primeiroHorario = primeiroHorario;
        this.intervaloHoras = intervaloHoras;
        this.proximoHorario = primeiroHorario;
        this.tomado = false;
        this.idoso = idoso;
        this.familiar = familiar;
    }

    // Regra de Negócio: recalcular próximo horário após tomada
    public void agendarProximaTomada() {
        this.proximoHorario = this.proximoHorario.plusHours(this.intervaloHoras);
        this.tomado = false;
    }

    // Getters e Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getNome() { return nome; }
    public void setNome(String nome) { this.nome = nome; }

    public LocalDateTime getPrimeiroHorario() { return primeiroHorario; }
    public void setPrimeiroHorario(LocalDateTime primeiroHorario) { this.primeiroHorario = primeiroHorario; }

    public Integer getIntervaloHoras() { return intervaloHoras; }
    public void setIntervaloHoras(Integer intervaloHoras) { this.intervaloHoras = intervaloHoras; }

    public LocalDateTime getProximoHorario() { return proximoHorario; }
    public void setProximoHorario(LocalDateTime proximoHorario) { this.proximoHorario = proximoHorario; }

    public Boolean getTomado() { return tomado; }
    public void setTomado(Boolean tomado) { this.tomado = tomado; }

    public Idoso getIdoso() { return idoso; }
    public void setIdoso(Idoso idoso) { this.idoso = idoso; }

    public Familiar getFamiliar() { return familiar; }
    public void setFamiliar(Familiar familiar) { this.familiar = familiar; }
}