package com.auth.simpleauth.enums;

public enum Perfil {
    FAMILIAR,
    IDOSO
}