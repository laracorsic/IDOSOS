package com.auth.simpleauth.repository;

import com.auth.simpleauth.entity.Remedio;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface RemedioRepository extends JpaRepository<Remedio, Long> {
    List<Remedio> findByIdosoId(Long idosoId);
}