package com.auth.simpleauth.controller;

import com.auth.simpleauth.dto.RemedioDto;
import com.auth.simpleauth.dto.RemedioResponseDto;
import com.auth.simpleauth.entity.Remedio;
import com.auth.simpleauth.service.RemedioService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/remedios")
@CrossOrigin(origins = "*")
public class RemedioController {

    private final RemedioService service;

    public RemedioController(RemedioService service) {
        this.service = service;
    }

    @PostMapping
    public ResponseEntity<RemedioResponseDto> cadastrar(@RequestBody RemedioDto dto) {
        Remedio novoRemedio = service.cadastrar(dto);
        return ResponseEntity.status(HttpStatus.CREATED).body(new RemedioResponseDto(novoRemedio));
    }

    @GetMapping
    public ResponseEntity<List<RemedioResponseDto>> listarTodos() {
        List<RemedioResponseDto> lista = service.listarTodos().stream()
                .map(RemedioResponseDto::new)
                .collect(Collectors.toList());
        return ResponseEntity.ok(lista);
    }

    @GetMapping("/idoso/{idosoId}")
    public ResponseEntity<List<RemedioResponseDto>> listarPorIdoso(@PathVariable Long idosoId) {
        List<RemedioResponseDto> lista = service.listarPorIdoso(idosoId).stream()
                .map(RemedioResponseDto::new)
                .collect(Collectors.toList());
        return ResponseEntity.ok(lista);
    }

    @PutMapping("/{id}/confirmar")
    public ResponseEntity<RemedioResponseDto> confirmarTomada(@PathVariable Long id) {
        Remedio remedioAtualizado = service.confirmarTomada(id);
        return ResponseEntity.ok(new RemedioResponseDto(remedioAtualizado));
    }
}