package com.auth.simpleauth.service;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class TelegramService {

    @Value("${telegram.bot.token}")
    private String botToken;

    @Value("${telegram.chat.id:}")
    private String defaultChatId;

    private final RestTemplate restTemplate;

    public TelegramService() {
        this.restTemplate = new RestTemplate();
    }

    public void enviarNotificacao(String chatIdDestino, String mensagem) {
        String targetChatId = (chatIdDestino != null && !chatIdDestino.isBlank()) ? chatIdDestino : defaultChatId;

        if (targetChatId == null || targetChatId.isBlank() || targetChatId.startsWith("SEU_")) {
            System.err.println("⚠️ Notificação cancelada: Usuário não possui Chat ID do Telegram cadastrado.");
            return;
        }

        String url = "https://api.telegram.org/bot" + botToken + "/sendMessage";

        Map<String, Object> body = new HashMap<>();
        body.put("chat_id", targetChatId);
        body.put("text", mensagem);
        body.put("parse_mode", "HTML");

        try {
            restTemplate.postForObject(url, body, String.class);
        } catch (Exception e) {
            System.err.println("❌ Erro ao enviar mensagem via Telegram: " + e.getMessage());
        }
    }

    public void enviarNotificacaoComBotao(String chatIdDestino, String mensagem, Long idDose) {
        String targetChatId = (chatIdDestino != null && !chatIdDestino.isBlank()) ? chatIdDestino : defaultChatId;

        if (targetChatId == null || targetChatId.isBlank() || targetChatId.startsWith("SEU_")) {
            System.err.println("⚠️ Notificação cancelada: Usuário não possui Chat ID do Telegram cadastrado.");
            return;
        }

        String url = "https://api.telegram.org/bot" + botToken + "/sendMessage";

        Map<String, Object> body = new HashMap<>();
        body.put("chat_id", targetChatId);
        body.put("text", mensagem);
        body.put("parse_mode", "HTML");

        // Adiciona o botão interativo [ ✅ Tomei o Remédio ]
        Map<String, Object> botao = new HashMap<>();
        botao.put("text", "✅ Tomei o Remédio");
        botao.put("callback_data", "TOMAR_DOSE:" + idDose);

        List<List<Map<String, Object>>> keyboard = List.of(List.of(botao));
        body.put("reply_markup", Map.of("inline_keyboard", keyboard));

        try {
            restTemplate.postForObject(url, body, String.class);
        } catch (Exception e) {
            System.err.println("❌ Erro ao enviar mensagem com botão via Telegram: " + e.getMessage());
        }
    }

    public void enviarNotificacao(String mensagem) {
        enviarNotificacao(null, mensagem);
    }
}