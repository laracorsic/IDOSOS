// Base de dados simulada dos idosos cadastrados
const idososCadastrados = [
    {
        id: "12345",
        nome: "Miquéias de Sousa",
        remedios: "2/3",
        atrasos: "1",
        compromissos: "1",
        compromissoDesc: "hoje, às 15h",
        notificacoes: [
            { texto: "Miquéias tomou o remédio Paracetamol", hora: "08:30", lida: false },
            { texto: "Alerta: Remédio de Pressão em atraso!", hora: "10:00", lida: false },
            { texto: "Miquéias adicionou uma consulta médica às 15h", hora: "11:15", lida: false }
        ]
    },
    {
        id: "002",
        nome: "Maria das Graças",
        remedios: "3/3",
        atrasos: "0",
        compromissos: "2",
        compromissoDesc: "Amanhã, às 09h",
        notificacoes: [
            { texto: "Maria marcou compromisso: Fisioterapia", hora: "09:00", lida: false },
            { texto: "Maria tomou todos os remédios do dia", hora: "12:00", lida: false }
        ]
    },
    {
        id: "003",
        nome: "João Batista",
        remedios: "1/4",
        atrasos: "2",
        compromissos: "0",
        compromissoDesc: "Nenhum hoje",
        notificacoes: [
            { texto: "Alerta: João esqueceu a medicação das 08h", hora: "08:45", lida: false }
        ]
    }
];

let idosoSelecionado = null;

// Inicializar na página dinamicamente
document.addEventListener("DOMContentLoaded", () => {
    // 1. Carrega o usuário logado via localStorage
    const currentUser = JSON.parse(localStorage.getItem("currentUser")) || {};

    // Atualiza nome do familiar logado
    const userNameEl = document.getElementById("user-name");
    if (userNameEl) {
        userNameEl.innerText = currentUser.nome || "Familiar";
    }

    // 2. Busca o idoso vinculado pelo ID ou Nome salvo no login
    const idIdoso = currentUser.idIdoso;
    
    idosoSelecionado = idososCadastrados.find(
        i => i.id === idIdoso || (i.nome && currentUser.nomeIdoso && i.nome.toLowerCase() === currentUser.nomeIdoso.toLowerCase())
    );

    // Se o ID digitado no login não constar na lista fictícia, gera um perfil dinâmico com o ID digitado
    if (!idosoSelecionado) {
        idosoSelecionado = {
            id: idIdoso || "38299",
            nome: currentUser.nomeIdoso || `Idoso (ID: #${idIdoso || '38299'})`,
            remedios: "0/0",
            atrasos: "0",
            compromissos: "0",
            compromissoDesc: "Nenhum hoje",
            notificacoes: []
        };
    }

    // 3. Renderiza os dados no painel
    carregarDadosIdoso(idosoSelecionado);
});

// Pesquisar idoso por nome ou ID
function buscarIdoso() {
    const input = document.getElementById("search-idoso").value.toLowerCase().trim();
    const resultsContainer = document.getElementById("search-results");

    if (input === "") {
        resultsContainer.classList.add("hidden");
        return;
    }

    const filtrados = idososCadastrados.filter(i => 
        i.nome.toLowerCase().includes(input) || i.id.includes(input)
    );

    resultsContainer.innerHTML = "";

    if (filtrados.length === 0) {
        resultsContainer.innerHTML = `<div class="search-item">Nenhum idoso encontrado</div>`;
    } else {
        filtrados.forEach(idoso => {
            const item = document.createElement("div");
            item.className = "search-item";
            item.innerHTML = `
                <strong>${idoso.nome}</strong>
                <span>ID: #${idoso.id}</span>
            `;
            item.onclick = () => selecionarIdoso(idoso);
            resultsContainer.appendChild(item);
        });
    }

    resultsContainer.classList.remove("hidden");
}

// Selecionar idoso e atualizar o dashboard
function selecionarIdoso(idoso) {
    idosoSelecionado = idoso;
    carregarDadosIdoso(idoso);
    document.getElementById("search-results").classList.add("hidden");
    document.getElementById("search-idoso").value = "";
}

// Carregar dados no painel
function carregarDadosIdoso(idoso) {
    document.getElementById("current-idoso-label").innerText = `Idoso: ${idoso.nome} (ID: #${idoso.id})`;
    document.getElementById("dashboard-title").innerText = `Resumo de hoje: ${idoso.nome}`;
    
    document.getElementById("card-remedios").innerText = idoso.remedios;
    document.getElementById("card-atrasos").innerText = idoso.atrasos;
    document.getElementById("card-compromissos").innerText = idoso.compromissos;
    document.getElementById("card-compromisso-desc").innerText = idoso.compromissoDesc;

    // Salva o idoso selecionado para que o perfil saiba quem carregar
    localStorage.setItem("selectedIdoso", JSON.stringify(idoso));

    renderizarNotificacoes();
}

// Redireciona para o Perfil do Idoso ativo
// Redireciona para o Perfil do Idoso ativo
function irParaPerfilIdoso(event) {
    event.preventDefault();
    if (idosoSelecionado) {
        localStorage.setItem("selectedIdoso", JSON.stringify(idosoSelecionado));
    }
    
    // Altere para o caminho relativo correto:
    // Se o arquivo estiver dentro da pasta "inicioidoso":
    window.location.href = "../inicioidoso/inicioidoso.html"; 
    
    // Se estiver direto na pasta anterior (raiz):
    // window.location.href = "../inicioidoso.html";
}

// Alternar visibilidade do menu do sininho
function toggleNotificacoes() {
    const drawer = document.getElementById("notif-drawer");
    drawer.classList.toggle("hidden");

    if (!drawer.classList.contains("hidden") && idosoSelecionado && idosoSelecionado.notificacoes) {
        idosoSelecionado.notificacoes.forEach(n => n.lida = true);
        atualizarBadge();
    }
}

// Renderizar lista de notificações
function renderizarNotificacoes() {
    const list = document.getElementById("notif-list");
    list.innerHTML = "";

    if (!idosoSelecionado || !idosoSelecionado.notificacoes || idosoSelecionado.notificacoes.length === 0) {
        list.innerHTML = `<li class="notif-item">Nenhuma notificação recente.</li>`;
    } else {
        idosoSelecionado.notificacoes.forEach(n => {
            const li = document.createElement("li");
            li.className = `notif-item ${!n.lida ? 'new' : ''}`;
            li.innerHTML = `
                <span>${n.texto}</span>
                <span class="notif-time">${n.hora}</span>
            `;
            list.appendChild(li);
        });
    }

    atualizarBadge();
}

// Atualizar contador do badge de notificações
function atualizarBadge() {
    if (!idosoSelecionado || !idosoSelecionado.notificacoes) return;

    const naoLidas = idosoSelecionado.notificacoes.filter(n => !n.lida).length;
    const badge = document.getElementById("notif-badge");

    if (naoLidas > 0) {
        badge.innerText = naoLidas;
        badge.classList.remove("hidden");
    } else {
        badge.classList.add("hidden");
    }
}

// Limpar notificações do idoso atual
function limparNotificacoes() {
    if (idosoSelecionado) {
        idosoSelecionado.notificacoes = [];
        renderizarNotificacoes();
    }
}

// Fechar menus se clicar fora
document.addEventListener("click", (e) => {
    const searchContainer = document.querySelector(".search-box-container");
    const notifContainer = document.querySelector(".notification-container");

    if (searchContainer && !searchContainer.contains(e.target)) {
        document.getElementById("search-results").classList.add("hidden");
    }

    if (notifContainer && !notifContainer.contains(e.target)) {
        document.getElementById("notif-drawer").classList.add("hidden");
    }
});