document.addEventListener("DOMContentLoaded", () => {
    const channel = new BroadcastChannel("zelo_channel");

    const sintomasInput = document.getElementById("sintomas-input");
    const btnEnviarTexto = document.getElementById("btn-enviar-texto");
    const btnMic = document.getElementById("btn-mic-recorder");
    const micStatusText = document.getElementById("mic-status-text");

    const modalSucesso = document.getElementById("modal-sucesso");
    const modalEmergencia = document.getElementById("modal-emergencia");
    const btnEstouBem = document.getElementById("btn-estou-bem");
    const btnPedirAjuda = document.getElementById("btn-pedir-ajuda");
    const btnFecharEmergencia = document.getElementById("btn-fechar-emergencia");

    let mediaRecorder;
    let audioChunks = [];
    let isRecording = false;

    function exibirSucesso(tipo = "texto") {
        if (modalSucesso) modalSucesso.style.display = "flex";

        const evento = {
            tipo: "MENSAGEM_MEDICO",
            formato: tipo,
            dataHora: new Date().toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit" }),
            mensagem: "Nova mensagem enviada ao médico pelo idoso."
        };

        localStorage.setItem("zelo_ultimo_evento", JSON.stringify(evento));
        channel.postMessage(evento);
    }

    if (btnEnviarTexto) {
        btnEnviarTexto.addEventListener("click", () => {
            const texto = sintomasInput ? sintomasInput.value.trim() : "";
            if (!texto) {
                alert("⚠️ Por favor, escreva o que está sentindo antes de enviar.");
                return;
            }
            sintomasInput.value = "";
            exibirSucesso("texto");
        });
    }

    if (btnMic) {
        btnMic.addEventListener("click", async () => {
            if (isRecording) {
                mediaRecorder.stop();
                return;
            }

            try {
                const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
                mediaRecorder = new MediaRecorder(stream);
                audioChunks = [];

                mediaRecorder.ondataavailable = (event) => {
                    audioChunks.push(event.data);
                };

                mediaRecorder.onstart = () => {
                    isRecording = true;
                    btnMic.classList.add("recording");
                    if (micStatusText) micStatusText.innerText = "🛑 GRAVANDO... CLIQUE NOVAMENTE PARA PARAR E ENVIAR";
                };

                mediaRecorder.onstop = () => {
                    isRecording = false;
                    btnMic.classList.remove("recording");
                    if (micStatusText) micStatusText.innerText = "🎙️ CLIQUE NO BOTÃO ABAIXO PARA COMEÇAR A GRAVAR SEU ÁUDIO";
                    
                    stream.getTracks().forEach(track => track.stop());
                    exibirSucesso("audio");
                };

                mediaRecorder.start();
            } catch (err) {
                alert("⚠️ Permissão de microfone negada ou indisponível no navegador.");
            }
        });
    }

    if (btnEstouBem) {
        btnEstouBem.addEventListener("click", () => {
            if (modalSucesso) modalSucesso.style.display = "none";
        });
    }

    if (btnPedirAjuda) {
        btnPedirAjuda.addEventListener("click", () => {
            if (modalSucesso) modalSucesso.style.display = "none";
            if (modalEmergencia) modalEmergencia.style.display = "flex";
        });
    }

    if (btnFecharEmergencia) {
        btnFecharEmergencia.addEventListener("click", () => {
            if (modalEmergencia) modalEmergencia.style.display = "none";
        });
    }

    document.querySelectorAll(".emergency-btn").forEach(btn => {
        btn.addEventListener("click", () => {
            const servico = btn.querySelector("span:last-child")?.innerText || "EMERGÊNCIA";
            const evento = {
                tipo: "ALERTA_EMERGENCIA",
                servico: servico,
                dataHora: new Date().toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit" })
            };
            localStorage.setItem("zelo_ultimo_evento", JSON.stringify(evento));
            channel.postMessage(evento);
        });
    });
});