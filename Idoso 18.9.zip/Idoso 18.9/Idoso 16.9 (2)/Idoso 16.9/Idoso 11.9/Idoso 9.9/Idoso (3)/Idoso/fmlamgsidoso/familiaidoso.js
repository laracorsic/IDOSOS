document.addEventListener("DOMContentLoaded", function () {

    // Gerenciamento de dados persistente no LocalStorage
    function obterContatos() {
        const salvos = localStorage.getItem("zelo_contatos");
        if (!salvos) return [];
        try {
            return JSON.parse(salvos);
        } catch (e) {
            return [];
        }
    }

    function salvarContatos(lista) {
        localStorage.setItem("zelo_contatos", JSON.stringify(lista));
    }

    // Referências do DOM
    const contactsGrid = document.getElementById("contacts-grid");
    
    // Modais
    const modalContato = document.getElementById("modal-contato");
    const modalMensagem = document.getElementById("modal-mensagem");
    const modalCadastro = document.getElementById("modal-cadastro");

    // Elementos do Modal de Ação
    const nomeContatoModal = document.getElementById("nome-contato");
    const relacaoContatoModal = document.getElementById("relacao-contato");
    const botaoLigar = document.getElementById("botao-ligar");
    const botaoMensagem = document.getElementById("botao-mensagem");
    const botaoExcluir = document.getElementById("botao-excluir");

    // Elementos do Modal de Mensagem
    const mensagemNome = document.getElementById("mensagem-nome");
    const campoMensagem = document.getElementById("campo-mensagem");
    const enviarMensagem = document.getElementById("enviar-mensagem");

    // Form de Cadastro
    const btnAbrirCadastro = document.getElementById("btn-abrir-cadastro");
    const formNovoContato = document.getElementById("form-novo-contato");

    // Botão emergência familiar
    const btnFamiliarEmergencia = document.getElementById("botao-familiar-emergencia");

    let contatoAtual = null;

    // Renderização dos cards de contatos
    function renderizarContatos() {
        const contatos = obterContatos();
        contactsGrid.innerHTML = "";

        if (contatos.length === 0) {
            contactsGrid.innerHTML = `
                <div class="mensagem-vazia">
                    Nenhum contato cadastrado ainda.<br><br>
                    Clique no botão verde acima para cadastrar seu primeiro contato!
                </div>
            `;
            if (btnFamiliarEmergencia) {
                btnFamiliarEmergencia.href = "#";
                btnFamiliarEmergencia.onclick = function() {
                    alert("Ainda não há contatos cadastrados para o botão de emergência.");
                };
            }
            return;
        }

        contatos.forEach(contato => {
            const cardButton = document.createElement("button");
            cardButton.type = "button";
            cardButton.className = "contact-card";
            cardButton.setAttribute("aria-label", `Opções para ${contato.nome}`);
            
            cardButton.innerHTML = `
                <div class="avatar-wrapper">
                    <img src="iconeusuario.png" alt="" class="avatar-img">
                </div>
                <div class="contact-info">
                    <p class="contact-name">${contato.nome}</p>
                    <p class="contact-relation">(${contato.relacao})</p>
                </div>
            `;

            cardButton.addEventListener("click", () => {
                abrirModalContato(contato);
            });

            contactsGrid.appendChild(cardButton);
        });

        // Primeiro contato vira padrão da emergência familiar
        if (btnFamiliarEmergencia && contatos.length > 0) {
            btnFamiliarEmergencia.onclick = null;
            btnFamiliarEmergencia.href = `tel:${contatos[0].telefone}`;
        }
    }

    // Modal e Ações
    function abrirModalContato(contato) {
        contatoAtual = contato;
        nomeContatoModal.textContent = contato.nome;
        relacaoContatoModal.textContent = `(${contato.relacao})`;
        modalContato.classList.add("aberto");
        modalContato.setAttribute("aria-hidden", "false");
    }

    function fecharModais() {
        modalContato.classList.remove("aberto");
        modalMensagem.classList.remove("aberto");
        modalCadastro.classList.remove("aberto");
        modalContato.setAttribute("aria-hidden", "true");
        modalMensagem.setAttribute("aria-hidden", "true");
        modalCadastro.setAttribute("aria-hidden", "true");
    }

    if (botaoLigar) {
        botaoLigar.addEventListener("click", function () {
            if (!contatoAtual || !contatoAtual.telefone) {
                alert("Número de telefone não encontrado.");
                return;
            }
            window.location.href = `tel:${contatoAtual.telefone}`;
        });
    }

    if (botaoMensagem) {
        botaoMensagem.addEventListener("click", function () {
            if (!contatoAtual) return;
            modalContato.classList.remove("aberto");
            mensagemNome.textContent = contatoAtual.nome;
            campoMensagem.value = "";
            modalMensagem.classList.add("aberto");
            modalMensagem.setAttribute("aria-hidden", "false");
        });
    }

    if (enviarMensagem) {
        enviarMensagem.addEventListener("click", function () {
            const texto = campoMensagem.value.trim();
            if (!texto) {
                alert("Por favor, escreva uma mensagem antes de enviar.");
                return;
            }

            const numLimpo = contatoAtual.telefone.replace(/\D/g, "");
            const linkWhatsapp = `https://api.whatsapp.com/send?phone=${numLimpo}&text=${encodeURIComponent(texto)}`;
            
            window.open(linkWhatsapp, "_blank");
            fecharModais();
        });
    }

    if (botaoExcluir) {
        botaoExcluir.addEventListener("click", function () {
            if (!contatoAtual) return;
            if (confirm(`Tem certeza que deseja apagar o contato de ${contatoAtual.nome}?`)) {
                let contatos = obterContatos();
                contatos = contatos.filter(c => c.id !== contatoAtual.id);
                salvarContatos(contatos);
                fecharModais();
                renderizarContatos();
            }
        });
    }

    if (btnAbrirCadastro) {
        btnAbrirCadastro.addEventListener("click", function () {
            formNovoContato.reset();
            modalCadastro.classList.add("aberto");
            modalCadastro.setAttribute("aria-hidden", "false");
        });
    }

    if (formNovoContato) {
        formNovoContato.addEventListener("submit", function (e) {
            e.preventDefault();

            const nome = document.getElementById("novo-nome").value.trim();
            const relacao = document.getElementById("novo-parentesco").value.trim();
            const telefone = document.getElementById("novo-telefone").value.trim();

            if (!nome || !telefone) {
                alert("Por favor, preencha o nome e o telefone.");
                return;
            }

            const novoContato = {
                id: Date.now().toString(),
                nome: nome,
                relacao: relacao || "Contato",
                telefone: telefone
            };

            const contatos = obterContatos();
            contatos.push(novoContato);
            salvarContatos(contatos);

            fecharModais();
            renderizarContatos();
            alert("Contato salvo com sucesso!");
        });
    }

    // Fechamento dos Modais
    const btnFecharModal = document.getElementById("fechar-modal");
    const btnFecharMsg = document.getElementById("fechar-mensagem");
    const btnFecharCad = document.getElementById("fechar-cadastro");
    const btnCancCad = document.getElementById("cancelar-cadastro");
    const btnCancMsg = document.getElementById("cancelar-mensagem");

    if (btnFecharModal) btnFecharModal.addEventListener("click", fecharModais);
    if (btnFecharMsg) btnFecharMsg.addEventListener("click", fecharModais);
    if (btnFecharCad) btnFecharCad.addEventListener("click", fecharModais);
    if (btnCancCad) btnCancCad.addEventListener("click", fecharModais);
    
    if (btnCancMsg) {
        btnCancMsg.addEventListener("click", () => {
            modalMensagem.classList.remove("aberto");
            modalContato.classList.add("aberto");
        });
    }

    renderizarContatos();
});