document.addEventListener("DOMContentLoaded", () => {
    // 1. Carrega dados do idoso selecionado
    const selectedIdoso = JSON.parse(localStorage.getItem("selectedIdoso")) || {};
    const currentUser = JSON.parse(localStorage.getItem("currentUser")) || {};

    const idDisplay = document.getElementById("idoso-id-display");
    if (idDisplay) {
        idDisplay.innerText = selectedIdoso.id || currentUser.idIdoso || "38299";
    }

    // 2. Atualiza a data atual dinamicamente
    const dateTitle = document.getElementById("current-date-title");
    if (dateTitle) {
        const agora = new Date();
        const opcoes = { day: '2-digit', month: 'long', year: 'numeric' };
        const dataFormatada = agora.toLocaleDateString('pt-BR', opcoes).toUpperCase();
        dateTitle.innerText = `HOJE, DIA ${dataFormatada}`;
    }
});