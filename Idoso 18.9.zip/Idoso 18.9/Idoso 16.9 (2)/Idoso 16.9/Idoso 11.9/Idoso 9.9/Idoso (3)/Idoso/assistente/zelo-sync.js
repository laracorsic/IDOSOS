// Gerenciador central de sincronização em tempo real ZELO
if (typeof window.ZeloSync === "undefined") {
    window.ZeloSync = (() => {
        // Suporte seguro para BroadcastChannel em diferentes navegadores
        const channel = ("BroadcastChannel" in window) ? new BroadcastChannel("zelo_channel") : null;

        // Função para emitir notificação
        function emitirEvento(tipo, dados = {}) {
            const payload = {
                tipo,
                ...dados,
                timestamp: new Date().toISOString(),
                dataHora: new Date().toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit" })
            };

            try {
                localStorage.setItem("zelo_ultimo_evento", JSON.stringify(payload));
            } catch (erro) {
                console.warn("[ZeloSync] Erro ao guardar no LocalStorage:", erro);
            }

            if (channel) {
                try {
                    channel.postMessage(payload);
                } catch (erro) {
                    console.warn("[ZeloSync] Erro ao enviar mensagem pelo BroadcastChannel:", erro);
                }
            }
        }

        // Ouve mensagens no BroadcastChannel e no LocalStorage (fallback entre guias/janelas)
        function escutarEventos(callback) {
            if (typeof callback !== "function") return;

            if (channel) {
                channel.onmessage = (event) => callback(event.data);
            }

            window.addEventListener("storage", (event) => {
                if (event.key === "zelo_ultimo_evento" && event.newValue) {
                    try {
                        const dados = JSON.parse(event.newValue);
                        callback(dados);
                    } catch (erro) {
                        console.error("[ZeloSync] Erro ao processar dados do evento:", erro);
                    }
                }
            });
        }

        return { emitirEvento, escutarEventos };
    })();
}