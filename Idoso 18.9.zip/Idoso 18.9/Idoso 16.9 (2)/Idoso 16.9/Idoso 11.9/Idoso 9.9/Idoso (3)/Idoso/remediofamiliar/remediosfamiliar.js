document.addEventListener("DOMContentLoaded", () => {
    const btnSininho = document.getElementById("btn-sininho");
    const notifDropdown = document.getElementById("notif-dropdown");
    const notifLista = document.getElementById("notif-lista");
    const notifBadge = document.getElementById("notif-badge");
    const btnLimpar = document.getElementById("btn-limpar-notif");

    let notificacoes = JSON.parse(localStorage.getItem("zelo_notificacoes_salvas")) || [];

    function renderizarNotificacoes() {
        notifLista.innerHTML = "";

        if (notificacoes.length === 0) {
            notifLista.innerHTML = `<p class="notif-empty">Nenhuma notificação no momento.</p>`;
            notifBadge.style.display = "none";
            return;
        }

        notifBadge.textContent = notificacoes.length;
        notifBadge.style.display = "block";

        notificacoes.forEach((notif) => {
            const item = document.createElement("div");
            item.className = "notif-item";
            item.innerHTML = `
                <div class="notif-item-text">💊 ${notif.mensagem}</div>
                <div class="notif-item-time">${notif.hora}</div>
            `;
            notifLista.appendChild(item);
        });
    }

    if (btnSininho) {
        btnSininho.addEventListener("click", (e) => {
            e.stopPropagation();
            notifDropdown.classList.toggle("is-open");
        });
    }

    document.addEventListener("click", () => {
        if (notifDropdown) notifDropdown.classList.remove("is-open");
    });

    if (btnLimpar) {
        btnLimpar.addEventListener("click", () => {
            notificacoes = [];
            localStorage.removeItem("zelo_notificacoes_salvas");
            renderizarNotificacoes();
        });
    }

    if (typeof ZeloSync !== "undefined") {
        ZeloSync.escutarEventos((dados) => {
            if (dados.tipo === "REMEDIO_TOMADO") {
                const novaNotif = {
                    mensagem: dados.mensagem || "O idoso tomou o remédio!",
                    hora: dados.dataHora || new Date().toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit" })
                };

                notificacoes.unshift(novaNotif);
                localStorage.setItem("zelo_notificacoes_salvas", JSON.stringify(notificacoes));
                renderizarNotificacoes();
            }
        });
    }

    renderizarNotificacoes();
});