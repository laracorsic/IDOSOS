document.addEventListener("DOMContentLoaded", function () {


    /* =====================================================
       BOTÃO "PRECISA DE AJUDA?"
    ====================================================== */

    const botaoAjudaIdoso =
        document.getElementById("botao-ajuda-idoso");

    const mensagemAjudaIdoso =
        document.getElementById("mensagem-ajuda-idoso");


    if (botaoAjudaIdoso && mensagemAjudaIdoso) {

        botaoAjudaIdoso.addEventListener(
            "click",
            function () {

                const aberta =
                    mensagemAjudaIdoso.classList.contains("aberta");


                if (aberta) {

                    mensagemAjudaIdoso.classList.remove("aberta");

                    mensagemAjudaIdoso.setAttribute(
                        "aria-hidden",
                        "true"
                    );

                    botaoAjudaIdoso.setAttribute(
                        "aria-expanded",
                        "false"
                    );

                } else {

                    mensagemAjudaIdoso.classList.add("aberta");

                    mensagemAjudaIdoso.setAttribute(
                        "aria-hidden",
                        "false"
                    );

                    botaoAjudaIdoso.setAttribute(
                        "aria-expanded",
                        "true"
                    );

                }

            }
        );

    }



    /* =====================================================
       EMERGÊNCIA
    ====================================================== */

    const botaoAjuda =
        document.getElementById("botao-ajuda");

    const modalEmergencia =
        document.getElementById("modal-emergencia");

    const fecharEmergencia =
        document.getElementById("fechar-emergencia");


    /* =====================================================
       ABRIR EMERGÊNCIA
    ====================================================== */

    if (botaoAjuda && modalEmergencia) {

        botaoAjuda.addEventListener(
            "click",
            function () {

                modalEmergencia.classList.add("aberto");

                modalEmergencia.setAttribute(
                    "aria-hidden",
                    "false"
                );


                if (fecharEmergencia) {

                    fecharEmergencia.focus();

                }

            }
        );

    }



    /* =====================================================
       FECHAR EMERGÊNCIA
    ====================================================== */

    if (fecharEmergencia && modalEmergencia) {

        fecharEmergencia.addEventListener(
            "click",
            function () {

                fecharModalEmergencia();

            }
        );

    }



    /* =====================================================
       FUNÇÃO FECHAR MODAL
    ====================================================== */

    function fecharModalEmergencia() {

        if (!modalEmergencia) {

            return;

        }


        modalEmergencia.classList.remove("aberto");

        modalEmergencia.setAttribute(
            "aria-hidden",
            "true"
        );


        if (botaoAjuda) {

            botaoAjuda.focus();

        }

    }



    /* =====================================================
       CLICAR FORA DO MODAL
    ====================================================== */

    if (modalEmergencia) {

        modalEmergencia.addEventListener(
            "click",
            function (event) {

                if (event.target === modalEmergencia) {

                    fecharModalEmergencia();

                }

            }
        );

    }



    /* =====================================================
       TECLA ESC
    ====================================================== */

    document.addEventListener(
        "keydown",
        function (event) {

            if (event.key !== "Escape") {

                return;

            }


            if (
                modalEmergencia &&
                modalEmergencia.classList.contains("aberto")
            ) {

                fecharModalEmergencia();

            }


            if (
                mensagemAjudaIdoso &&
                mensagemAjudaIdoso.classList.contains("aberta")
            ) {

                mensagemAjudaIdoso.classList.remove("aberta");

                mensagemAjudaIdoso.setAttribute(
                    "aria-hidden",
                    "true"
                );

                if (botaoAjudaIdoso) {

                    botaoAjudaIdoso.setAttribute(
                        "aria-expanded",
                        "false"
                    );

                }

            }

        }
    );


});