# Lista de Casa — demonstração

Demonstração de uma lista doméstica pensada para pessoas idosas. Não é uma loja e não mostra preços.

- imagens grandes;
- letras grandes;
- busca simples;
- escolha da quantidade;
- lista dos itens que estão faltando;
- botão para enviar a lista para um familiar pelo compartilhamento do celular ou WhatsApp;
- não precisa de banco, Node ou API.

## Como abrir no VS Code

1. Abra a pasta `loja-idosos-demo` no VS Code.
2. Instale a extensão **Live Server** (Ritwick Dey), se ainda não tiver.
3. Clique com o botão direito em `index.html`.
4. Escolha **Open with Live Server**.

O navegador abrirá a demonstração automaticamente.

## Como testar

1. Escolha a quantidade de um produto.
2. Clique em **Adicionar à lista**.
3. Abra **Minha lista** no canto superior.
4. Clique em **Enviar lista para familiar**.

O botão abre diretamente uma conversa do WhatsApp com o número configurado e deixa a mensagem pronta. É preciso tocar em **Enviar** no WhatsApp para concluir o envio.

As imagens da demonstração são carregadas de URLs públicas do Unsplash. Em um sistema real, podem ser trocadas por imagens locais ou por imagens da API Open Food Facts.
