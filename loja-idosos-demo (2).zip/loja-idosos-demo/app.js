const products = [
  { id: 1, name: "Arroz branco 5 kg", category: "Mercearia", image: "https://images.unsplash.com/photo-1586201375761-83865001e31c?auto=format&fit=crop&w=700&q=80" },
  { id: 2, name: "Feijão carioca 1 kg", category: "Mercearia", image: "https://images.unsplash.com/photo-1551462147-ff29053bfc14?auto=format&fit=crop&w=700&q=80" },
  { id: 3, name: "Leite integral 1 litro", category: "Laticínios", image: "https://images.unsplash.com/photo-1563636619-e9143da7973b?auto=format&fit=crop&w=700&q=80" },
  { id: 4, name: "Banana prata 1 kg", category: "Hortifruti", image: "https://images.unsplash.com/photo-1571771894821-ce9b6c11b08e?auto=format&fit=crop&w=700&q=80" },
  { id: 5, name: "Café torrado 500 g", category: "Mercearia", image: "https://images.unsplash.com/photo-1495474472287-4d71bcdd2085?auto=format&fit=crop&w=700&q=80" },
  { id: 6, name: "Papel higiênico 12 rolos", category: "Limpeza", image: "https://images.unsplash.com/photo-1584556812952-905ffd0c611a?auto=format&fit=crop&w=700&q=80" }
];

const FAMILY_WHATSAPP = "5516993966195";
let list = [];
const grid = document.querySelector("#productGrid");
const search = document.querySelector("#search");
const listCount = document.querySelector("#listCount");
const listItems = document.querySelector("#listItems");
const listPanel = document.querySelector("#listPanel");
const overlay = document.querySelector("#overlay");
const toast = document.querySelector("#toast");

function showToast(message) {
  toast.textContent = message;
  toast.classList.add("show");
  setTimeout(() => toast.classList.remove("show"), 2500);
}

function renderProducts(items = products) {
  if (!items.length) {
    grid.innerHTML = '<p class="empty">Nenhum item encontrado. Tente outra palavra.</p>';
    return;
  }
  grid.innerHTML = items.map(product => `
    <article class="product-card">
      <img src="${product.image}" alt="Imagem de ${product.name}" loading="lazy" />
      <span class="category">${product.category}</span>
      <h2>${product.name}</h2>
      <label class="quantity-label" for="quantity-${product.id}">Quantidade</label>
      <input id="quantity-${product.id}" class="quantity-input" type="number" min="1" max="99" value="1" />
      <button class="add-button" data-id="${product.id}">Adicionar à lista</button>
    </article>
  `).join("");
  document.querySelectorAll(".add-button").forEach(button => {
    button.addEventListener("click", () => {
      const id = Number(button.dataset.id);
      const quantity = Number(document.querySelector(`#quantity-${id}`).value) || 1;
      addToList(id, quantity);
    });
  });
}

function addToList(id, quantity) {
  const product = products.find(item => item.id === id);
  const found = list.find(item => item.id === id);
  if (found) found.quantity += quantity;
  else list.push({ ...product, quantity });
  renderList();
  showToast(`${product.name} entrou na sua lista.`);
}

function renderList() {
  const count = list.reduce((sum, item) => sum + item.quantity, 0);
  listCount.textContent = count;
  if (!list.length) listItems.innerHTML = '<p>Ainda não há itens na lista.</p>';
  else listItems.innerHTML = list.map(item => `
    <div class="list-row">
      <div><strong>${item.name}</strong><small>Quantidade: ${item.quantity}</small></div>
      <button class="remove-button" data-remove="${item.id}">Remover</button>
    </div>
  `).join("");
  document.querySelectorAll("[data-remove]").forEach(button => button.addEventListener("click", () => {
    list = list.filter(item => item.id !== Number(button.dataset.remove));
    renderList();
  }));
}

function toggleList(open) {
  listPanel.classList.toggle("open", open);
  listPanel.setAttribute("aria-hidden", String(!open));
  overlay.hidden = !open;
}

function sendList() {
  if (!list.length) {
    showToast("Adicione algum item antes de enviar.");
    return;
  }
  const text = ["Olá! Esta é a lista do que está faltando em casa:", "", ...list.map(item => `• ${item.name} — quantidade: ${item.quantity}`), "", "Obrigado!"] .join("\n");
  window.open(`https://wa.me/${FAMILY_WHATSAPP}?text=${encodeURIComponent(text)}`, "_blank");
}

search.addEventListener("input", event => {
  const term = event.target.value.toLocaleLowerCase("pt-BR");
  renderProducts(products.filter(item => `${item.name} ${item.category}`.toLocaleLowerCase("pt-BR").includes(term)));
});
document.querySelector("#listButton").addEventListener("click", () => toggleList(true));
document.querySelector("#closeList").addEventListener("click", () => toggleList(false));
overlay.addEventListener("click", () => toggleList(false));
document.querySelector("#sendButton").addEventListener("click", sendList);
document.querySelector("#clearButton").addEventListener("click", () => { list = []; renderList(); showToast("Lista limpa."); });
renderProducts();
renderList();
