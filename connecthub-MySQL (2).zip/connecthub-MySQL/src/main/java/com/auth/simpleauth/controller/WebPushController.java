package com.auth.simpleauth.controller;

import com.auth.simpleauth.dto.WebPushConfigurationResponse;
import com.auth.simpleauth.dto.WebPushSubscriptionRequest;
import com.auth.simpleauth.entity.Usuario;
import com.auth.simpleauth.service.WebPushNotificationService;
import jakarta.servlet.http.HttpSession;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/notificacoes/push")
public class WebPushController {
    private final WebPushNotificationService webPushService;

    public WebPushController(WebPushNotificationService webPushService) {
        this.webPushService = webPushService;
    }

    @GetMapping("/configuracao")
    public WebPushConfigurationResponse configuracao() {
        return new WebPushConfigurationResponse(webPushService.isEnabled(), webPushService.getPublicKey());
    }

    @PostMapping("/inscricoes")
    public ResponseEntity<Void> registrar(@Valid @RequestBody WebPushSubscriptionRequest request,
                                          HttpSession session) {
        Usuario usuario = usuarioDaSessao(session);
        webPushService.registrar(usuario.getId(), request);
        return ResponseEntity.status(HttpStatus.CREATED).build();
    }

    @GetMapping("/inscricoes/status")
    public InscricaoStatus status(HttpSession session) {
        Usuario usuario = usuarioDaSessao(session);
        return new InscricaoStatus(webPushService.temInscricao(usuario.getId()));
    }

    @PostMapping("/teste")
    public ResponseEntity<TesteResponse> teste(HttpSession session) {
        Usuario usuario = usuarioDaSessao(session);
        if (!webPushService.temInscricao(usuario.getId())) {
            return ResponseEntity.status(HttpStatus.CONFLICT)
                    .body(new TesteResponse("Ative as notificações neste navegador antes de testar."));
        }
        webPushService.notificar(usuario.getId(), "Teste de notificações",
                "As notificações do ConnectHub estão funcionando neste navegador.", "/configuracoes.html");
        return ResponseEntity.accepted().body(new TesteResponse("Teste enviado para o navegador."));
    }

    @DeleteMapping("/inscricoes")
    public ResponseEntity<Void> remover(@Valid @RequestBody RemoverInscricaoRequest request,
                                        HttpSession session) {
        Usuario usuario = usuarioDaSessao(session);
        webPushService.remover(usuario.getId(), request.endpoint());
        return ResponseEntity.noContent().build();
    }

    private static Usuario usuarioDaSessao(HttpSession session) {
        Object valor = session.getAttribute("usuario");
        if (valor instanceof Usuario usuario) return usuario;
        throw new IllegalStateException("Sessão de usuário inválida.");
    }

    public record InscricaoStatus(boolean inscrito) {}
    public record TesteResponse(String message) {}
    public record RemoverInscricaoRequest(@NotBlank String endpoint) {}
}
