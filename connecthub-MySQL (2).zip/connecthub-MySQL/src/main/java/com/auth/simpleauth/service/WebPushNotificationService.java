package com.auth.simpleauth.service;

import com.auth.simpleauth.dto.WebPushSubscriptionRequest;
import com.auth.simpleauth.entity.Usuario;
import com.auth.simpleauth.entity.WebPushSubscription;
import com.auth.simpleauth.entity.WebPushVapidKey;
import com.auth.simpleauth.repository.UsuarioRepository;
import com.auth.simpleauth.repository.WebPushSubscriptionRepository;
import com.auth.simpleauth.repository.WebPushVapidKeyRepository;
import com.fasterxml.jackson.databind.ObjectMapper;
import jakarta.annotation.PostConstruct;
import nl.martijndwars.webpush.Notification;
import nl.martijndwars.webpush.PushService;
import org.apache.http.HttpResponse;
import org.bouncycastle.jce.interfaces.ECPrivateKey;
import org.bouncycastle.jce.interfaces.ECPublicKey;
import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.bouncycastle.util.BigIntegers;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.net.URI;
import java.nio.charset.StandardCharsets;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.SecureRandom;
import java.security.Security;
import java.security.spec.ECGenParameterSpec;
import java.util.Base64;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

@Service
public class WebPushNotificationService {
    private static final Logger log = LoggerFactory.getLogger(WebPushNotificationService.class);
    private static final Long VAPID_KEY_ID = 1L;

    private final WebPushSubscriptionRepository subscriptionRepository;
    private final WebPushVapidKeyRepository vapidKeyRepository;
    private final UsuarioRepository usuarioRepository;
    private final ObjectMapper objectMapper;

    private String publicKey;
    private String privateKey;

    @Value("${app.webpush.vapid.subject:mailto:admin@connecthub.app}")
    private String subject;

    public WebPushNotificationService(WebPushSubscriptionRepository subscriptionRepository,
                                      WebPushVapidKeyRepository vapidKeyRepository,
                                      UsuarioRepository usuarioRepository,
                                      ObjectMapper objectMapper) {
        this.subscriptionRepository = subscriptionRepository;
        this.vapidKeyRepository = vapidKeyRepository;
        this.usuarioRepository = usuarioRepository;
        this.objectMapper = objectMapper;
        if (Security.getProvider(BouncyCastleProvider.PROVIDER_NAME) == null) {
            Security.addProvider(new BouncyCastleProvider());
        }
    }

    @PostConstruct
    public void inicializarChavesVapid() {
        Optional<WebPushVapidKey> chaveSalva = vapidKeyRepository.findById(VAPID_KEY_ID);
        if (chaveSalva.isEmpty()) {
            try {
                chaveSalva = Optional.of(vapidKeyRepository.saveAndFlush(gerarParVapid()));
                log.info("Par de chaves Web Push criado e armazenado no banco de dados.");
            } catch (DataIntegrityViolationException corridaDeInicializacao) {
                // Duas instâncias podem iniciar juntas; a que perdeu usa o par persistido pela outra.
                chaveSalva = vapidKeyRepository.findById(VAPID_KEY_ID);
                if (chaveSalva.isEmpty()) throw corridaDeInicializacao;
            }
        }
        this.publicKey = chaveSalva.get().getPublicKey();
        this.privateKey = chaveSalva.get().getPrivateKey();
        try {
            PushService configuracao = new PushService(publicKey, privateKey, subject);
            if (!nl.martijndwars.webpush.Utils.verifyKeyPair(
                    configuracao.getPrivateKey(), configuracao.getPublicKey())) {
                throw new IllegalStateException("O par VAPID salvo não corresponde.");
            }
        } catch (Exception e) {
            throw new IllegalStateException("As chaves VAPID persistidas são inválidas.", e);
        }
    }

    public boolean isEnabled() {
        return publicKey != null && !publicKey.isBlank()
                && privateKey != null && !privateKey.isBlank();
    }

    public String getPublicKey() {
        return isEnabled() ? publicKey : null;
    }

    @Transactional
    public void registrar(Long usuarioId, WebPushSubscriptionRequest request) {
        validarEndpoint(request.getEndpoint());
        validarChaves(request.getKeys().getP256dh(), request.getKeys().getAuth());
        Usuario usuario = usuarioRepository.findById(usuarioId)
                .orElseThrow(() -> new IllegalArgumentException("Usuário não encontrado."));
        String hash = hashEndpoint(request.getEndpoint());
        Optional<WebPushSubscription> existente = subscriptionRepository.findByEndpointHash(hash);
        if (existente.isPresent()) {
            existente.get().atualizar(usuario, request.getEndpoint(), request.getKeys().getP256dh(), request.getKeys().getAuth());
        } else {
            subscriptionRepository.save(new WebPushSubscription(
                    usuario,
                    hash,
                    request.getEndpoint(),
                    request.getKeys().getP256dh(),
                    request.getKeys().getAuth()
            ));
        }
    }

    @Transactional
    public void remover(Long usuarioId, String endpoint) {
        validarEndpoint(endpoint);
        subscriptionRepository.deleteByUsuarioIdAndEndpointHash(usuarioId, hashEndpoint(endpoint));
    }

    public boolean temInscricao(Long usuarioId) {
        return subscriptionRepository.existsByUsuarioId(usuarioId);
    }

    @Async("webPushAsyncExecutor")
    public void notificar(Long usuarioId, String titulo, String mensagem, String url) {
        if (!isEnabled() || usuarioId == null) return;

        for (WebPushSubscription subscription : subscriptionRepository.findByUsuarioId(usuarioId)) {
            try {
                PushService pushService = new PushService(publicKey, privateKey, subject);
                Map<String, String> payload = new HashMap<>();
                payload.put("title", titulo);
                payload.put("body", mensagem);
                payload.put("url", url == null || url.isBlank() ? "/" : url);
                payload.put("tag", "connecthub-notificacao");
                byte[] content = objectMapper.writeValueAsBytes(payload);

                Notification notification = new Notification(
                        subscription.getEndpoint(),
                        nl.martijndwars.webpush.Utils.loadPublicKey(subscription.getP256dh()),
                        Base64.getUrlDecoder().decode(subscription.getAuth()),
                        content,
                        3600
                );
                HttpResponse response = pushService.send(notification);
                int status = response.getStatusLine().getStatusCode();
                if (status == 404 || status == 410) {
                    subscriptionRepository.deleteById(subscription.getId());
                    log.info("Inscrição Web Push expirada removida (id={}).", subscription.getId());
                } else if (status < 200 || status >= 300) {
                    log.warn("Push service retornou HTTP {} para uma inscrição.", status);
                }
            } catch (Exception e) {
                log.warn("Não foi possível enviar uma notificação Web Push: {}", e.getMessage());
            }
        }
    }

    private WebPushVapidKey gerarParVapid() {
        try {
            KeyPairGenerator gerador = KeyPairGenerator.getInstance("EC", BouncyCastleProvider.PROVIDER_NAME);
            gerador.initialize(new ECGenParameterSpec("secp256r1"), new SecureRandom());
            KeyPair par = gerador.generateKeyPair();
            String chavePublica = Base64.getUrlEncoder().withoutPadding()
                    .encodeToString(nl.martijndwars.webpush.Utils.encode((ECPublicKey) par.getPublic()));
            byte[] privada = BigIntegers.asUnsignedByteArray(32, ((ECPrivateKey) par.getPrivate()).getD());
            String chavePrivada = Base64.getUrlEncoder().withoutPadding().encodeToString(privada);
            return new WebPushVapidKey(VAPID_KEY_ID, chavePublica, chavePrivada);
        } catch (Exception e) {
            throw new IllegalStateException("Não foi possível criar as chaves permanentes de Web Push.", e);
        }
    }

    private static void validarEndpoint(String endpoint) {
        if (endpoint == null || endpoint.length() > 4096) {
            throw new IllegalArgumentException("Endpoint Web Push inválido.");
        }
        try {
            URI uri = URI.create(endpoint);
            String host = uri.getHost() == null ? "" : uri.getHost().toLowerCase(java.util.Locale.ROOT);
            boolean hostConfiavel = host.equals("fcm.googleapis.com")
                    || host.equals("push.services.mozilla.com")
                    || host.endsWith(".push.services.mozilla.com")
                    || host.equals("web.push.apple.com")
                    || host.equals("notify.windows.com")
                    || host.endsWith(".notify.windows.com");
            if (!"https".equalsIgnoreCase(uri.getScheme()) || !hostConfiavel) {
                throw new IllegalArgumentException("O endpoint Web Push deve usar HTTPS.");
            }
        } catch (IllegalArgumentException e) {
            throw new IllegalArgumentException("Endpoint Web Push inválido.");
        }
    }

    private static void validarChaves(String p256dh, String auth) {
        try {
            byte[] chavePublica = Base64.getUrlDecoder().decode(p256dh);
            byte[] segredoAuth = Base64.getUrlDecoder().decode(auth);
            if (chavePublica.length != 65 || chavePublica[0] != 0x04 || segredoAuth.length != 16) {
                throw new IllegalArgumentException("Chaves da inscrição Web Push inválidas.");
            }
        } catch (IllegalArgumentException e) {
            throw new IllegalArgumentException("Chaves da inscrição Web Push inválidas.");
        }
    }

    private static String hashEndpoint(String endpoint) {
        try {
            byte[] digest = java.security.MessageDigest.getInstance("SHA-256")
                    .digest(endpoint.getBytes(StandardCharsets.UTF_8));
            return java.util.HexFormat.of().formatHex(digest);
        } catch (java.security.NoSuchAlgorithmException e) {
            throw new IllegalStateException("SHA-256 não está disponível.", e);
        }
    }
}
