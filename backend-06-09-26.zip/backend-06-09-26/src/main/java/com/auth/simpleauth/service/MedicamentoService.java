package com.auth.simpleauth.service;

import com.auth.simpleauth.dto.MedicamentoDto;
import com.auth.simpleauth.entity.Dose;
import com.auth.simpleauth.entity.Idoso;
import com.auth.simpleauth.entity.Medicamento;
import com.auth.simpleauth.repository.DoseRepository;
import com.auth.simpleauth.repository.IdosoRepository;
import com.auth.simpleauth.repository.MedicamentoRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

@Service
public class MedicamentoService {

    private final MedicamentoRepository medicamentoRepository;
    private final IdosoRepository idosoRepository;
    private final DoseRepository doseRepository;

    public MedicamentoService(MedicamentoRepository medicamentoRepository,
                              IdosoRepository idosoRepository,
                              DoseRepository doseRepository) {
        this.medicamentoRepository = medicamentoRepository;
        this.idosoRepository = idosoRepository;
        this.doseRepository = doseRepository;
    }

    @Transactional
    public Medicamento cadastrar(MedicamentoDto dto) {
        Idoso idoso = idosoRepository.findById(dto.getIdIdoso())
                .orElseThrow(() -> new RuntimeException("Idoso não encontrado com ID: " + dto.getIdIdoso()));

        // Passa o idoso.getFamiliar() no último argumento do construtor de Medicamento
        Medicamento medicamento = new Medicamento(
                dto.getNome(),
                dto.getDosagem(),
                dto.getUnidade(),
                dto.getQuantidadePorDose(),
                dto.getPrimeiroHorario(),
                dto.getIntervaloHoras(),
                idoso,
                idoso.getFamiliar()
        );

        Medicamento medicamentoSalvo = medicamentoRepository.save(medicamento);

        // Gera a primeira dose da agenda
        gerarPrimeiraDose(medicamentoSalvo);

        return medicamentoSalvo;
    }

    private void gerarPrimeiraDose(Medicamento medicamento) {
        Dose primeiraDose = new Dose(medicamento, medicamento.getPrimeiroHorario());
        doseRepository.save(primeiraDose);
    }

    public List<Medicamento> listar() {
        return medicamentoRepository.findAll();
    }

    public List<Medicamento> listarPorIdoso(Long idosoId) {
        return medicamentoRepository.findByIdosoIdAndAtivoTrue(idosoId);
    }

    public Optional<Medicamento> buscarPorId(Long id) {
        return medicamentoRepository.findById(id);
    }

    @Transactional
    public Medicamento atualizar(Long id, MedicamentoDto dto) {
        Medicamento medicamento = medicamentoRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Medicamento não encontrado com ID: " + id));

        medicamento.setNome(dto.getNome());
        medicamento.setDosagem(dto.getDosagem());
        medicamento.setUnidade(dto.getUnidade());
        medicamento.setQuantidadePorDose(dto.getQuantidadePorDose());
        medicamento.setPrimeiroHorario(dto.getPrimeiroHorario());
        medicamento.setIntervaloHoras(dto.getIntervaloHoras());

        if (dto.getIdIdoso() != null) {
            Idoso idoso = idosoRepository.findById(dto.getIdIdoso())
                    .orElseThrow(() -> new RuntimeException("Idoso não encontrado com ID: " + dto.getIdIdoso()));
            medicamento.setIdoso(idoso);
            medicamento.setFamiliar(idoso.getFamiliar());
        }

        return medicamentoRepository.save(medicamento);
    }

    @Transactional
    public void desativar(Long id) {
        Medicamento medicamento = medicamentoRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Medicamento não encontrado com ID: " + id));
        medicamento.setAtivo(false);
        medicamentoRepository.save(medicamento);
    }
}