package com.auth.simpleauth.service;

import com.auth.simpleauth.entity.Dose;
import com.auth.simpleauth.entity.Familiar;
import com.auth.simpleauth.entity.Medicamento;
import com.auth.simpleauth.enums.StatusDose;
import com.auth.simpleauth.repository.DoseRepository;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

@Service
public class AgendaSchedulerService {

    private final DoseRepository doseRepository;
    private final TelegramService telegramService;

    public AgendaSchedulerService(DoseRepository doseRepository, TelegramService telegramService) {
        this.doseRepository = doseRepository;
        this.telegramService = telegramService;
    }

    // Executa a cada 10 segundos para maior precisão no teste
    @Scheduled(fixedRate = 10000)
    @Transactional
    public void verificarDosesAgendadas() {
        LocalDateTime agora = LocalDateTime.now();

        List<Dose> dosesParaProcessar = doseRepository.findByStatusInAndHorarioProgramadoLessThanEqual(
                List.of(StatusDose.PENDENTE, StatusDose.NOTIFICADO),
                agora
        );

        for (Dose dose : dosesParaProcessar) {
            processarDose(dose, agora);
        }
    }

    private void processarDose(Dose dose, LocalDateTime agora) {
        Medicamento med = dose.getMedicamento();
        String nomeMedicamento = med.getNome();
        String nomeIdoso = med.getIdoso().getNome();
        String telegramIdIdoso = med.getIdoso().getTelegramChatId();

        // 1. PRIMEIRA NOTIFICAÇÃO (Com botão -> Próximo aviso em 2 minutos)
        if (dose.getStatus() == StatusDose.PENDENTE) {
            dose.setStatus(StatusDose.NOTIFICADO);
            dose.setQuantidadeNotificacoes(1);
            dose.setProximaNotificacao(agora.plusMinutes(2));
            doseRepository.save(dose);

            String quantidadeDose = (med.getQuantidadePorDose() % 1 == 0)
                    ? String.valueOf(med.getQuantidadePorDose().longValue())
                    : String.valueOf(med.getQuantidadePorDose());

            String horarioFormatado = dose.getHorarioProgramado().format(DateTimeFormatter.ofPattern("HH:mm"));

            String mensagem = String.format(
                    "⏰ <b>Lembrete de Medicamento</b>\n" +
                            "Olá, %s!\n" +
                            "Está na hora de tomar o seu remédio:\n" +
                            "💊 Medicamento: %s\n" +
                            "📏 Dose: %s %s\n" +
                            "🕒 Horário: %s\n\n" +
                            "Por favor, não se esqueça de confirmar a dose!",
                    nomeIdoso,
                    nomeMedicamento,
                    quantidadeDose,
                    med.getUnidade(),
                    horarioFormatado
            );

            telegramService.enviarNotificacaoComBotao(telegramIdIdoso, mensagem, dose.getId());
            return;
        }

        // 2. RE-NOTIFICAÇÃO (+2 min) OU ATRASO (+1 min extra)
        if (dose.getStatus() == StatusDose.NOTIFICADO && dose.getProximaNotificacao() != null) {
            if (agora.isAfter(dose.getProximaNotificacao())) {
                int tentativas = dose.getQuantidadeNotificacoes() + 1;
                dose.setQuantidadeNotificacoes(tentativas);

                if (tentativas == 2) {
                    // Passaram 2 minutos sem confirmar: Cobra novamente e aguarda mais 1 minuto
                    dose.setProximaNotificacao(agora.plusMinutes(1));
                    doseRepository.save(dose);

                    String msgReiteracao = String.format(
                            "⚠️ %s, você ainda não confirmou o remédio '<b>%s</b>'!\n" +
                                    "Por favor, clique no botão abaixo para confirmar.",
                            nomeIdoso, nomeMedicamento
                    );
                    telegramService.enviarNotificacaoComBotao(telegramIdIdoso, msgReiteracao, dose.getId());

                } else {
                    // Passou 1 minuto a mais (Total 3 minutos) sem confirmar: Marca ATRASADO e avisa Familiar
                    dose.setStatus(StatusDose.ATRASADO);
                    doseRepository.save(dose);

                    notificarFamiliarAtraso(dose);
                }
            }
        }
    }

    private void notificarFamiliarAtraso(Dose dose) {
        Familiar familiar = dose.getMedicamento().getIdoso().getFamiliar();
        if (familiar != null && familiar.getTelegramChatId() != null) {
            String msgFamiliar = String.format(
                    "🚨 ATENÇÃO: O idoso %s NÃO confirmou a dose do medicamento '%s' programada para as %s!",
                    dose.getMedicamento().getIdoso().getNome(),
                    dose.getMedicamento().getNome(),
                    dose.getHorarioProgramado().toLocalTime().format(DateTimeFormatter.ofPattern("HH:mm"))
            );
            telegramService.enviarNotificacao(familiar.getTelegramChatId(), msgFamiliar);
        }
    }
}