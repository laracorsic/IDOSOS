const API_AUTH_URL = 'http://localhost:8080/login';
const API_VINCULO_URL = 'http://localhost:8080/api/vinculos';
const DEFAULT_AVATAR = 'https://via.placeholder.com/150/cbd5e0/ffffff?text=User';

let usuarioLogado = null;

// Exibe mensagens de feedback na tela
function showMessage(text, isSuccess) {
  const msgDiv = document.getElementById('responseMessage');
  if (msgDiv) {
    msgDiv.textContent = text;
    msgDiv.className = `message ${isSuccess ? 'success' : 'error'}`;
    msgDiv.style.display = 'block';
  }
}

function hideMessage() {
  const msgDiv = document.getElementById('responseMessage');
  if (msgDiv) {
    msgDiv.style.display = 'none';
  }
}

// 1. CARREGA A SESSÃO DO USUÁRIO LOGADO E AJUSTA A INTERFACE
async function inicializarTela() {
  try {
    const response = await fetch(API_AUTH_URL, {
      method: 'GET',
      credentials: 'include'
    });

    if (!response.ok) {
      const statusContainer = document.getElementById('sessionStatus');
      if (statusContainer) {
        statusContainer.innerHTML = 
          '<p style="color:red;">Você precisa estar logado para acessar esta página. <a href="auth.html">Fazer Login</a></p>';
      }
      return;
    }

    // Tenta interpretar a resposta como JSON (LoginController atualizado)
    let isIdoso = false;
    let idUsuario = null;

    try {
      usuarioLogado = await response.json();
      idUsuario = usuarioLogado.id;
      isIdoso = usuarioLogado.perfil === 'IDOSO';

      const statusContainer = document.getElementById('sessionStatus');
      if (statusContainer) {
        statusContainer.innerHTML = `<strong>Sessão Ativa:</strong> ${usuarioLogado.nome} (${usuarioLogado.perfil})`;
      }
    } catch (e) {
      // Fallback caso a rota retorne texto puro
      const sessionText = await response.text();
      isIdoso = sessionText.includes('IDOSO');
      const matchId = sessionText.match(/(?:ID:\s*|id=)(\d+)/i);
      if (matchId && matchId[1]) {
        idUsuario = parseInt(matchId[1], 10);
      }
      usuarioLogado = { id: idUsuario, perfil: isIdoso ? 'IDOSO' : 'FAMILIAR' };

      const statusContainer = document.getElementById('sessionStatus');
      if (statusContainer) {
        statusContainer.innerHTML = `<strong>Sessão Ativa:</strong><br>${sessionText}`;
      }
    }

    // Oculta/Exibe painéis correspondentes
    const painelIdoso = document.getElementById('painelIdoso');
    const painelFamiliar = document.getElementById('painelFamiliar');

    if (isIdoso) {
      if (painelIdoso) painelIdoso.classList.remove('hidden');
      if (painelFamiliar) painelFamiliar.classList.add('hidden');
      carregarPedidosPendentes(idUsuario);
      carregarFamiliaresAceitos(idUsuario);
    } else {
      if (painelFamiliar) painelFamiliar.classList.remove('hidden');
      if (painelIdoso) painelIdoso.classList.add('hidden');
      carregarIdososAceitos(idUsuario);
    }

  } catch (error) {
    console.error('Erro na validação da sessão:', error);
    const statusContainer = document.getElementById('sessionStatus');
    if (statusContainer) {
      statusContainer.innerHTML = '<p style="color:red;">Você precisa estar logado para acessar esta página. <a href="auth.html">Fazer Login</a></p>';
    }
  }
}

// 2. FUNÇÕES DO IDOSO

// Lista as solicitações pendentes recebidas
async function carregarPedidosPendentes(idIdoso) {
  const id = idIdoso || (usuarioLogado ? usuarioLogado.id : null);
  const container = document.getElementById('listaPendentes');
  if (!container || !id) return;

  try {
    const response = await fetch(`${API_VINCULO_URL}/pedidos-pendentes/${id}`, {
      method: 'GET',
      credentials: 'include'
    });

    if (!response.ok) return;

    const pendentes = await response.json();
    container.innerHTML = '';

    if (!pendentes || pendentes.length === 0) {
      container.innerHTML = '<p class="empty-msg">Nenhuma solicitação de vínculo pendente.</p>';
      return;
    }

    pendentes.forEach(p => {
      const img = p.fotoUrl || p.imagemUrl || DEFAULT_AVATAR;
      container.innerHTML += `
        <div class="user-card">
          <img src="${img}" alt="Foto" class="avatar">
          <div class="user-info">
            <h4>${p.nomeFamiliar}</h4>
            <p>${p.emailFamiliar}</p>
            <div class="actions">
              <button class="btn-success" onclick="responderSolicitacao(${p.idVinculo}, true)">Aceitar</button>
              <button class="btn-danger" onclick="responderSolicitacao(${p.idVinculo}, false)">Recusar</button>
            </div>
          </div>
        </div>
      `;
    });
  } catch (error) {
    console.error('Erro ao carregar solicitações pendentes:', error);
  }
}

// Aceita ou recusa a solicitação de vínculo
async function responderSolicitacao(vinculoId, aceito) {
  hideMessage();
  try {
    const response = await fetch(`${API_VINCULO_URL}/responder/${vinculoId}?aceito=${aceito}`, {
      method: 'PUT',
      credentials: 'include'
    });

    const msg = await response.text();
    showMessage(msg, response.ok);

    if (response.ok && usuarioLogado) {
      carregarPedidosPendentes(usuarioLogado.id);
      carregarFamiliaresAceitos(usuarioLogado.id);
    }
  } catch (error) {
    showMessage('Erro ao responder à solicitação.', false);
  }
}

// Lista os familiares que já foram aceitos pelo idoso
async function carregarFamiliaresAceitos(idIdoso) {
  const id = idIdoso || (usuarioLogado ? usuarioLogado.id : null);
  const container = document.getElementById('listaFamiliaresAceitos');
  if (!container || !id) return;

  try {
    const response = await fetch(`${API_VINCULO_URL}/familiares-aceitos/${id}`, {
      method: 'GET',
      credentials: 'include'
    });

    if (!response.ok) return;

    const familiares = await response.json();
    renderizarUsuarios(familiares, container, 'Nenhum familiar vinculado ainda.');
  } catch (error) {
    console.error('Erro ao carregar familiares:', error);
  }
}

// 3. FUNÇÕES DO FAMILIAR

// Envia solicitação de vínculo para um idoso informando seu ID
document.getElementById('formSolicitarVinculo')?.addEventListener('submit', async (e) => {
  e.preventDefault();
  hideMessage();

  if (!usuarioLogado) {
    showMessage('Usuário não autenticado.', false);
    return;
  }

  const idFamiliar = usuarioLogado.id;
  const idIdoso = document.getElementById('inputIdosoId')?.value;

  if (!idIdoso) {
    showMessage('Informe o ID do idoso.', false);
    return;
  }

  try {
    const response = await fetch(`${API_VINCULO_URL}/solicitar?idFamiliar=${idFamiliar}&idIdoso=${idIdoso}`, {
      method: 'POST',
      credentials: 'include'
    });

    const msg = await response.text();
    showMessage(msg, response.ok);

    if (response.ok) {
      document.getElementById('formSolicitarVinculo').reset();
    }
  } catch (error) {
    showMessage('Erro ao solicitar vínculo.', false);
  }
});

// Lista os idosos que já aceitaram o vínculo com o familiar
async function carregarIdososAceitos(idFamiliar) {
  const id = idFamiliar || (usuarioLogado ? usuarioLogado.id : null);
  const container = document.getElementById('listaIdososAceitos');
  if (!container || !id) return;

  try {
    const response = await fetch(`${API_VINCULO_URL}/idosos-aceitos/${id}`, {
      method: 'GET',
      credentials: 'include'
    });

    if (!response.ok) return;

    const idosos = await response.json();
    renderizarUsuarios(idosos, container, 'Nenhum idoso vinculado até o momento.');
  } catch (error) {
    console.error('Erro ao carregar idosos:', error);
  }
}

// 4. FUNÇÃO AUXILIAR DE RENDERIZAÇÃO
function renderizarUsuarios(lista, container, mensagemVazia) {
  if (!container) return;
  container.innerHTML = '';

  if (!lista || lista.length === 0) {
    container.innerHTML = `<p class="empty-msg">${mensagemVazia}</p>`;
    return;
  }

  lista.forEach(user => {
    const img = user.imagemUrl || user.fotoUrl || DEFAULT_AVATAR;
    container.innerHTML += `
      <div class="user-card">
        <img src="${img}" alt="Foto" class="avatar">
        <div class="user-info">
          <h4>${user.nome}</h4>
          <p>${user.email}</p>
        </div>
      </div>
    `;
  });
}

// Inicializa a verificação assim que carrega o script
inicializarTela();