const API_BASE_URL = 'http://localhost:8080';

// Executado ao carregar a página
document.addEventListener('DOMContentLoaded', () => {
  sincronizarParametrosUrl();
  carregarDadosUsuario();
  carregarFamiliares();
});

// Captura e armazena os parâmetros ?id=X&tipo=IDOSO vindos da URL do Telegram
function sincronizarParametrosUrl() {
  const urlParams = new URLSearchParams(window.location.search);
  const idUrl = urlParams.get('id');
  const tipoUrl = urlParams.get('tipo');

  if (idUrl) localStorage.setItem('userId', idUrl);
  if (tipoUrl) localStorage.setItem('userTipo', tipoUrl.toUpperCase());
}

// Busca os dados da sessão do idoso sem forçar o logout em falha de cookie no redirecionamento do Telegram
async function carregarDadosUsuario() {
  const userNameElem = document.getElementById('userName');
  const userId = localStorage.getItem('userId');

  try {
    const response = await fetch(`${API_BASE_URL}/login`, {
      method: 'GET',
      credentials: 'include'
    });

    if (response.ok) {
      const dataText = await response.text();
      userNameElem.textContent = dataText || 'Idoso';
    } else if (userId) {
      // Se tivermos o userId gravado (vindo do Telegram), mantemos o acesso do idoso
      userNameElem.textContent = 'Idoso';
    } else {
      // Somente se NÃO houver nem cookie nem userId armazenado redirecionamos para login
      window.location.href = 'auth.html';
    }
  } catch (error) {
    console.error('Erro ao verificar sessão do servidor:', error);
    if (userId) {
      userNameElem.textContent = 'Idoso';
    } else {
      window.location.href = 'auth.html';
    }
  }
}

// Busca a lista de familiares vinculados a este idoso
async function carregarFamiliares() {
  const familyListContainer = document.getElementById('familyList');
  const userId = localStorage.getItem('userId');

  if (!userId) {
    familyListContainer.innerHTML = '<p class="no-family-msg">Nenhum familiar vinculado no momento.</p>';
    return;
  }

  try {
    const response = await fetch(`${API_BASE_URL}/idosos/${userId}/familiares`, {
      method: 'GET',
      credentials: 'include'
    });

    if (response.ok) {
      const familiares = await response.json();

      if (!familiares || familiares.length === 0) {
        familyListContainer.innerHTML = '<p class="no-family-msg">Nenhum familiar vinculado no momento.</p>';
        return;
      }

      familyListContainer.innerHTML = '';
      familiares.forEach(fam => {
        const card = document.createElement('div');
        card.className = 'family-card';
        card.innerHTML = `
          <span>👤 ${fam.nome}</span>
          ${fam.telefone ? `<span class="phone">📞 ${fam.telefone}</span>` : ''}
        `;
        familyListContainer.appendChild(card);
      });
    } else {
      familyListContainer.innerHTML = '<p class="no-family-msg">Nenhum familiar vinculado no momento.</p>';
    }
  } catch (error) {
    console.error('Erro ao buscar familiares:', error);
    familyListContainer.innerHTML = '<p class="no-family-msg">Não foi possível carregar a lista de familiares.</p>';
  }
}

// Navegação entre as páginas
function navigate(url) {
  window.location.href = url;
}

// Encerrar sessão
async function logout() {
  try {
    await fetch(`${API_BASE_URL}/login/logout`, {
      method: 'POST',
      credentials: 'include'
    });
  } catch (error) {
    console.error('Erro ao chamar logout no servidor:', error);
  } finally {
    localStorage.clear();
    window.location.href = 'auth.html';
  }
}