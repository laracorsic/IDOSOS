const API_BASE_URL = 'http://localhost:8080';
let idosoSelecionadoId = null;

document.addEventListener('DOMContentLoaded', () => {
  sincronizarParametrosUrl();
  carregarDadosUsuario();
  carregarIdososVinculados();
});

// Captura e armazena os parâmetros ?id=X&tipo=FAMILIAR vindos da URL do Telegram
function sincronizarParametrosUrl() {
  const urlParams = new URLSearchParams(window.location.search);
  const idUrl = urlParams.get('id');
  const tipoUrl = urlParams.get('tipo');

  if (idUrl) localStorage.setItem('userId', idUrl);
  if (tipoUrl) localStorage.setItem('userTipo', tipoUrl.toUpperCase());
}

// Busca dados da sessão do familiar sem expulsa-lo se o cookie falhar na navegação do Telegram
async function carregarDadosUsuario() {
  const userNameElem = document.getElementById('userName');
  const userId = localStorage.getItem('userId');

  try {
    const response = await fetch(`${API_BASE_URL}/login`, {
      method: 'GET',
      credentials: 'include'
    });

    if (response.ok) {
      const dataText = await response.text();
      userNameElem.textContent = dataText || 'Familiar';
    } else if (userId) {
      // Preserva a navegação do familiar caso a chamada GET de cookie falhe no redirecionamento externo
      userNameElem.textContent = 'Familiar';
    } else {
      window.location.href = 'auth.html';
    }
  } catch (error) {
    console.error('Erro ao verificar sessão:', error);
    if (userId) {
      userNameElem.textContent = 'Familiar';
    } else {
      window.location.href = 'auth.html';
    }
  }
}

// Busca os idosos que estão vinculados a este familiar
async function carregarIdososVinculados() {
  const idososListContainer = document.getElementById('idososList');
  const userId = localStorage.getItem('userId');

  if (!userId) {
    idososListContainer.innerHTML = '<p class="loading-text">Nenhum idoso vinculado no momento.</p>';
    return;
  }

  try {
    const response = await fetch(`${API_BASE_URL}/vinculos/familiar/${userId}/idosos`, {
      method: 'GET',
      credentials: 'include'
    });

    if (response.ok) {
      const idosos = await response.json();

      if (!idosos || idosos.length === 0) {
        idososListContainer.innerHTML = `
          <p class="loading-text">
            Você ainda não possui idosos vinculados.<br>
            Clique em <strong>"+ Solicitar Novo Vínculo"</strong> para começar.
          </p>`;
        document.getElementById('selectedIdosoName').textContent = 'Nenhum idoso selecionado';
        return;
      }

      idososListContainer.innerHTML = '';
      
      idosos.forEach((idoso, index) => {
        const card = document.createElement('div');
        card.className = `idoso-card ${index === 0 ? 'active' : ''}`;
        card.onclick = () => selecionarIdoso(idoso, card);

        card.innerHTML = `
          <div class="idoso-card-header">
            <h4 class="idoso-name">${idoso.nome || 'Idoso #' + idoso.id}</h4>
            <span class="idoso-status">Ativo</span>
          </div>
          <div class="idoso-info">
            <p>ID: ${idoso.id}</p>
            ${idoso.telefone ? `<p>📞 ${idoso.telefone}</p>` : ''}
          </div>
        `;

        idososListContainer.appendChild(card);
      });

      // Seleciona o primeiro idoso da lista por padrão
      selecionarIdoso(idosos[0]);

    } else {
      idososListContainer.innerHTML = '<p class="loading-text">Nenhum idoso vinculado no momento.</p>';
    }
  } catch (error) {
    console.error('Erro ao buscar idosos vinculados:', error);
    idososListContainer.innerHTML = '<p class="loading-text">Erro ao carregar idosos vinculados.</p>';
  }
}

// Seleciona um idoso para direcionar as operações do painel
function selecionarIdoso(idoso, cardElement = null) {
  idosoSelecionadoId = idoso.id;
  localStorage.setItem('selectedIdosoId', idoso.id);
  
  document.getElementById('selectedIdosoName').textContent = `${idoso.nome || 'Idoso #' + idoso.id} (ID: ${idoso.id})`;

  // Atualiza destaque visual dos cards
  if (cardElement) {
    document.querySelectorAll('.idoso-card').forEach(c => c.classList.remove('active'));
    cardElement.classList.add('active');
  }
}

// Navegação enviando contexto do idoso selecionado via parâmetro/localStorage
function navigate(url) {
  if (idosoSelecionadoId) {
    window.location.href = `${url}?idosoId=${idosoSelecionadoId}`;
  } else {
    window.location.href = url;
  }
}

// Encerrar sessão
async function logout() {
  try {
    await fetch(`${API_BASE_URL}/login/logout`, {
      method: 'POST',
      credentials: 'include'
    });
  } catch (error) {
    console.error('Erro ao realizar logout:', error);
  } finally {
    localStorage.clear();
    window.location.href = 'auth.html';
  }
}