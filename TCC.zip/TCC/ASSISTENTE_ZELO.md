# Assistente de voz Zelo

O projeto agora inclui um assistente de voz acessível para as páginas da interface do idoso. O assistente aparece como **Falar com Zelo** no canto inferior da tela e pode ser acionado pelo microfone, pelo teclado ou pelos botões de ajuda existentes.

## O que foi integrado

O núcleo do Zelo utiliza um agente conversacional com interpretação livre. Em vez de depender de uma lista fixa de frases, a IA recebe a conversa e decide a intenção, faz perguntas de esclarecimento e escolhe quando usar uma ferramenta disponível. Atualmente existe a ferramenta `consultar_clima`, que a IA pode acionar para perguntas sobre tempo, chuva e temperatura, mesmo quando a pessoa usa uma formulação diferente da prevista pelo programador.

O navegador faz o reconhecimento de voz em português do Brasil com a Web Speech API, transforma a fala em texto, lê as respostas em voz alta e executa comandos de navegação entre as áreas de início, remédios, família e amigos, médico online e jogos. Também existem respostas locais para hora, data, ajuda contextual, conversa e encaminhamento para o botão vermelho de socorro.

A interface usa fonte ampliada, alto contraste, foco visível, botões grandes, suporte a teclado, opção para ligar ou desligar a voz e uma alternativa de digitação para navegadores que não oferecem reconhecimento de fala.

## Agente multi-IA e revisão automática

O Zelo agora usa uma IA coordenadora com interpretação livre. Ela recebe a conversa, entende a intenção sem exigir frases cadastradas e pode chamar ferramentas, como a consulta meteorológica. Depois de produzir a resposta, uma segunda chamada automática revisa clareza, segurança e contradições, preservando fatos e números. Por padrão, a revisão usa o mesmo provedor configurado e não exige uma segunda chave.

O fluxo pode ser desativado quando necessário com:

```bash
export ASSISTENTE_IA_REVISOR_ATIVO=false
```

Esse modo não elimina a necessidade de configurar um provedor de IA. O que ele elimina é a necessidade de programar previamente todas as perguntas e respostas possíveis. O backend precisa de uma única configuração de endpoint, chave e modelo para que a IA possa raciocinar; dados atuais, como clima, continuam vindo de uma fonte externa confiável.

## Ativar conversa livre com IA e ferramentas

A chave nunca deve ser colocada no JavaScript ou em qualquer arquivo dentro de `static`. O backend lê as variáveis de ambiente abaixo:

```bash
export ASSISTENTE_IA_URL="https://api.openai.com/v1/chat/completions"
export ASSISTENTE_IA_CHAVE="sua-chave-do-provedor"
export ASSISTENTE_IA_MODELO="gpt-5-mini"
./mvnw spring-boot:run
```

O endpoint configurado deve aceitar o formato de Chat Completions compatível com OpenAI e oferecer suporte a `tools`/function calling. Para outro provedor, informe uma URL compatível e o modelo correspondente. A rota pública do backend é `POST /assistente/conversar`; ela recebe a mensagem, o título da página, um resumo do conteúdo visível e as últimas mensagens da conversa. O backend faz a primeira chamada, executa a ferramenta escolhida pela IA e faz uma segunda chamada para produzir a resposta final.

Não é possível obter conversa inteligente e previsão atualizada sem nenhuma fonte de dados ou configuração: o raciocínio vem do modelo de IA e o clima vem de uma API meteorológica. O objetivo desta arquitetura é eliminar a necessidade de programar cada pergunta ou resposta; basta configurar uma única vez o provedor de IA e, no futuro, cadastrar novas ferramentas, não frases.

## Teste rápido

1. Inicie o backend com `./mvnw spring-boot:run`.
2. Abra `http://localhost:8080/` em um navegador com conexão segura ou em `localhost`.
3. Entre na área do idoso.
4. Toque em **Falar com Zelo** e permita o microfone.
5. Diga, por exemplo, “abrir meus remédios”, “como uso esta página” ou “vamos conversar”.

Sem as variáveis de ambiente da IA, o assistente continua disponível no **modo acolhedor**, com navegação, ajuda contextual, hora, data, conversa inicial e mensagens de segurança.

## Cuidados de segurança

O assistente não substitui médico, cuidador ou serviço de emergência. Ele não deve inventar informações sobre remédios, horários ou contatos. Em uma situação de risco, a pessoa deve usar o botão vermelho de socorro e procurar ajuda humana imediatamente.

O projeto original mantém as configurações de banco de dados existentes. O teste de contexto depende de um MySQL disponível com as credenciais configuradas em `application.properties`; a compilação do projeto foi validada separadamente com `./mvnw -q -DskipTests package`.
