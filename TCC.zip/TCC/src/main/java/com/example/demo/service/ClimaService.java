package com.example.demo.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClient;
import org.springframework.web.util.UriComponentsBuilder;

import java.util.Locale;

@Service
public class ClimaService {
    private final ObjectMapper mapper = new ObjectMapper();
    private final RestClient client = RestClient.builder().build();

    public String previsao(String entrada) {
        String cidade = entrada == null ? "" : entrada.trim().replaceAll("\\s*[-–—]\\s*", ", ")
                .replaceAll("(?i)^(no|na|estado)\\s+estado\\s+de\\s+", "").trim();
        String normalizada = java.text.Normalizer.normalize(cidade.toLowerCase(Locale.ROOT), java.text.Normalizer.Form.NFD).replaceAll("\\p{M}", "");
        if (cidade.isBlank() || normalizada.equals("brasil") || normalizada.matches("(sao paulo|rio de janeiro|minas gerais|bahia|parana|santa catarina|goias|pernambuco|ceara|para|amazonas|maranhao|piaui|acre|alagoas|amapa|espirito santo|mato grosso|mato grosso do sul|paraiba|rio grande do norte|rio grande do sul|rondonia|roraima|sergipe|tocantins)")) {
            return "Para consultar o tempo, diga uma cidade, de preferência com estado. Exemplo: previsão em São Carlos, SP.";
        }
        try {
            String geoUrl = UriComponentsBuilder.fromUriString("https://geocoding-api.open-meteo.com/v1/search")
                    .queryParam("name", cidade).queryParam("count", 10).queryParam("language", "pt")
                    .queryParam("countryCode", "BR").queryParam("format", "json").build().encode().toUriString();
            JsonNode results = mapper.readTree(client.get().uri(geoUrl).retrieve().body(String.class)).path("results");
            if (!results.isArray() || results.isEmpty()) return "Não encontrei essa cidade. Diga o nome e o estado, por exemplo: São Carlos, SP.";
            JsonNode local = results.get(0);
            for (JsonNode item : results) if (!"PCLI".equalsIgnoreCase(item.path("feature_code").asText())) { local = item; break; }
            String weatherUrl = UriComponentsBuilder.fromUriString("https://api.open-meteo.com/v1/forecast")
                    .queryParam("latitude", local.path("latitude").asDouble()).queryParam("longitude", local.path("longitude").asDouble())
                    .queryParam("current", "temperature_2m,apparent_temperature,weather_code,wind_speed_10m")
                    .queryParam("daily", "precipitation_probability_max,temperature_2m_max,temperature_2m_min")
                    .queryParam("timezone", local.path("timezone").asText("auto")).queryParam("forecast_days", 1).build().encode().toUriString();
            JsonNode weather = mapper.readTree(client.get().uri(weatherUrl).retrieve().body(String.class));
            JsonNode current = weather.path("current");
            int chance = weather.path("daily").path("precipitation_probability_max").path(0).asInt(-1);
            String resposta = "Em " + local.path("name").asText(cidade) + ", " + descricao(current.path("weather_code").asInt(-1)) + ", com "
                    + numero(current.path("temperature_2m").asDouble()) + " °C e sensação de " + numero(current.path("apparent_temperature").asDouble()) + " °C.";
            if (chance >= 0) resposta += " A chance máxima de chuva hoje é de " + chance + "%.";
            return resposta + " Consulte novamente antes de sair, pois a previsão pode mudar.";
        } catch (Exception ex) {
            return "Não consegui consultar a previsão agora. Verifique a conexão e tente novamente.";
        }
    }
    private String numero(double n) { return String.format(new Locale("pt", "BR"), "%.1f", n); }
    private String descricao(int codigo) { return switch (codigo) { case 0 -> "o céu está limpo"; case 1, 2 -> "o tempo está parcialmente nublado"; case 3 -> "o céu está nublado"; case 45, 48 -> "há neblina"; case 51, 53, 55, 56, 57 -> "há garoa"; case 61, 63, 65, 80, 81, 82 -> "há chuva"; case 95, 96, 99 -> "há possibilidade de trovoada"; default -> "a condição do tempo não foi informada"; }; }
}
