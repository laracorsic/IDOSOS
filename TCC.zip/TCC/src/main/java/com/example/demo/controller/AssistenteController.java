package com.example.demo.controller;

import com.example.demo.service.ClimaService;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestClient;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * Assistente "Zelo" com IA real (Groq, via endpoint compatível com OpenAI),
 * sem respostas programadas manualmente. O modelo interpreta a intenção da pessoa
 * livremente e decide sozinho quando usar a ferramenta de clima (function calling).
 * O respostaLocal() só existe como contingência para quando não há internet/chave configurada.
 */
@RestController
@RequestMapping("/assistente")
@CrossOrigin(origins = "*")
public class AssistenteController {

    private static final String SYSTEM_PROMPT = """
            Você é Zelo, um companheiro inteligente para pessoas idosas, falando português do Brasil.
            Interprete a intenção da pessoa mesmo que ela use abreviações, erros de digitação, frases curtas,
            linguagem informal ou não formule uma pergunta completa. Não dependa de palavras-chave exatas.
            Converse com naturalidade, acolhimento, paciência e respeito, sem infantilizar.
            Faça perguntas de esclarecimento quando faltar uma informação necessária.
            Você tem ferramentas: use a ferramenta de clima quando a pessoa perguntar sobre tempo, temperatura,
            chuva, previsão ou condições para sair; não tente adivinhar a previsão. Para navegação, diga claramente
            qual área deve ser aberta, mas não invente que executou uma ação que o navegador não confirmou.
            Para remédios e saúde, dê somente orientação geral, nunca diagnostique, prescreva ou altere doses.
            Em emergência, oriente ajuda humana imediata e o botão de socorro. Não peça senhas, códigos,
            dados bancários ou informações pessoais desnecessárias. Responda em até três parágrafos curtos.
            """;

    private final ObjectMapper objectMapper = new ObjectMapper();
    private final RestClient restClient = RestClient.builder().build();
    private final ClimaService climaService;

    @Value("${assistente.ia.url:https://api.groq.com/openai/v1/chat/completions}") private String iaUrl;
    @Value("${assistente.ia.chave:}") private String iaChave;
    @Value("${assistente.ia.modelo:openai/gpt-oss-120b}") private String iaModelo;
    @Value("${assistente.ia.revisor.ativo:true}") private boolean revisorAtivo;

    public AssistenteController(ClimaService climaService) { this.climaService = climaService; }

    public record HistoricoMensagem(String role, String content) {}
    public record ConversaRequest(String message, String pageTitle, String pageContext, List<HistoricoMensagem> history) {}

    @GetMapping("/status")
    public ResponseEntity<Map<String, Object>> status() {
        return ResponseEntity.ok(Map.of(
                "configurada", iaConfigurada(),
                "agenteComFerramentas", iaConfigurada(),
                "climaDisponivel", true,
                "modelo", iaModelo,
                "mensagem", iaConfigurada() ? "Zelo está pronto para interpretar pedidos livres." : "Zelo está no modo local; configure a chave da Groq para conversa aberta."
        ));
    }

    @PostMapping(value = "/conversar", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Map<String, Object>> conversar(@RequestBody ConversaRequest request) {
        String pergunta = textoSeguro(request == null ? null : request.message());
        if (pergunta.isBlank()) return ResponseEntity.badRequest().body(Map.of("reply", "Pode falar comigo. Estou ouvindo você.", "source", "validacao"));
        if (!iaConfigurada()) return ResponseEntity.ok(respostaLocal(pergunta));

        try {
            List<Map<String, Object>> mensagens = new ArrayList<>();
            mensagens.add(mensagem("system", SYSTEM_PROMPT));
            if (request.history() != null) {
                request.history().stream().filter(item -> item != null && item.content() != null)
                        .skip(Math.max(0, request.history().size() - 12L)).limit(12)
                        .forEach(item -> mensagens.add(mensagem(
                                "assistant".equalsIgnoreCase(item.role()) ? "assistant" : "user",
                                limitar(textoSeguro(item.content()), 1400))));
            }
            mensagens.add(mensagem("system", "Página atual: " + limitar(textoSeguro(request.pageTitle()), 160)
                    + "\nConteúdo visível: " + limitar(textoSeguro(request.pageContext()), 3500)));
            mensagens.add(mensagem("user", pergunta));

            String resposta = executarAgente(mensagens);
            if (resposta.isBlank()) resposta = "Não consegui formular uma resposta agora. Pode explicar de outro jeito?";
            return ResponseEntity.ok(Map.of("reply", resposta, "source", "ia-agente", "model", iaModelo, "available", true));
        } catch (Exception ex) {
            return ResponseEntity.ok(Map.of("reply", "Tive uma dificuldade momentânea para pensar na resposta. Ainda estou aqui com você; tente novamente em alguns instantes.", "source", "contingencia", "available", true));
        }
    }

    private String executarAgente(List<Map<String, Object>> mensagens) throws Exception {
        JsonNode respostaInicial = objectMapper.readTree(chamarIA(payload(mensagens)));
        JsonNode escolha = respostaInicial.path("choices").path(0).path("message");
        JsonNode chamadas = escolha.path("tool_calls");
        if (!chamadas.isArray() || chamadas.isEmpty()) return revisarResposta(textoDaMensagem(escolha), mensagens);

        mensagens.add(mensagemComChamadas(escolha));
        for (JsonNode chamada : chamadas) {
            String nome = chamada.path("function").path("name").asText();
            String argumentos = chamada.path("function").path("arguments").asText("{}");
            String resultado = executarFerramenta(nome, objectMapper.readTree(argumentos));
            Map<String, Object> ferramenta = new HashMap<>();
            ferramenta.put("role", "tool");
            ferramenta.put("tool_call_id", chamada.path("id").asText());
            ferramenta.put("content", resultado);
            mensagens.add(ferramenta);
        }
        JsonNode respostaFinal = objectMapper.readTree(chamarIA(payload(mensagens)));
        String rascunho = textoDaMensagem(respostaFinal.path("choices").path(0).path("message"));
        return revisarResposta(rascunho, mensagens);
    }

    private String revisarResposta(String rascunho, List<Map<String, Object>> mensagens) throws Exception {
        if (!revisorAtivo || rascunho.isBlank()) return rascunho;
        String pergunta = "";
        for (int i = mensagens.size() - 1; i >= 0; i--) {
            if ("user".equals(mensagens.get(i).get("role"))) {
                pergunta = String.valueOf(mensagens.get(i).get("content"));
                break;
            }
        }
        List<Map<String, Object>> revisao = new ArrayList<>();
        revisao.add(mensagem("system", "Você é o revisor final do Zelo. Preserve todos os fatos e números do rascunho. Corrija apenas erros, contradições, excesso de texto ou linguagem difícil. Não invente informações. Retorne somente a resposta final em português do Brasil, com no máximo três parágrafos curtos."));
        revisao.add(mensagem("user", "Pergunta original: " + limitar(pergunta, 1200) + "\n\nRascunho para revisar:\n" + limitar(rascunho, 2400)));
        Map<String, Object> pedido = new HashMap<>();
        pedido.put("model", iaModelo);
        pedido.put("messages", revisao);
        pedido.put("temperature", 0.2);
        pedido.put("max_tokens", 500);
        String corpo = chamarIA(pedido);
        String finalizado = textoDaMensagem(objectMapper.readTree(corpo).path("choices").path(0).path("message"));
        return finalizado.isBlank() ? rascunho : finalizado;
    }

    private String chamarIA(Map<String, Object> payload) {
        return restClient.post().uri(iaUrl)
                .contentType(MediaType.APPLICATION_JSON)
                .header("Authorization", "Bearer " + iaChave)
                .body(payload)
                .retrieve().body(String.class);
    }

    private Map<String, Object> payload(List<Map<String, Object>> mensagens) {
        Map<String, Object> payload = new HashMap<>();
        payload.put("model", iaModelo);
        payload.put("messages", mensagens);
        payload.put("tools", ferramentas());
        payload.put("tool_choice", "auto");
        payload.put("temperature", 0.5);
        payload.put("max_tokens", 600);
        return payload;
    }

    private List<Map<String, Object>> ferramentas() {
        Map<String, Object> funcao = new HashMap<>();
        funcao.put("name", "consultar_clima");
        funcao.put("description", "Consulta as condições meteorológicas atuais e a previsão para uma cidade. Use quando o usuário perguntar sobre clima, tempo, temperatura, chuva ou se deve sair.");
        funcao.put("parameters", Map.of("type", "object", "properties", Map.of("cidade", Map.of("type", "string", "description", "Nome da cidade, preferencialmente com estado e país")), "required", List.of("cidade"), "additionalProperties", false));
        return List.of(Map.of("type", "function", "function", funcao));
    }

    private String executarFerramenta(String nome, JsonNode argumentos) {
        if ("consultar_clima".equals(nome)) return climaService.previsao(argumentos.path("cidade").asText(""));
        return "Ferramenta não disponível. Responda sem inventar dados.";
    }

    private Map<String, Object> mensagem(String role, String content) {
        return Map.of("role", role, "content", content);
    }

    private Map<String, Object> mensagemComChamadas(JsonNode message) {
        Map<String, Object> resultado = new HashMap<>();
        resultado.put("role", "assistant");
        resultado.put("content", message.path("content").isNull() ? "" : message.path("content").asText(""));
        resultado.put("tool_calls", objectMapper.convertValue(message.path("tool_calls"), Object.class));
        return resultado;
    }

    private String textoDaMensagem(JsonNode message) {
        JsonNode content = message.path("content");
        return content.isTextual() ? content.asText().trim() : "";
    }

    private Map<String, Object> respostaLocal(String pergunta) {
        String texto = normalizar(pergunta);
        String resposta;
        if (texto.contains("socorro") || texto.contains("emergencia") || texto.contains("perigo")) resposta = "Se você está em perigo ou passou mal, procure ajuda humana imediatamente e use o botão vermelho de socorro.";
        else if (texto.contains("como voce esta") || texto.contains("como vc esta") || texto.contains("voce esta bem") || texto.contains("vc esta bem")) resposta = "Estou bem e contente por conversar com você. Obrigado por perguntar. E você, como está se sentindo hoje?";
        else if (texto.contains("o que voce pode") || texto.contains("o que posso perguntar")) resposta = "Você pode conversar comigo, perguntar sobre o tempo, pedir ajuda com esta página, abrir remédios, família, médico e jogos, ou falar sobre como está se sentindo.";
        else if (texto.contains("previsao") || texto.contains("temperatura") || texto.contains("clima") || texto.contains("vai chover")) resposta = "Posso consultar o tempo. Diga a cidade, por exemplo: “previsão em São Carlos, SP”.";
        else if (texto.contains("hora")) resposta = "Agora são " + LocalDateTime.now().format(DateTimeFormatter.ofPattern("HH 'horas e' mm 'minutos'")) + ".";
        else if (texto.contains("data") || texto.contains("que dia")) resposta = "Hoje é " + LocalDateTime.now().format(DateTimeFormatter.ofPattern("EEEE, dd/MM/yyyy", new Locale("pt", "BR"))) + ".";
        else if (texto.contains("convers") || texto.contains("companhia") || texto.contains("papo")) resposta = "Estou aqui com você. Podemos conversar sobre seu dia, suas lembranças, sua família ou qualquer assunto que queira compartilhar.";
        else resposta = "Estou sem conexão com a IA no momento, então minhas respostas estão limitadas. Assim que a chave da Groq estiver configurada, posso conversar livremente sobre qualquer assunto.";
        return Map.of("reply", resposta, "source", "local", "available", true);
    }

    private String normalizar(String valor) { return java.text.Normalizer.normalize(textoSeguro(valor).toLowerCase(Locale.ROOT), java.text.Normalizer.Form.NFD).replaceAll("\\p{M}", ""); }
    private String textoSeguro(String valor) { return valor == null ? "" : valor.trim(); }
    private String limitar(String valor, int tamanho) { return valor.length() <= tamanho ? valor : valor.substring(0, tamanho); }
    private boolean iaConfigurada() { return iaUrl != null && !iaUrl.isBlank() && iaChave != null && !iaChave.isBlank(); }
}
