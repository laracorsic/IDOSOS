# Integração do Zelo com o frontend dos idosos

O frontend da pasta `Idosos` foi incorporado ao projeto Spring Boot. O assistente visual é carregado em todas as páginas HTML por meio de `assistente.css` e `assistente.js`.

A comunicação pode ocorrer de duas formas. No modo separado, recomendado para desenvolvimento, o frontend servido pelo VS Code chama o backend Spring Boot em `http://localhost:8080`. O backend já permite chamadas CORS e mantém a chave Groq somente no servidor.

A comunicação com o backend usa:

- `GET /assistente/status`: verifica se a IA está configurada.
- `POST /assistente/conversar`: envia a mensagem, o histórico recente e o conteúdo visível da página.

A chave da Groq permanece somente no backend, por meio da variável de ambiente `ASSISTENTE_IA_CHAVE`.

## Execução separada: backend no IntelliJ e frontend no VS Code

### Backend no IntelliJ

Abra a pasta que contém o `pom.xml` no IntelliJ, configure a variável `ASSISTENTE_IA_CHAVE` na configuração do Spring Boot e execute `com.example.demo.DemoApplication`. O backend deve ficar disponível em `http://localhost:8080`.

### Frontend no VS Code

Abra a pasta `Idosos` no VS Code. Instale a extensão **Live Server** ou use outro servidor estático. Não abra o HTML diretamente com `file://`, pois o navegador pode bloquear chamadas para a API. Clique com o botão direito em `paginainicial/paginainicial.html` e escolha **Open with Live Server**. O assistente já está configurado para chamar `http://localhost:8080`.

Os scripts que já usavam a API também apontam para essa porta: `entraridoso/idoso1.js`, `entrafamiliar/familiar1.js` e `vinculo/vinculo.js`.

### Verificação rápida

Com o backend executando, abra no navegador:

```text
http://localhost:8080/assistente/status
```

A resposta deve ser um JSON com o campo `configurada`. Depois abra a página pelo Live Server e clique em **Falar com Zelo**.

## Execução no IntelliJ

No campo **Environment variables** da configuração do Spring Boot, use o formato:

```text
ASSISTENTE_IA_CHAVE=sua_chave_groq
```

Não coloque somente o valor da chave: o nome da variável é obrigatório. Também é possível configurar opcionalmente:

```text
ASSISTENTE_IA_URL=https://api.groq.com/openai/v1/chat/completions;ASSISTENTE_IA_MODELO=openai/gpt-oss-120b
```

Depois, inicie a classe `com.example.demo.DemoApplication`. A página inicial pode ser acessada em `http://localhost:8080/`.

## Comportamento sem chave

Sem `ASSISTENTE_IA_CHAVE`, o sistema continua funcionando em modo local, com respostas básicas e navegação pelo site. Com a chave configurada, mensagens abertas são encaminhadas ao modelo Groq pelo endpoint Java.

## Validação realizada

O projeto foi compilado com JDK 21 e a suíte existente terminou com **BUILD SUCCESS**, com 1 teste executado, 0 falhas e 0 erros. Para reproduzir:

```bash
export JAVA_HOME=/usr/lib/jvm/java-21-openjdk-amd64
export PATH="$JAVA_HOME/bin:$PATH"
./mvnw clean test
```

Nunca publique a chave da Groq em HTML, JavaScript, Git ou capturas de tela. Se uma chave real foi exibida anteriormente, revogue-a e gere outra.
