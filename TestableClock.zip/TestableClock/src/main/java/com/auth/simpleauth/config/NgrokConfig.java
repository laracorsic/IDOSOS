package com.auth.simpleauth.config;

import com.github.alexdlaird.ngrok.NgrokClient;
import com.github.alexdlaird.ngrok.conf.JavaNgrokConfig;
import com.github.alexdlaird.ngrok.protocol.CreateTunnel;
import com.github.alexdlaird.ngrok.protocol.Tunnel;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

@Component
public class NgrokConfig implements CommandLineRunner {

    @Override
    public void run(String... args) {
        try {
            String authToken = "cr_3JKL7sPan627IPQb0FazmtCILwi";
            int portaFrontEnd = 5500; // Porta do seu Live Server

            final JavaNgrokConfig javaNgrokConfig = new JavaNgrokConfig.Builder()
                    .withAuthToken(authToken)
                    .build();

            final NgrokClient ngrokClient = new NgrokClient.Builder()
                    .withJavaNgrokConfig(javaNgrokConfig)
                    .build();

            final CreateTunnel createTunnel = new CreateTunnel.Builder()
                    .withAddr(portaFrontEnd)
                    .build();

            final Tunnel tunnel = ngrokClient.connect(createTunnel);

            // Injeta a nova URL do Ngrok diretamente nas propriedades de sistema do Spring
            System.setProperty("app.frontend.url", tunnel.getPublicUrl());

            System.out.println("\n--------------------------------------------------");
            System.out.println("✅ Ngrok conectado com sucesso!");
            System.out.println("🌐 URL pública dinâmica: " + tunnel.getPublicUrl());
            System.out.println("--------------------------------------------------\n");

        } catch (Exception e) {
            System.err.println("❌ Erro ao conectar o ngrok: " + e.getMessage());
        }
    }
}