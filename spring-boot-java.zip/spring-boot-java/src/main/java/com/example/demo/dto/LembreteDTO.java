package com.example.demo.dto;

import java.time.LocalDateTime;

public class LembreteDTO {
    private String descricao;
    private LocalDateTime data_hora;
    private Long idRemedio;

    public LembreteDTO(String descricao, LocalDateTime data_hora, Long idRemedio) {
        this.descricao = descricao;
        this.data_hora = data_hora;
        this.idRemedio = idRemedio;
    }

    public String getDescricao() { return descricao; }
    public LocalDateTime getData_hora() { return data_hora; }
    public Long getIdRemedio() { return idRemedio; }
}