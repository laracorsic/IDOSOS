package com.example.demo.service;

import com.example.demo.dto.RemedioDTO;
import com.example.demo.entity.Idoso;
import com.example.demo.entity.Remedio;
import com.example.demo.repository.IdosoRepository;
import com.example.demo.repository.RemedioRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class RemedioService {

    @Autowired
    private RemedioRepository remedioRepository;

    @Autowired
    private IdosoRepository idosoRepository;

    @Transactional
    public void cadastrar(RemedioDTO dto) {
        Idoso idoso = dto.getIdIdoso() != null ? idosoRepository.findById(dto.getIdIdoso()).orElse(null) : null;
        Remedio remedio = new Remedio(dto.getNome(), dto.getDosagem(), dto.getIntervalo(), dto.getHora(), idoso);
        remedioRepository.save(remedio);
    }

    public List<Remedio> listar() {
        return remedioRepository.findAll();
    }

    @Transactional
    public void atualizar(Long id, RemedioDTO dto) {
        Remedio remedio = remedioRepository.findById(id).orElse(null);
        if (remedio != null) {
            Idoso idoso = dto.getIdIdoso() != null ? idosoRepository.findById(dto.getIdIdoso()).orElse(null) : null;
            remedio.setNome(dto.getNome());
            remedio.setDosagem(dto.getDosagem());
            remedio.setIntervalo(dto.getIntervalo());
            remedio.setHora(dto.getHora());
            remedio.setIdoso(idoso);
        }
    }

    @Transactional
    public void remover(Long id) {
        if (remedioRepository.existsById(id)) {
            remedioRepository.deleteById(id);
        }
    }
}