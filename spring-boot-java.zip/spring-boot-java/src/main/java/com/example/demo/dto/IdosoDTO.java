package com.example.demo.dto;

public class IdosoDTO {
    private String nome;
    private int idade;
    private String telefone;
    private Long idFamiliar;
    private Long idCuidador;

    public IdosoDTO(String nome, int idade, String telefone, Long idFamiliar, Long idCuidador) {
        this.nome = nome;
        this.idade = idade;
        this.telefone = telefone;
        this.idFamiliar = idFamiliar;
        this.idCuidador = idCuidador;
    }

    public String getNome() {
        return nome;
    }

    public int getIdade() {
        return idade;
    }

    public String getTelefone() {
        return telefone;
    }

    public Long getIdFamiliar() {
        return idFamiliar;
    }

    public Long getIdCuidador() {
        return idCuidador;
    }
}