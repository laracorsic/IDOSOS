package com.example.demo.service;

import com.example.demo.dto.IdosoDTO;
import com.example.demo.entity.Cuidador;
import com.example.demo.entity.Familiar;
import com.example.demo.entity.Idoso;
import com.example.demo.repository.CuidadorRepository;
import com.example.demo.repository.FamiliarRepository;
import com.example.demo.repository.IdosoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class IdosoService {

    @Autowired
    private IdosoRepository idosoRepository;

    @Autowired
    private FamiliarRepository familiarRepository;

    @Autowired
    private CuidadorRepository cuidadorRepository;

    @Transactional
    public void cadastrar(IdosoDTO dto) {
        Familiar familiar = dto.getIdFamiliar() != null ? familiarRepository.findById(dto.getIdFamiliar()).orElse(null) : null;
        Cuidador cuidador = dto.getIdCuidador() != null ? cuidadorRepository.findById(dto.getIdCuidador()).orElse(null) : null;

        Idoso idoso = new Idoso(dto.getNome(), dto.getIdade(), dto.getTelefone(), familiar, cuidador);
        idosoRepository.save(idoso);
    }

    public List<Idoso> listar() {
        return idosoRepository.findAll();
    }

    @Transactional
    public void atualizar(Long id, IdosoDTO dto) {
        Idoso idosoEncontrado = idosoRepository.findById(id).orElse(null);
        if (idosoEncontrado != null) {
            Familiar familiar = dto.getIdFamiliar() != null ? familiarRepository.findById(dto.getIdFamiliar()).orElse(null) : null;
            Cuidador cuidador = dto.getIdCuidador() != null ? cuidadorRepository.findById(dto.getIdCuidador()).orElse(null) : null;

            idosoEncontrado.setNome(dto.getNome());
            idosoEncontrado.setIdade(dto.getIdade());
            idosoEncontrado.setTelefone(dto.getTelefone());
            idosoEncontrado.setFamiliar(familiar);
            idosoEncontrado.setCuidador(cuidador);
        }
    }

    @Transactional
    public void remover(Long id) {
        if (idosoRepository.existsById(id)) {
            idosoRepository.deleteById(id);
        }
    }
}