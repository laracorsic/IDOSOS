package com.example.demo.entity;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "lembrete")
public class Lembrete {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String descricao;
    private LocalDateTime data_hora = LocalDateTime.now();

    @ManyToOne
    @JoinColumn(name = "id_remedio")
    private Remedio remedio;

    protected Lembrete() {}


    public Lembrete(String descricao, LocalDateTime data_hora) {
        this.descricao = descricao;
        this.data_hora = data_hora;
    }


    public Lembrete(String descricao, LocalDateTime data_hora, Remedio remedio) {
        this.descricao = descricao;
        this.data_hora = data_hora;
        this.remedio = remedio;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public LocalDateTime getData_hora() {
        return data_hora;
    }

    public void setData_hora(LocalDateTime data_hora) {
        this.data_hora = data_hora;
    }

    public Remedio getRemedio() {
        return remedio;
    }

    public void setRemedio(Remedio remedio) {
        this.remedio = remedio;
    }
}