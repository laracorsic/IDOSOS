package com.example.demo.entity;

import jakarta.persistence.*;
import com.fasterxml.jackson.annotation.JsonIgnore;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "idoso")
public class Idoso {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String nome;
    private int idade;
    private String telefone;

    @ManyToOne
    @JoinColumn(name = "id_familiar", nullable = true)
    private Familiar familiar;

    @ManyToOne
    @JoinColumn(name = "id_cuidador", nullable = true)
    private Cuidador cuidador;

    @JsonIgnore
    @OneToMany(mappedBy = "idoso", cascade = CascadeType.ALL)
    private List<Remedio> remedios = new ArrayList<>();

    protected Idoso() {}


    public Idoso(String nome, int idade, String telefone) {
        this.nome = nome;
        this.idade = idade;
        this.telefone = telefone;
    }


    public Idoso(String nome, int idade, String telefone, Familiar familiar, Cuidador cuidador) {
        this.nome = nome;
        this.idade = idade;
        this.telefone = telefone;
        this.familiar = familiar;
        this.cuidador = cuidador;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public int getIdade() {
        return idade;
    }

    public void setIdade(int idade) {
        this.idade = idade;
    }

    public String getTelefone() {
        return telefone;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }

    public Familiar getFamiliar() {
        return familiar;
    }

    public void setFamiliar(Familiar familiar) {
        this.familiar = familiar;
    }

    public Cuidador getCuidador() {
        return cuidador;
    }

    public void setCuidador(Cuidador cuidador) {
        this.cuidador = cuidador;
    }

    public List<Remedio> getRemedios() {
        return remedios;
    }

    public void setRemedios(List<Remedio> remedios) {
        this.remedios = remedios;
    }
}