package com.example.demo.dto;

public class FamiliarDTO {
    private String nome;
    private int idade;
    private String telefone;

    public FamiliarDTO(String nome, int idade, String telefone) {
        this.nome = nome;
        this.idade = idade;
        this.telefone = telefone;
    }

    public String getNome() {
        return nome;
    }

    public int getIdade() {
        return idade;
    }

    public String getTelefone() {
        return telefone;
    }
}