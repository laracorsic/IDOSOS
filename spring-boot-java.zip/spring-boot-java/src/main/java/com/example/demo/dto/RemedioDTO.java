package com.example.demo.dto;

import java.time.LocalTime;

public class RemedioDTO {
    private String nome;
    private float dosagem;
    private float intervalo;
    private LocalTime hora;
    private Long idIdoso;

    public RemedioDTO(String nome, float dosagem, float intervalo, LocalTime hora, Long idIdoso) {
        this.nome = nome;
        this.dosagem = dosagem;
        this.intervalo = intervalo;
        this.hora = hora;
        this.idIdoso = idIdoso;
    }

    public String getNome() { return nome; }
    public float getDosagem() { return dosagem; }
    public float getIntervalo() { return intervalo; }
    public LocalTime getHora() { return hora; }
    public Long getIdIdoso() { return idIdoso; }
}