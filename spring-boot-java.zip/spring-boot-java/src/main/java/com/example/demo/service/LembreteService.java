package com.example.demo.service;

import com.example.demo.dto.LembreteDTO;
import com.example.demo.entity.Lembrete;
import com.example.demo.entity.Remedio;
import com.example.demo.repository.LembreteRepository;
import com.example.demo.repository.RemedioRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class LembreteService {

    @Autowired
    private LembreteRepository lembreteRepository;

    @Autowired
    private RemedioRepository remedioRepository;

    @Transactional
    public void cadastrar(LembreteDTO dto) {
        Remedio remedio = dto.getIdRemedio() != null ? remedioRepository.findById(dto.getIdRemedio()).orElse(null) : null;
        Lembrete lembrete = new Lembrete(dto.getDescricao(), dto.getData_hora(), remedio);
        lembreteRepository.save(lembrete);
    }

    public List<Lembrete> listar() {
        return lembreteRepository.findAll();
    }

    @Transactional
    public void atualizar(Long id, LembreteDTO dto) {
        Lembrete lembrete = lembreteRepository.findById(id).orElse(null);
        if (lembrete != null) {
            Remedio remedio = dto.getIdRemedio() != null ? remedioRepository.findById(dto.getIdRemedio()).orElse(null) : null;
            lembrete.setDescricao(dto.getDescricao());
            lembrete.setData_hora(dto.getData_hora());
            lembrete.setRemedio(remedio);
        }
    }

    @Transactional
    public void remover(Long id) {
        if (lembreteRepository.existsById(id)) {
            lembreteRepository.deleteById(id);
        }
    }
}