package com.example.demo.service;

import com.example.demo.dto.CuidadorDTO;
import com.example.demo.entity.Cuidador;
import com.example.demo.repository.CuidadorRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class CuidadorService {

    @Autowired
    private CuidadorRepository repository;

    @Transactional
    public void cadastrar(CuidadorDTO cuidadorDTO){
        repository.save(new Cuidador(cuidadorDTO.getNome(), cuidadorDTO.getTelefone(), cuidadorDTO.getCpf()));
    }

    public List<Cuidador> listar(){
        return repository.findAll();
    }

    @Transactional
    public void atualizar(Long id, CuidadorDTO cuidadorDTO){
        Cuidador cuidadorEncontrado = repository.getReferenceById(id);
        if (cuidadorEncontrado == null) {
            System.out.println("Cuidador não existe");
        } else {
            cuidadorEncontrado.setNome(cuidadorDTO.getNome());
            cuidadorEncontrado.setTelefone(cuidadorDTO.getTelefone());
            cuidadorEncontrado.setCpf(cuidadorDTO.getCpf());
        }
    }

    @Transactional
    public void remover(Long id) {
        Cuidador cuidadorEncontrado = repository.getReferenceById(id);
        if (cuidadorEncontrado != null) {
            repository.deleteById(id);
        } else {
            System.out.println("Cuidador não existe");
        }
    }
}