package com.example.demo.entity;

import jakarta.persistence.*;
import com.fasterxml.jackson.annotation.JsonIgnore;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "remedio")
public class Remedio {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String nome;
    private float dosagem;
    private float intervalo;
    private LocalTime hora;

    @ManyToOne
    @JoinColumn(name = "id_idoso", nullable = true)
    private Idoso idoso;

    @JsonIgnore
    @OneToMany(mappedBy = "remedio", cascade = CascadeType.ALL)
    private List<Lembrete> lembretes = new ArrayList<>();

    protected Remedio() {}


    public Remedio(String nome, float dosagem, float intervalo, LocalTime hora, Idoso idoso) {
        this.nome = nome;
        this.dosagem = dosagem;
        this.intervalo = intervalo;
        this.hora = hora;
        this.idoso = idoso;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public float getDosagem() {
        return dosagem;
    }

    public void setDosagem(float dosagem) {
        this.dosagem = dosagem;
    }

    public float getIntervalo() {
        return intervalo;
    }

    public void setIntervalo(float intervalo) {
        this.intervalo = intervalo;
    }

    public LocalTime getHora() {
        return hora;
    }

    public void setHora(LocalTime hora) {
        this.hora = hora;
    }


    public Idoso getIdoso() {
        return idoso;
    }

    public void setIdoso(Idoso idoso) {
        this.idoso = idoso;
    }

    public List<Lembrete> getLembretes() {
        return lembretes;
    }

    public void setLembretes(List<Lembrete> lembretes) {
        this.lembretes = lembretes;
    }
}