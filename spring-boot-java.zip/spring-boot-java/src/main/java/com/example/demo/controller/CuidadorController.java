package com.example.demo.controller;

import com.example.demo.dto.CuidadorDTO;
import com.example.demo.entity.Cuidador;
import com.example.demo.service.CuidadorService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/cuidadores")
@CrossOrigin(origins = "*")
public class CuidadorController {

    @Autowired
    private CuidadorService service;

    @PostMapping
    public void cadastrar(@RequestBody CuidadorDTO dto){
        service.cadastrar(dto);
    }

    @GetMapping
    public ResponseEntity<List<Cuidador>> listar(){
        List<Cuidador> lista = service.listar();
        return ResponseEntity.ok(lista);
    }

    @PutMapping("/{id}")
    public void atualizar(@PathVariable Long id, @RequestBody CuidadorDTO dto){
        service.atualizar(id, dto);
    }

    @DeleteMapping("/{id}")
    public void remover(@PathVariable Long id){
        service.remover(id);
    }
}