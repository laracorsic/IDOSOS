const API_BASE_URL = 'http://localhost:8080'; 

document.addEventListener("DOMContentLoaded", () => {

    // ==========================================
    // 1. CRIAÇÃO E LÓGICA DO MODAL DE AJUDA
    // ==========================================
    const modalAjuda = document.createElement("div");
    modalAjuda.id = "caixa-ajuda-idoso";
    modalAjuda.innerHTML = `
        <div class="conteudo-ajuda">
            <h2>Precisa de uma ajuda? 😊</h2>
            <p>Para entrar, basta seguir estes 4 passos:</p>
            <p>1. Escreva o seu número de telefone.</p>
            <p>2. Escreva a sua idade.</p>
            <p>3. Escreva o seu nome completo.</p>
            <p>4. Clique no botão verde <strong>ENTRAR</strong>.</p>
            <button id="fechar-ajuda">Entendi, obrigado!</button>
        </div>
    `;
    document.body.appendChild(modalAjuda);

    const estilo = document.createElement("style");
    estilo.textContent = `
        #caixa-ajuda-idoso {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0,0,0,0.6);
            z-index: 9999;
            justify-content: center;
            align-items: center;
            font-family: Arial, sans-serif;
        }
        .conteudo-ajuda {
            background: white;
            padding: 30px;
            border-radius: 15px;
            max-width: 450px;
            width: 90%;
            text-align: center;
            box-shadow: 0 10px 25px rgba(0,0,0,0.3);
        }
        .conteudo-ajuda h2 {
            color: #333;
            font-size: 28px;
            margin-bottom: 20px;
        }
        .conteudo-ajuda p {
            color: #555;
            font-size: 20px;
            line-height: 1.5;
            margin-bottom: 15px;
        }
        #fechar-ajuda {
            background-color: #3b82f6;
            color: white;
            border: none;
            padding: 15px 30px;
            font-size: 20px;
            font-weight: bold;
            border-radius: 8px;
            cursor: pointer;
            margin-top: 10px;
            width: 100%;
        }
        #fechar-ajuda:hover {
            background-color: #2563eb;
        }
    `;
    document.head.appendChild(estilo);

    const botaoAjuda = document.querySelector(".btn-help");
    if (botaoAjuda) {
        botaoAjuda.addEventListener("click", (e) => {
            e.preventDefault();
            modalAjuda.style.display = "flex";
        });
    }

    document.getElementById("fechar-ajuda").addEventListener("click", () => {
        modalAjuda.style.display = "none";
    });

    // ==========================================
    // 2. MÁSCARA AUTOMÁTICA DE TELEFONE
    // ==========================================
    const inputTelefone = document.getElementById("telefone");
    
    if (inputTelefone) {
        // Limita o campo a no máximo 15 caracteres: (16) 99999-9888
        inputTelefone.setAttribute("maxlength", "15"); 
        
        inputTelefone.addEventListener("input", (e) => {
            let valor = e.target.value;
            
            // Remove qualquer caractere que não seja número
            valor = valor.replace(/\D/g, ""); 
            
            // Aplica a estilização dinâmica com base no tamanho digitado
            if (valor.length > 0) {
                valor = "(" + valor;
            }
            if (valor.length > 3) {
                valor = valor.slice(0, 3) + ") " + valor.slice(3);
            }
            if (valor.length > 10) {
                valor = valor.slice(0, 10) + "-" + valor.slice(10);
            }
            
            // Devolve o valor formatado de volta para o input da tela
            e.target.value = valor;
        });
    }

    // ==========================================
    // 3. ENVIO DOS DADOS PARA O BACKEND (JAVA)
    // ==========================================
    const formIdoso = document.getElementById("formCadastroIdoso");

    if (formIdoso) {
        formIdoso.addEventListener("submit", async (event) => {
            event.preventDefault(); 

            const telefoneDigitado = document.getElementById("telefone").value;
            const idadeDigitada = document.getElementById("idade").value;
            const nomeDigitado = document.getElementById("nome").value;

            const dadosIdoso = {
                nome: nomeDigitado,
                telefone: telefoneDigitado, // Envia já formatado como "(16) 99999-8888"
                idade: parseInt(idadeDigitada, 10)
            };

            try {
                const response = await fetch(`${API_BASE_URL}/idosos`, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify(dadosIdoso)
                });

                if (!response.ok) {
                    throw new Error(`Erro no servidor: ${response.status}`);
                }

                const respostaServidor = await response.json();
                console.log('Idoso registrado com sucesso:', respostaServidor);

                // Adiciona o tipo de usuário para controle na página de vínculo
                respostaServidor.userType = 'idoso';
                localStorage.setItem('currentUser', JSON.stringify(respostaServidor));
                window.location.href = "../vinculo/vinculo.html";

            } catch (error) {
                console.error('Falha ao registrar idoso:', error);
                alert('Ocorreu um erro ao tentar entrar. Verifique se o servidor Java está rodando.');
            }
        });
    }
});
