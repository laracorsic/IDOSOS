# Testar Web Push e Zelo

## Teste local

1. Inicie o backend preparado em `http://localhost:8080` (banco H2 local).
2. Sirva esta pasta por HTTP, nunca abrindo o HTML com `file://`. No terminal dentro desta pasta use `python -m http.server 5500`, ou use o Live Server do VS Code.
3. Acesse `http://localhost:5500/index.html`, cadastre-se e entre. Abra Configurações.
4. Clique **Ativar notificações** e permita no navegador. O status deve informar que a inscrição foi salva. Depois clique **Enviar notificação de teste** e confira a central de notificações do navegador/Windows.
5. Nas páginas autenticadas, use o botão flutuante **Falar com Zelo** para conversar.

`localhost` é uma origem segura para Service Worker/Web Push. Os envios reais usam o provedor push do navegador; Telegram não é necessário. A resposta HTTP 202 significa que o backend aceitou/enfileirou o teste. A confirmação visual é ver a notificação no dispositivo.

## Produção

Publique este frontend no Vercel e o backend atualizado no Render. O frontend usa o endereço definido em `js/config.js`. Configure no Render o CORS para a origem publicada, PostgreSQL e cookies de sessão cross-site seguros (`SESSION_COOKIE_SECURE=true`, `SESSION_COOKIE_SAME_SITE=None`). Para respostas generativas do Zelo, cadastre uma chave Groq nova como segredo `ASSISTENTE_IA_CHAVE` no Render; sem esse segredo, Zelo responde em modo local limitado. Não ponha chaves no frontend.
