/* Web Push receiver; served from the frontend origin at /service-worker.js. */
self.addEventListener('push', (event) => {
  let data = {};
  try {
    data = event.data ? event.data.json() : {};
  } catch (_) {
    data = { body: event.data ? event.data.text() : '' };
  }
  event.waitUntil(self.registration.showNotification(data.title || 'ConnectHub', {
    body: data.body || 'Você tem um novo lembrete.',
    icon: '/favicon.ico',
    badge: '/favicon.ico',
    tag: data.tag || 'connecthub-notificacao',
    data: { url: data.url || '/' }
  }));
});

self.addEventListener('notificationclick', (event) => {
  event.notification.close();
  let destination;
  try {
    destination = new URL(event.notification.data?.url || '/', self.location.origin);
    if (destination.origin !== self.location.origin) destination = new URL('/', self.location.origin);
  } catch (_) {
    destination = new URL('/', self.location.origin);
  }
  event.waitUntil((async () => {
    const windows = await self.clients.matchAll({ type: 'window', includeUncontrolled: true });
    for (const client of windows) {
      if ('focus' in client) {
        await client.focus();
        if ('navigate' in client) await client.navigate(destination.href);
        return;
      }
    }
    if (self.clients.openWindow) await self.clients.openWindow(destination.href);
  })());
});
