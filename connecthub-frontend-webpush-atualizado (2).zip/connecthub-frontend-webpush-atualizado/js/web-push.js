import { API_BASE_URL } from './config.js';

const api = `${API_BASE_URL}/notificacoes/push`;
const statusNode = document.getElementById('statusNotificacoesPush');
const activateButton = document.getElementById('btnAtivarNotificacoesPush');
const testButton = document.getElementById('btnTestarNotificacoesPush');

function showStatus(message, state = 'info') {
  if (!statusNode) return;
  statusNode.textContent = message;
  statusNode.dataset.state = state;
}

function vapidKeyBytes(value) {
  const padding = '='.repeat((4 - value.length % 4) % 4);
  const base64 = (value + padding).replace(/-/g, '+').replace(/_/g, '/');
  return Uint8Array.from(atob(base64), character => character.charCodeAt(0));
}

async function errorMessage(response, fallback) {
  const text = await response.text();
  return text || `${fallback} (HTTP ${response.status})`;
}

async function loadServerStatus() {
  const response = await fetch(`${api}/inscricoes/status`, { credentials: 'include' });
  if (!response.ok) throw new Error(await errorMessage(response, 'Não foi possível consultar a inscrição'));
  return response.json();
}

export async function initializeWebPushControls() {
  if (!activateButton || !testButton || !statusNode) return;
  const supported = 'serviceWorker' in navigator && 'PushManager' in window && 'Notification' in window;
  if (!supported) {
    activateButton.disabled = true;
    testButton.disabled = true;
    showStatus('Este navegador não oferece suporte a notificações push.', 'error');
    return;
  }
  if (!window.isSecureContext) {
    activateButton.disabled = true;
    testButton.disabled = true;
    showStatus('Push requer HTTPS (ou localhost). Abra o site por uma origem segura.', 'error');
    return;
  }

  let readyToTest = false;
  let registration;
  const refresh = async () => {
    registration = await navigator.serviceWorker.register('/service-worker.js', { scope: '/' });
    const localSubscription = await registration.pushManager.getSubscription();
    const remoteStatus = await loadServerStatus();
    readyToTest = Boolean(remoteStatus.inscrito && localSubscription);
    testButton.disabled = !readyToTest;
    if (Notification.permission === 'denied') {
      showStatus('As notificações estão bloqueadas no navegador. Libere a permissão nas configurações do site.', 'error');
    } else if (readyToTest) {
      showStatus('Este navegador está inscrito e a inscrição foi salva no servidor. Você pode enviar um teste.', 'success');
      activateButton.textContent = 'Atualizar inscrição';
    } else if (localSubscription && !remoteStatus.inscrito) {
      showStatus('O navegador tem uma inscrição, mas ela ainda não está vinculada à sua conta. Clique em Atualizar inscrição.', 'info');
      activateButton.textContent = 'Atualizar inscrição';
    } else {
      showStatus('Notificações ainda não estão ativas neste navegador.', 'info');
      activateButton.textContent = 'Ativar notificações';
    }
  };

  activateButton.addEventListener('click', async () => {
    activateButton.disabled = true;
    testButton.disabled = true;
    try {
      if (Notification.permission !== 'granted') {
        // Request permission directly from the click gesture; do not prompt automatically.
        const permissionPromise = Notification.requestPermission();
        const permission = await permissionPromise;
        if (permission !== 'granted') throw new Error('Permissão de notificações não concedida.');
      }
      showStatus('Ativando notificações neste navegador...');
      const configResponse = await fetch(`${api}/configuracao`, { credentials: 'include' });
      if (!configResponse.ok) throw new Error(await errorMessage(configResponse, 'Falha ao consultar configuração Web Push'));
      const config = await configResponse.json();
      if (!config.enabled || !config.publicKey) throw new Error('Web Push não está habilitado no backend.');
      registration = await navigator.serviceWorker.register('/service-worker.js', { scope: '/' });
      let subscription = await registration.pushManager.getSubscription();
      if (!subscription) {
        subscription = await registration.pushManager.subscribe({
          userVisibleOnly: true,
          applicationServerKey: vapidKeyBytes(config.publicKey)
        });
      }
      const saveResponse = await fetch(`${api}/inscricoes`, {
        method: 'POST',
        credentials: 'include',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(subscription.toJSON())
      });
      if (!saveResponse.ok) throw new Error(await errorMessage(saveResponse, 'Não foi possível salvar a inscrição'));
      await refresh();
      showStatus('Inscrição salva. Agora use “Enviar notificação de teste” para verificar a entrega.', 'success');
    } catch (error) {
      showStatus(error.message || 'Não foi possível ativar as notificações.', 'error');
    } finally {
      activateButton.disabled = false;
      testButton.disabled = !readyToTest;
    }
  });

  testButton.addEventListener('click', async () => {
    testButton.disabled = true;
    try {
      const response = await fetch(`${api}/teste`, { method: 'POST', credentials: 'include' });
      if (!response.ok) throw new Error(await errorMessage(response, 'Falha ao solicitar notificação de teste'));
      const result = await response.json();
      showStatus(`${result.message || 'Teste solicitado.'} Confira a central de notificações do navegador/Windows.`, 'success');
    } catch (error) {
      showStatus(error.message || 'Falha ao enviar teste.', 'error');
    } finally {
      testButton.disabled = !readyToTest;
    }
  });

  try {
    await refresh();
  } catch (error) {
    if (error.message && (error.message.includes('401') || error.message.includes('Acesso não autorizado'))) {
      showStatus('Sua sessão não está autenticada. Entre novamente e abra Configurações.', 'error');
    } else {
      showStatus(error.message || 'Não foi possível consultar o estado das notificações.', 'error');
    }
    activateButton.disabled = false;
    testButton.disabled = true;
  }
}
