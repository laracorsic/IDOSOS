import { API_BASE_URL } from './config.js';

const backend = API_BASE_URL.replace(/\/$/, '');
window.CONNECTHUB_API_BASE_URL = backend;
const stylesheet = document.createElement('link');
stylesheet.rel = 'stylesheet';
stylesheet.href = `${backend}/zelo/assistente.css`;
document.head.appendChild(stylesheet);
const widget = document.createElement('script');
widget.src = `${backend}/zelo/assistente.js`;
widget.defer = true;
document.body.appendChild(widget);
