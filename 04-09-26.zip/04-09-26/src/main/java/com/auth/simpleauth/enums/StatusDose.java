package com.auth.simpleauth.enums;

public enum StatusDose {
    PENDENTE,
    NOTIFICADO,
    TOMADO,
    ATRASADO,
    PERDIDO
}