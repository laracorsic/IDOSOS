package com.auth.simpleauth.service;

import com.auth.simpleauth.entity.Dose;
import com.auth.simpleauth.entity.Medicamento;
import com.auth.simpleauth.enums.StatusDose;
import com.auth.simpleauth.repository.DoseRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
public class DoseService {

    private final DoseRepository doseRepository;

    public DoseService(DoseRepository doseRepository) {
        this.doseRepository = doseRepository;
    }

    public List<Dose> listarPorIdoso(Long idosoId) {
        return doseRepository.findByMedicamentoIdosoId(idosoId);
    }

    public Optional<Dose> buscarPorId(Long id) {
        return doseRepository.findById(id);
    }

    @Transactional
    public Dose confirmarDose(Long doseId) {
        Dose dose = doseRepository.findById(doseId)
                .orElseThrow(() -> new RuntimeException("Dose não encontrada com ID: " + doseId));

        dose.setStatus(StatusDose.TOMADO);
        dose.setHorarioConfirmado(LocalDateTime.now());

        // Limpa a próxima notificação para interromper os alertas do AgendaSchedulerService
        dose.setProximaNotificacao(null);

        Dose doseAtualizada = doseRepository.save(dose);

        // Gera automaticamente a próxima dose programada baseada no intervalo
        gerarProximaDose(dose.getMedicamento(), dose.getHorarioProgramado());

        return doseAtualizada;
    }

    @Transactional
    public Dose marcarComoAtrasadaOuPerdida(Long doseId, StatusDose novoStatus) {
        Dose dose = doseRepository.findById(doseId)
                .orElseThrow(() -> new RuntimeException("Dose não encontrada com ID: " + doseId));

        dose.setStatus(novoStatus);
        dose.setProximaNotificacao(null);
        return doseRepository.save(dose);
    }

    private void gerarProximaDose(Medicamento medicamento, LocalDateTime horarioAtual) {
        if (medicamento.getAtivo() == null || !medicamento.getAtivo()) return;

        LocalDateTime proximoHorario = horarioAtual.plusHours(medicamento.getIntervaloHoras());
        Dose proximaDose = new Dose(medicamento, proximoHorario);
        doseRepository.save(proximaDose);
    }
}