package com.auth.simpleauth.service;

import com.auth.simpleauth.entity.Dose;
import com.auth.simpleauth.entity.Familiar;
import com.auth.simpleauth.enums.StatusDose;
import com.auth.simpleauth.repository.DoseRepository;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class AgendaSchedulerService {

    private final DoseRepository doseRepository;
    private final TelegramService telegramService;

    public AgendaSchedulerService(DoseRepository doseRepository, TelegramService telegramService) {
        this.doseRepository = doseRepository;
        this.telegramService = telegramService;
    }

    // Executa a cada 60 segundos (60.000 ms)
    @Scheduled(fixedRate = 60000)
    @Transactional
    public void verificarDosesAgendadas() {
        LocalDateTime agora = LocalDateTime.now();

        // 1. Busca doses pendentes ou já notificadas cujo horário programado já passou
        List<Dose> dosesParaProcessar = doseRepository.findByStatusInAndHorarioProgramadoLessThanEqual(
                List.of(StatusDose.PENDENTE, StatusDose.NOTIFICADO),
                agora
        );

        for (Dose dose : dosesParaProcessar) {
            processarDose(dose, agora);
        }
    }

    private void processarDose(Dose dose, LocalDateTime agora) {
        String nomeMedicamento = dose.getMedicamento().getNome();
        String nomeIdoso = dose.getMedicamento().getIdoso().getNome();
        String telegramIdIdoso = dose.getMedicamento().getIdoso().getTelegramChatId();

        // Primeira Notificação ao Idoso
        if (dose.getStatus() == StatusDose.PENDENTE) {
            dose.setStatus(StatusDose.NOTIFICADO);
            dose.setQuantidadeNotificacoes(1);
            dose.setProximaNotificacao(agora.plusMinutes(15));
            doseRepository.save(dose);

            String mensagem = String.format("⏰ Olá %s! Hora de tomar o medicamento: %s.", nomeIdoso, nomeMedicamento);
            telegramService.enviarNotificacao(telegramIdIdoso, mensagem);
            return;
        }

        // Lógica de Re-notificação / Atraso
        if (dose.getStatus() == StatusDose.NOTIFICADO && dose.getProximaNotificacao() != null) {
            if (agora.isAfter(dose.getProximaNotificacao())) {
                int tentativas = dose.getQuantidadeNotificacoes() + 1;
                dose.setQuantidadeNotificacoes(tentativas);

                if (tentativas < 3) {
                    // Tenta novamente com o Idoso após mais 15 min
                    dose.setProximaNotificacao(agora.plusMinutes(15));
                    doseRepository.save(dose);

                    String mensagem = String.format("⚠️ Lembrente (%d/3): %s, você ainda não confirmou o %s!",
                            tentativas, nomeIdoso, nomeMedicamento);
                    telegramService.enviarNotificacao(telegramIdIdoso, mensagem);
                } else {
                    // Excedeu tentativas: Marca como ATRASADO e avisa o Familiar
                    dose.setStatus(StatusDose.ATRASADO);
                    doseRepository.save(dose);

                    notificarFamiliarAtraso(dose);
                }
            }
        }
    }

    private void notificarFamiliarAtraso(Dose dose) {
        Familiar familiar = dose.getMedicamento().getIdoso().getFamiliar();
        if (familiar != null && familiar.getTelegramChatId() != null) {
            String msgFamiliar = String.format(
                    "🚨 ATENÇÃO: O idoso %s não confirmou a dose do medicamento '%s' programada para as %s.",
                    dose.getMedicamento().getIdoso().getNome(),
                    dose.getMedicamento().getNome(),
                    dose.getHorarioProgramado().toLocalTime()
            );
            telegramService.enviarNotificacao(familiar.getTelegramChatId(), msgFamiliar);
        }
    }
}