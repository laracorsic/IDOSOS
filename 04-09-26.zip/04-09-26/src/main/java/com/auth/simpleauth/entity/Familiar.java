package com.auth.simpleauth.entity;

import com.auth.simpleauth.enums.Perfil;
import jakarta.persistence.DiscriminatorValue;
import jakarta.persistence.Entity;
import jakarta.persistence.OneToMany;

import java.util.ArrayList;
import java.util.List;

@Entity
@DiscriminatorValue("FAMILIAR")
public class Familiar extends Usuario {

    // Lista de idosos vinculados a este familiar
    @OneToMany(mappedBy = "familiar")
    private List<Idoso> idosos = new ArrayList<>();

    // Atualizado: Refatorado de Remedio para Medicamento
    @OneToMany(mappedBy = "familiar")
    private List<Medicamento> medicamentosCadastrados = new ArrayList<>();

    public Familiar() {
        setPerfil(Perfil.FAMILIAR);
    }

    public Familiar(String nome, String email, String senha, String telefone, String telegramChatId) {
        super(nome, email, senha, telefone, telegramChatId, Perfil.FAMILIAR);
    }

    // Getters e Setters
    public List<Idoso> getIdosos() { return idosos; }
    public void setIdosos(List<Idoso> idosos) { this.idosos = idosos; }

    public List<Medicamento> getMedicamentosCadastrados() { return medicamentosCadastrados; }
    public void setMedicamentosCadastrados(List<Medicamento> medicamentosCadastrados) {
        this.medicamentosCadastrados = medicamentosCadastrados;
    }
}