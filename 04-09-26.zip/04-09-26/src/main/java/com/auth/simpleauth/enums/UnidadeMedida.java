package com.auth.simpleauth.enums;

public enum UnidadeMedida {
    COMPRIMIDO,
    GOTAS,
    ML,
    MG,
    G,
    UNIDADE
}