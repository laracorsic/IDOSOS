package com.auth.simpleauth.repository;

import com.auth.simpleauth.entity.Dose;
import com.auth.simpleauth.enums.StatusDose;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;

@Repository
public interface DoseRepository extends JpaRepository<Dose, Long> {
    List<Dose> findByMedicamentoIdosoId(Long idosoId);

    // Busca doses pendentes ou notificadas com horário programado até o instante atual
    List<Dose> findByStatusInAndHorarioProgramadoLessThanEqual(List<StatusDose> status, LocalDateTime horario);

    // Busca histórico de doses entre duas datas
    List<Dose> findByMedicamentoIdosoIdAndHorarioProgramadoBetween(Long idosoId, LocalDateTime inicio, LocalDateTime fim);
}

