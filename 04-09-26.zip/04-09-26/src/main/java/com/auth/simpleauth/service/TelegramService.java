package com.auth.simpleauth.service;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.HashMap;
import java.util.Map;

@Service
public class TelegramService {

    @Value("${telegram.bot.token}")
    private String botToken;

    @Value("${telegram.chat.id:}")
    private String defaultChatId;

    private final RestTemplate restTemplate;

    public TelegramService() {
        this.restTemplate = new RestTemplate();
    }

    public void enviarNotificacao(String chatIdDestino, String mensagem) {
        String targetChatId = (chatIdDestino != null && !chatIdDestino.isBlank()) ? chatIdDestino : defaultChatId;

        // Se nem o destino e nem o fallback existirem, interrompe graciosamente sem chamar a API
        if (targetChatId == null || targetChatId.isBlank() || targetChatId.startsWith("SEU_")) {
            System.err.println("⚠️ Notificação cancelada: Usuário não possui Chat ID do Telegram cadastrado.");
            return;
        }

        String url = "https://api.telegram.org/bot" + botToken + "/sendMessage";

        Map<String, String> body = new HashMap<>();
        body.put("chat_id", targetChatId);
        body.put("text", mensagem);
        body.put("parse_mode", "Markdown");

        try {
            restTemplate.postForObject(url, body, String.class);
        } catch (Exception e) {
            System.err.println("❌ Erro ao enviar mensagem via Telegram: " + e.getMessage());
        }
    }

    // Sobrecarga para chamadas sem chatId explícito (utiliza o defaultChatId)
    public void enviarNotificacao(String mensagem) {
        enviarNotificacao(null, mensagem);
    }
}