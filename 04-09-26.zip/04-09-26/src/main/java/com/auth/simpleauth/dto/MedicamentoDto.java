package com.auth.simpleauth.dto;

import com.auth.simpleauth.enums.UnidadeMedida;
import java.time.LocalDateTime;

public class MedicamentoDto {
    private String nome;
    private Double dosagem;
    private UnidadeMedida unidade;
    private Double quantidadePorDose;
    private LocalDateTime primeiroHorario;
    private Integer intervaloHoras;
    private Long idIdoso;

    public MedicamentoDto() {}

    public MedicamentoDto(String nome, Double dosagem, UnidadeMedida unidade, Double quantidadePorDose,
                          LocalDateTime primeiroHorario, Integer intervaloHoras, Long idIdoso) {
        this.nome = nome;
        this.dosagem = dosagem;
        this.unidade = unidade;
        this.quantidadePorDose = quantidadePorDose;
        this.primeiroHorario = primeiroHorario;
        this.intervaloHoras = intervaloHoras;
        this.idIdoso = idIdoso;
    }

    public String getNome() { return nome; }
    public void setNome(String nome) { this.nome = nome; }

    public Double getDosagem() { return dosagem; }
    public void setDosagem(Double dosagem) { this.dosagem = dosagem; }

    public UnidadeMedida getUnidade() { return unidade; }
    public void setUnidade(UnidadeMedida unidade) { this.unidade = unidade; }

    public Double getQuantidadePorDose() { return quantidadePorDose; }
    public void setQuantidadePorDose(Double quantidadePorDose) { this.quantidadePorDose = quantidadePorDose; }

    public LocalDateTime getPrimeiroHorario() { return primeiroHorario; }
    public void setPrimeiroHorario(LocalDateTime primeiroHorario) { this.primeiroHorario = primeiroHorario; }

    public Integer getIntervaloHoras() { return intervaloHoras; }
    public void setIntervaloHoras(Integer intervaloHoras) { this.intervaloHoras = intervaloHoras; }

    public Long getIdIdoso() { return idIdoso; }
    public void setIdIdoso(Long idIdoso) { this.idIdoso = idIdoso; }
}