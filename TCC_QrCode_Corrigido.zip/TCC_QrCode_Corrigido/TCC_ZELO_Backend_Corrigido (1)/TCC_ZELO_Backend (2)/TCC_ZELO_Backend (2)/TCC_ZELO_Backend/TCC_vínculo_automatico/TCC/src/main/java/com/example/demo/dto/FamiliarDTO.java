package com.example.demo.dto;

public class FamiliarDTO {
    private String nome;
    private int idade;

    public FamiliarDTO() {}

    public FamiliarDTO(String nome, int idade) {
        this.nome = nome;
        this.idade = idade;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public int getIdade() {
        return idade;
    }

    public void setIdade(int idade) {
        this.idade = idade;
    }
}
