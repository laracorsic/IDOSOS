package com.example.demo.service;

import com.example.demo.dto.IdosoDTO;
import com.example.demo.entity.Idoso;
import com.example.demo.repository.IdosoRepository;
import com.example.demo.util.QRCodeGenerator;
import com.google.zxing.WriterException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import tools.jackson.databind.ObjectMapper;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service

public class IdosoService {

    @Autowired

    private IdosoRepository repository;

    @Transactional
    public Idoso cadastrar(IdosoDTO idosoDTO) {

        Idoso idoso = new Idoso(
                idosoDTO.getNome(),
                idosoDTO.getIdade()
        );

        idoso = repository.save(idoso);

        try {

            ObjectMapper mapper = new ObjectMapper();

            Map<String, Object> dadosQr = new HashMap<>();

            dadosQr.put("id", idoso.getId());
            dadosQr.put("nome", idoso.getNome());
            dadosQr.put("idade", idoso.getIdade());

            String conteudoQr = mapper.writeValueAsString(dadosQr);

            byte[] qrCode = QRCodeGenerator.generateQRCodeImage(
                    conteudoQr,
                    250,
                    250
            );

            idoso.setQrCode(qrCode);

            idoso = repository.save(idoso);

        } catch (WriterException | IOException e) {
            e.printStackTrace();
        }
        return idoso;
    }

    public List<Idoso> listar(){
        return repository.findAll();
    }

    public Idoso buscarPorId(Long id) {
        return repository.findById(id).orElse(null);
    }

    @Transactional
    public void atualizar(Long id, IdosoDTO idosoDTO){
       Idoso idosoEncontrado = repository.getReferenceById(id);
        if (idosoEncontrado == null) {
            System.out.println("Idoso não existe");
        }else{
           idosoEncontrado.setNome(idosoDTO.getNome());
           idosoEncontrado.setIdade(idosoDTO.getIdade());
        }
    }

    @Transactional
    public void remover(Long id) {
       Idoso idosoEncontrado = repository.getReferenceById(id);
        if (idosoEncontrado != null) {
            repository.deleteById(id);
        } else {
            System.out.println("Idoso não existe");
        }
    }
}