package com.example.demo.entity;

import jakarta.persistence.*;
import java.util.List;

@Entity
@Table(name = "cuidador")
public class Cuidador {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String nome;
    private String cpf;

    @ManyToMany
    @JoinTable(
            name = "cuidador_idoso",
            joinColumns = @JoinColumn(name = "id_cuidador"),
            inverseJoinColumns = @JoinColumn(name = "id_idoso")
    )
    private List<Idoso> idosos;

    protected Cuidador() {}

    public Cuidador(String nome, String cpf) {
        this.nome = nome;
        this.cpf = cpf;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    public List<Idoso> getIdosos() {
        return idosos;
    }

    public void setIdosos(List<Idoso> idosos) {
        this.idosos = idosos;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Cuidador cuidador = (Cuidador) o;
        return id != null && id.equals(cuidador.id);
    }

    @Override
    public int hashCode() {
        return id != null ? id.hashCode() : 0;
    }
}
