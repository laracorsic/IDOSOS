function obterIdosoAtual() {
    const idosoSalvo = JSON.parse(localStorage.getItem("selectedIdoso"));
    if (idosoSalvo && idosoSalvo.id) {
        return idosoSalvo;
    }
    
    const currentUser = JSON.parse(localStorage.getItem("currentUser")) || {};
    return {
        id: currentUser.idIdoso || "38299",
        nome: currentUser.nomeIdoso || "Miquéias de Sousa"
    };
}

const idosoAtivo = obterIdosoAtual();
const CHAVE_LEMBRETES = `zelo_lembretes_${idosoAtivo.id}`;

function obterLembretes() {
    return JSON.parse(localStorage.getItem(CHAVE_LEMBRETES)) || [];
}

function salvarLembretes(lembretes) {
    localStorage.setItem(CHAVE_LEMBRETES, JSON.stringify(lembretes));
}

function escaparHTML(texto) {
    const div = document.createElement("div");
    div.textContent = texto ?? "";
    return div.innerHTML;
}

document.addEventListener('DOMContentLoaded', () => {
    // Atualizar nome do idoso nos dois locais da interface
    const nomeLabel = document.getElementById("nome-idoso-label");
    const headerNomeLabel = document.getElementById("header-nome-idoso");
    
    if (nomeLabel) {
        nomeLabel.textContent = idosoAtivo.nome;
    }
    if (headerNomeLabel) {
        headerNomeLabel.textContent = idosoAtivo.nome;
    }

    // Elementos dos Modais
    const modalAdicionar = document.getElementById('modal-adicionar');
    const modalRemover = document.getElementById('modal-remover');
    const modalLista = document.getElementById('modal-lista');

    // Botões Principais
    const btnAbrirAdicionar = document.getElementById('btn-abrir-adicionar');
    const btnAbrirRemover = document.getElementById('btn-abrir-remover');
    const btnAbrirLista = document.getElementById('btn-abrir-lista');

    // Campos de Entrada e Listas
    const inputTitulo = document.getElementById('input-lembrete-titulo');
    const inputHorario = document.getElementById('input-lembrete-horario');
    const inputDesc = document.getElementById('input-lembrete-desc');
    const btnSalvarLembrete = document.getElementById('btn-salvar-lembrete');
    const listaRemover = document.getElementById('lista-remover');
    const listaVer = document.getElementById('lista-ver');

    // Abrir Modais
    btnAbrirAdicionar.addEventListener('click', (e) => {
        e.preventDefault();
        inputTitulo.value = '';
        inputHorario.value = '';
        inputDesc.value = '';
        modalAdicionar.classList.add('active');
    });

    btnAbrirRemover.addEventListener('click', (e) => {
        e.preventDefault();
        renderizarListaRemover();
        modalRemover.classList.add('active');
    });

    btnAbrirLista.addEventListener('click', (e) => {
        e.preventDefault();
        renderizarListaVer();
        modalLista.classList.add('active');
    });

    // Fechar Modais
    document.querySelectorAll('.btn-fechar').forEach(btn => {
        btn.addEventListener('click', () => {
            modalAdicionar.classList.remove('active');
            modalRemover.classList.remove('active');
            modalLista.classList.remove('active');
        });
    });

    // Adicionar Lembrete
    btnSalvarLembrete.addEventListener('click', () => {
        const titulo = inputTitulo.value.trim();
        const horario = inputHorario.value;
        const descricao = inputDesc.value.trim();

        if (!titulo) {
            alert('Por favor, informe o título do lembrete!');
            return;
        }

        const novoLembrete = {
            id: Date.now().toString(),
            titulo: titulo,
            horario: horario || "--:--",
            descricao: descricao,
            dataCriacao: new Date().toISOString()
        };

        const lembretes = obterLembretes();
        lembretes.push(novoLembrete);
        salvarLembretes(lembretes);

        modalAdicionar.classList.remove('active');
        alert('Lembrete adicionado com sucesso!');
    });

    // Renderizar Lista para Remover
    function renderizarListaRemover() {
        listaRemover.innerHTML = '';
        const lembretes = obterLembretes();

        if (lembretes.length === 0) {
            listaRemover.innerHTML = '<li>Nenhum lembrete cadastrado.</li>';
            return;
        }

        lembretes.forEach((item) => {
            const li = document.createElement('li');
            li.innerHTML = `
                <div>
                    <strong>${escaparHTML(item.titulo)}</strong> 
                    ${item.horario ? `<small>(${item.horario})</small>` : ''}
                </div>
                <button class="btn-deletar-item" onclick="removerLembrete('${item.id}')">Excluir</button>
            `;
            listaRemover.appendChild(li);
        });
    }

    // Renderizar Lista para Visualizar
    function renderizarListaVer() {
        listaVer.innerHTML = '';
        const lembretes = obterLembretes();

        if (lembretes.length === 0) {
            listaVer.innerHTML = '<li>Nenhum lembrete cadastrado.</li>';
            return;
        }

        lembretes.forEach(item => {
            const li = document.createElement('li');
            li.innerHTML = `
                <div>
                    <strong>${escaparHTML(item.titulo)}</strong> ${item.horario ? `- <span>${item.horario}</span>` : ''}
                    ${item.descricao ? `<br><small style="color: #666;">${escaparHTML(item.descricao)}</small>` : ''}
                </div>
            `;
            listaVer.appendChild(li);
        });
    }

    // Função global de remoção por ID
    window.removerLembrete = function(id) {
        let lembretes = obterLembretes();
        lembretes = lembretes.filter(item => item.id !== id);
        salvarLembretes(lembretes);
        renderizarListaRemover();
    };
});