document.addEventListener("DOMContentLoaded", () => {

    /* =====================================================
       ELEMENTOS
       ===================================================== */

    const btnAdicionar = document.getElementById("btn-adicionar");
    const btnRemover = document.getElementById("btn-remover");
    const btnCorGaveta = document.getElementById("btn-cor-gaveta");
    const btnLista = document.getElementById("btn-lista");

    const nomeIdosoElement = document.getElementById("nome-idoso");
    const idosoLabel = document.getElementById("idoso-label");
    const nomeFamiliar = document.getElementById("nome-familiar");


    /* =====================================================
       PEGAR IDOSO ATUAL
       ===================================================== */

    function pegarIdosoAtual() {

        const selecionado = JSON.parse(
            localStorage.getItem("selectedIdoso")
        );

        const usuario = JSON.parse(
            localStorage.getItem("currentUser")
        ) || {};


        if (selecionado) {
            return {
                id: selecionado.id || "38299",
                nome: selecionado.nome || "Miquéias de Sousa"
            };
        }


        return {
            id: usuario.idIdoso || "38299",
            nome: usuario.nomeIdoso || "Miquéias de Sousa"
        };
    }


    const idoso = pegarIdosoAtual();


    /* =====================================================
       ATUALIZAR NOME
       ===================================================== */

    nomeIdosoElement.textContent = idoso.nome.split(" ")[0];

    idosoLabel.textContent =
        `Idoso: ${idoso.nome} (ID: #${idoso.id})`;


    const usuarioAtual = JSON.parse(
        localStorage.getItem("currentUser")
    ) || {};

    nomeFamiliar.textContent =
        usuarioAtual.nome || "Familiar";


    /* =====================================================
       CHAVES DO LOCALSTORAGE
       ===================================================== */

    const chaveRemedios =
        `zelo_remedios_${idoso.id}`;

    const chaveGavetas =
        `zelo_gavetas_${idoso.id}`;


    /* =====================================================
       PEGAR REMÉDIOS
       ===================================================== */

    function pegarRemedios() {

        return JSON.parse(
            localStorage.getItem(chaveRemedios)
        ) || [];
    }


    /* =====================================================
       SALVAR REMÉDIOS
       ===================================================== */

    function salvarRemedios(remedios) {

        localStorage.setItem(
            chaveRemedios,
            JSON.stringify(remedios)
        );

        atualizarDadosDashboard();
    }


    /* =====================================================
       PEGAR GAVETAS
       ===================================================== */

    function pegarGavetas() {

        return JSON.parse(
            localStorage.getItem(chaveGavetas)
        ) || {};
    }


    /* =====================================================
       SALVAR GAVETAS
       ===================================================== */

    function salvarGavetas(gavetas) {

        localStorage.setItem(
            chaveGavetas,
            JSON.stringify(gavetas)
        );
    }


    /* =====================================================
       CRIAR MODAL
       ===================================================== */

    function criarModal(conteudo) {

        const overlay = document.createElement("div");

        overlay.className = "modal-overlay";

        overlay.innerHTML = `
            <div class="modal">
                ${conteudo}
            </div>
        `;

        document.body.appendChild(overlay);

        return overlay;
    }


    /* =====================================================
       FECHAR MODAL
       ===================================================== */

    function fecharModal(modal) {

        if (modal) {
            modal.remove();
        }
    }


    /* =====================================================
       ADICIONAR REMÉDIO
       ===================================================== */

    function adicionarRemedio() {

        const modal = criarModal(`

            <h2>Adicionar remédio</h2>

            <label for="nome-remedio">
                Nome do remédio
            </label>

            <input
                id="nome-remedio"
                type="text"
                placeholder="Ex.: Remédio"
            >


            <label for="dosagem-remedio">
                Dosagem
            </label>

            <input
                id="dosagem-remedio"
                type="text"
                placeholder="Ex.: 1 comprimido"
            >


            <label for="horario-remedio">
                Horário
            </label>

            <input
                id="horario-remedio"
                type="time"
            >


            <label for="gaveta-remedio">
                Número da gaveta
            </label>

            <select id="gaveta-remedio">

                <option value="1">
                    Gaveta 1
                </option>

                <option value="2">
                    Gaveta 2
                </option>

                <option value="3">
                    Gaveta 3
                </option>

                <option value="4">
                    Gaveta 4
                </option>

                <option value="5">
                    Gaveta 5
                </option>

                <option value="6">
                    Gaveta 6
                </option>

            </select>


            <div class="modal-buttons">

                <button
                    class="modal-btn cancel"
                    id="cancelar-adicionar">
                    Cancelar
                </button>

                <button
                    class="modal-btn confirm"
                    id="confirmar-adicionar">
                    Adicionar
                </button>

            </div>
        `);


        modal.querySelector(
            "#cancelar-adicionar"
        ).addEventListener("click", () => {

            fecharModal(modal);

        });


        modal.querySelector(
            "#confirmar-adicionar"
        ).addEventListener("click", () => {

            const nome =
                modal.querySelector("#nome-remedio")
                    .value.trim();

            const dosagem =
                modal.querySelector("#dosagem-remedio")
                    .value.trim();

            const horario =
                modal.querySelector("#horario-remedio")
                    .value;

            const gaveta =
                modal.querySelector("#gaveta-remedio")
                    .value;


            if (!nome) {

                alert(
                    "Digite o nome do remédio."
                );

                return;
            }


            const remedios = pegarRemedios();


            const novoRemedio = {

                id: Date.now(),

                nome: nome,

                dosagem:
                    dosagem || "Não informada",

                horario:
                    horario || "Não informado",

                gaveta: gaveta,

                tomado: false

            };


            remedios.push(novoRemedio);

            salvarRemedios(remedios);

            fecharModal(modal);


            alert(
                "Remédio adicionado com sucesso!"
            );

        });

    }


    /* =====================================================
       REMOVER REMÉDIO
       ===================================================== */

    function removerRemedio() {

        const remedios = pegarRemedios();


        if (remedios.length === 0) {

            alert(
                "Não existem remédios cadastrados."
            );

            return;
        }


        let listaHTML = "";


        remedios.forEach((remedio, index) => {

            listaHTML += `

                <div class="remedio-item">

                    <div class="remedio-info">

                        <strong>
                            ${index + 1}.
                            ${escaparHTML(remedio.nome)}
                        </strong>

                        <span>
                            ${escaparHTML(remedio.dosagem)}
                            |
                            Horário:
                            ${escaparHTML(remedio.horario)}
                        </span>

                        <span>
                            Gaveta ${remedio.gaveta}
                        </span>

                    </div>

                    <button
                        class="modal-btn confirm"
                        data-remedio-id="${remedio.id}">

                        Remover

                    </button>

                </div>

            `;
        });


        const modal = criarModal(`

            <h2>
                Remover remédio
            </h2>

            <p style="margin-bottom:20px;">
                Escolha qual remédio deseja remover:
            </p>

            <div>
                ${listaHTML}
            </div>

            <div class="modal-buttons">

                <button
                    class="modal-btn cancel"
                    id="fechar-remover">

                    Fechar

                </button>

            </div>

        `);


        modal.querySelector(
            "#fechar-remover"
        ).addEventListener("click", () => {

            fecharModal(modal);

        });


        modal.querySelectorAll(
            "[data-remedio-id]"
        ).forEach(botao => {

            botao.addEventListener(
                "click",
                () => {

                    const id =
                        Number(
                            botao.dataset.remedioId
                        );


                    const remedio =
                        pegarRemedios()
                        .find(r => r.id === id);


                    if (!remedio) {
                        return;
                    }


                    const confirmou =
                        confirm(
                            `Deseja remover "${remedio.nome}"?`
                        );


                    if (!confirmou) {
                        return;
                    }


                    const novaLista =
                        pegarRemedios()
                        .filter(r => r.id !== id);


                    salvarRemedios(novaLista);

                    fecharModal(modal);


                    alert(
                        "Remédio removido com sucesso!"
                    );

                }
            );

        });

    }


    /* =====================================================
       DEFINIR COR DA GAVETA
       ===================================================== */

    function definirCorGaveta() {

        const gavetas = pegarGavetas();


        const modal = criarModal(`

            <h2>
                Definir cor de gaveta
            </h2>

            <label for="numero-gaveta">
                Escolha a gaveta
            </label>

            <select id="numero-gaveta">

                <option value="1">
                    Gaveta 1
                </option>

                <option value="2">
                    Gaveta 2
                </option>

                <option value="3">
                    Gaveta 3
                </option>

                <option value="4">
                    Gaveta 4
                </option>

                <option value="5">
                    Gaveta 5
                </option>

                <option value="6">
                    Gaveta 6
                </option>

            </select>


            <label for="cor-gaveta">
                Escolha a cor
            </label>

            <input
                id="cor-gaveta"
                type="color"
                value="#c4d0ff"
                style="height:60px; padding:5px;"
            >


            <div class="modal-buttons">

                <button
                    class="modal-btn cancel"
                    id="cancelar-cor">

                    Cancelar

                </button>

                <button
                    class="modal-btn confirm"
                    id="salvar-cor">

                    Salvar cor

                </button>

            </div>

        `);


        const selectGaveta =
            modal.querySelector("#numero-gaveta");

        const inputCor =
            modal.querySelector("#cor-gaveta");


        function carregarCorAtual() {

            const gaveta =
                selectGaveta.value;

            if (gavetas[gaveta]) {

                inputCor.value =
                    gavetas[gaveta];

            }

        }


        selectGaveta.addEventListener(
            "change",
            carregarCorAtual
        );


        carregarCorAtual();


        modal.querySelector(
            "#cancelar-cor"
        ).addEventListener("click", () => {

            fecharModal(modal);

        });


        modal.querySelector(
            "#salvar-cor"
        ).addEventListener("click", () => {

            const gaveta =
                selectGaveta.value;

            const cor =
                inputCor.value;


            gavetas[gaveta] = cor;

            salvarGavetas(gavetas);

            fecharModal(modal);


            alert(
                `Cor da gaveta ${gaveta} definida!`
            );

        });

    }


    /* =====================================================
       VER LISTA
       ===================================================== */

    function verLista() {

        const remedios = pegarRemedios();

        const gavetas = pegarGavetas();


        let conteudo = "";


        if (remedios.length === 0) {

            conteudo = `

                <div class="lista-vazia">

                    <div style="font-size:45px;">
                        💊
                    </div>

                    <p>
                        Nenhum remédio cadastrado.
                    </p>

                </div>

            `;

        } else {

            remedios.forEach(remedio => {

                const cor =
                    gavetas[remedio.gaveta]
                    || "#c4d0ff";


                conteudo += `

                    <div class="remedio-item">

                        <div class="remedio-info">

                            <strong>
                                💊
                                ${escaparHTML(remedio.nome)}
                            </strong>

                            <span>
                                Dosagem:
                                ${escaparHTML(remedio.dosagem)}
                            </span>

                            <span>
                                Horário:
                                ${escaparHTML(remedio.horario)}
                            </span>

                            <span>
                                Gaveta:
                                ${remedio.gaveta}
                            </span>

                        </div>

                        <div
                            class="remedio-gaveta"
                            title="Cor da gaveta ${remedio.gaveta}"
                            style="background-color:${cor};">
                        </div>

                    </div>

                `;

            });

        }


        const modal = criarModal(`

            <h2>
                Lista de remédios
            </h2>

            <p style="margin-bottom:20px; color:#555;">
                Remédios cadastrados para
                <strong>
                    ${escaparHTML(idoso.nome)}
                </strong>
            </p>

            ${conteudo}

            <div class="modal-buttons">

                <button
                    class="modal-btn cancel"
                    id="fechar-lista">

                    Fechar

                </button>

            </div>

        `);


        modal.querySelector(
            "#fechar-lista"
        ).addEventListener("click", () => {

            fecharModal(modal);

        });

    }


    /* =====================================================
       ESCAPAR HTML
       Evita que texto digitado pelo usuário vire HTML.
       ===================================================== */

    function escaparHTML(texto) {

        const div =
            document.createElement("div");

        div.textContent =
            texto ?? "";

        return div.innerHTML;

    }


    /* =====================================================
       ATUALIZAR DASHBOARD
       ===================================================== */

    function atualizarDadosDashboard() {

        const remedios = pegarRemedios();

        localStorage.setItem(
            `zelo_total_remedios_${idoso.id}`,
            remedios.length
        );

        /*
         * Dispara um evento para outras partes do sistema.
         */
        window.dispatchEvent(
            new CustomEvent(
                "zeloRemediosAtualizados",
                {
                    detail: {
                        idosoId: idoso.id,
                        total: remedios.length
                    }
                }
            )
        );

    }


    /* =====================================================
       EVENTOS DOS BOTÕES
       ===================================================== */

    btnAdicionar.addEventListener(
        "click",
        adicionarRemedio
    );

    btnRemover.addEventListener(
        "click",
        removerRemedio
    );

    btnCorGaveta.addEventListener(
        "click",
        definirCorGaveta
    );

    btnLista.addEventListener(
        "click",
        verLista
    );


    /* =====================================================
       SAIR
       ===================================================== */

    window.sair = function(event) {

        event.preventDefault();

        localStorage.removeItem(
            "currentUser"
        );

        localStorage.removeItem(
            "selectedIdoso"
        );

        window.location.href =
            "../paginainicial/paginainicial.html";

    };


    /* =====================================================
       NOTIFICAÇÕES
       ===================================================== */

    const btnSininho =
        document.getElementById("btn-sininho");

    const notifDropdown =
        document.getElementById("notif-dropdown");

    const notifLista =
        document.getElementById("notif-lista");

    const notifBadge =
        document.getElementById("notif-badge");

    const btnLimpar =
        document.getElementById("btn-limpar-notif");


    let notificacoes =
        JSON.parse(
            localStorage.getItem(
                "zelo_notificacoes_salvas"
            )
        ) || [];


    function renderizarNotificacoes() {

        notifLista.innerHTML = "";


        if (notificacoes.length === 0) {

            notifLista.innerHTML =
                `<p class="notif-empty">
                    Nenhuma notificação no momento.
                </p>`;

            notifBadge.style.display =
                "none";

            return;
        }


        notifBadge.textContent =
            notificacoes.length;

        notifBadge.style.display =
            "block";


        notificacoes.forEach(notif => {

            const item =
                document.createElement("div");

            item.className =
                "notif-item";

            item.innerHTML = `

                <div class="notif-item-text">
                    💊 ${escaparHTML(notif.mensagem)}
                </div>

                <div class="notif-item-time">
                    ${escaparHTML(notif.hora)}
                </div>

            `;

            notifLista.appendChild(item);

        });

    }


    if (btnSininho) {

        btnSininho.addEventListener(
            "click",
            event => {

                event.stopPropagation();

                notifDropdown.classList.toggle(
                    "is-open"
                );

            }
        );

    }


    document.addEventListener(
        "click",
        () => {

            if (notifDropdown) {

                notifDropdown.classList.remove(
                    "is-open"
                );

            }

        }
    );


    if (btnLimpar) {

        btnLimpar.addEventListener(
            "click",
            event => {

                event.stopPropagation();

                notificacoes = [];

                localStorage.removeItem(
                    "zelo_notificacoes_salvas"
                );

                renderizarNotificacoes();

            }
        );

    }


    if (
        typeof ZeloSync !== "undefined"
    ) {

        ZeloSync.escutarEventos(
            dados => {

                if (
                    dados.tipo ===
                    "REMEDIO_TOMADO"
                ) {

                    const novaNotif = {

                        mensagem:
                            dados.mensagem ||
                            "O idoso tomou o remédio!",

                        hora:
                            dados.dataHora ||
                            new Date().toLocaleTimeString(
                                "pt-BR",
                                {
                                    hour: "2-digit",
                                    minute: "2-digit"
                                }
                            )

                    };


                    notificacoes.unshift(
                        novaNotif
                    );


                    localStorage.setItem(
                        "zelo_notificacoes_salvas",
                        JSON.stringify(
                            notificacoes
                        )
                    );


                    renderizarNotificacoes();

                }

            }
        );

    }


    renderizarNotificacoes();

    atualizarDadosDashboard();

});