function obterIdosoAtual() {
    const idosoSalvo = JSON.parse(localStorage.getItem("selectedIdoso"));
    if (idosoSalvo && idosoSalvo.id) {
        return idosoSalvo;
    }
    
    const currentUser = JSON.parse(localStorage.getItem("currentUser")) || {};
    return {
        id: currentUser.idIdoso || "12345",
        nome: currentUser.nomeIdoso || "Miquéias de Sousa"
    };
}

function obterDataAtualLocal() {
    const agora = new Date();
    const ano = agora.getFullYear();
    const mes = String(agora.getMonth() + 1).padStart(2, '0');
    const dia = String(agora.getDate()).padStart(2, '0');
    return `${ano}-${mes}-${dia}`;
}

function atualizarTotaisDashboard() {
    const idoso = obterIdosoAtual();
    
    // Atualizar Label do idoso no cabeçalho
    const idosoLabel = document.getElementById("current-idoso-label");
    if (idosoLabel) {
        idosoLabel.textContent = `Idoso: ${idoso.nome}`;
    }

    // --- LEMBRETES ---
    const CHAVE_LEMBRETES = `zelo_lembretes_${idoso.id}`;
    const lembretes = JSON.parse(localStorage.getItem(CHAVE_LEMBRETES)) || [];
    
    const totalLembretesCard = document.getElementById("total-lembretes-card");
    if (totalLembretesCard) {
        const qtd = lembretes.length;
        totalLembretesCard.textContent = `${qtd} ${qtd === 1 ? 'cadastrado' : 'cadastrados'}`;
    }

    // --- COMPROMISSOS ---
    const CHAVE_COMPROMISSOS = `zelo_compromissos_${idoso.id}`;
    const compromissos = JSON.parse(localStorage.getItem(CHAVE_COMPROMISSOS)) || [];

    // Data de hoje em YYYY-MM-DD
    const hoje = obterDataAtualLocal();

    // Filtra compromissos comparando a string de data tratada (sem espaços extras)
    const compromissosHoje = compromissos.filter(c => {
        if (!c.data) return false;
        // Limpa a string de data para garantir comparação correta
        const dataCompromisso = c.data.trim();
        return dataCompromisso === hoje;
    });

    // Card Status Verde (Compromissos de Hoje)
    const cardCompromissos = document.getElementById("card-compromissos");
    const cardCompromissoDesc = document.getElementById("card-compromisso-desc");
    
    if (cardCompromissos) {
        cardCompromissos.textContent = compromissosHoje.length;
    }
    
    if (cardCompromissoDesc) {
        if (compromissosHoje.length === 1) {
            cardCompromissoDesc.textContent = 'Compromisso hoje';
        } else if (compromissosHoje.length > 1) {
            cardCompromissoDesc.textContent = 'Compromissos hoje';
        } else {
            cardCompromissoDesc.textContent = 'Nenhum hoje';
        }
    }

    // Card de Ação (Total Cadastrados)
    const totalCompromissosCard = document.getElementById("total-compromissos-card");
    if (totalCompromissosCard) {
        const qtdComp = compromissos.length;
        totalCompromissosCard.textContent = `${qtdComp} ${qtdComp === 1 ? 'cadastrado' : 'cadastrados'}`;
    }
}

// Executa ao carregar o DOM e ao voltar para a página via navegação
document.addEventListener("DOMContentLoaded", atualizarTotaisDashboard);
window.addEventListener("pageshow", atualizarTotaisDashboard);