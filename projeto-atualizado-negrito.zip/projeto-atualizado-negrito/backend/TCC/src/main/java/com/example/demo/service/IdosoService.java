package com.example.demo.service;

import com.example.demo.dto.AuthResponseDTO;
import com.example.demo.dto.IdosoDTO;
import com.example.demo.entity.Idoso;
import com.example.demo.repository.IdosoRepository;
import com.example.demo.util.JwtUtil;
import com.example.demo.util.QRCodeGenerator;
import com.example.demo.util.TelefoneJaCadastradoException;
import com.google.zxing.WriterException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import tools.jackson.databind.ObjectMapper;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class IdosoService {
    @Autowired private IdosoRepository repository;
    @Autowired private JwtUtil jwtUtil;

    @Transactional
    public AuthResponseDTO cadastrar(IdosoDTO dto) {
        String telefoneNormalizado = apenasNumeros(dto.getTelefone());
        boolean jaExiste = repository.findAll().stream()
                .anyMatch(i -> apenasNumeros(i.getTelefone()).equals(telefoneNormalizado));
        if (jaExiste) {
            throw new TelefoneJaCadastradoException(
                    "Este telefone já tem um cadastro de idoso. Toque em \"Entrar\" e use o telefone.");
        }
        Idoso idoso = repository.save(new Idoso(dto.getNome(), dto.getIdade(), dto.getTelefone()));
        try {
            ObjectMapper mapper = new ObjectMapper();
            Map<String, Object> dadosQr = new HashMap<>();
            dadosQr.put("id", idoso.getId());
            dadosQr.put("nome", idoso.getNome());
            dadosQr.put("idade", idoso.getIdade());
            dadosQr.put("telefone", idoso.getTelefone());
            idoso.setQrCode(QRCodeGenerator.generateQRCodeImage(mapper.writeValueAsString(dadosQr), 250, 250));
            idoso = repository.save(idoso);
        } catch (WriterException | IOException e) {
            throw new IllegalStateException("Não foi possível gerar o QR Code do idoso.", e);
        }
        return autenticar(idoso);
    }

    public AuthResponseDTO autenticar(Idoso idoso) {
        boolean vinculado = idoso.getFamiliares() != null && !idoso.getFamiliares().isEmpty();
        return new AuthResponseDTO(idoso.getId(), idoso.getNome(), idoso.getIdade(), idoso.getTelefone(), "idoso",
                vinculado, jwtUtil.gerarToken(idoso.getId(), "idoso"));
    }

    private String apenasNumeros(String valor) {
        return valor == null ? "" : valor.replaceAll("\\D", "");
    }

    public List<Idoso> listar(){ return repository.findAll(); }
    public Idoso buscarPorId(Long id) { return repository.findById(id).orElse(null); }

    @Transactional
    public void atualizar(Long id, IdosoDTO dto){
        Idoso u = repository.getReferenceById(id);
        u.setNome(dto.getNome()); u.setIdade(dto.getIdade()); u.setTelefone(dto.getTelefone());
    }

    @Transactional
    public void remover(Long id) { repository.deleteById(id); }
}
