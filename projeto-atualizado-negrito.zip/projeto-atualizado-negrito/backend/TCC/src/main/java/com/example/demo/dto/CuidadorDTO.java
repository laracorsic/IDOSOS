package com.example.demo.dto;

import jakarta.validation.constraints.NotBlank;

public class CuidadorDTO {
    @NotBlank(message = "Informe o telefone.")
    private  String telefone;

    @NotBlank(message = "Informe o nome.")
    private String nome;

    @NotBlank(message = "Informe o CPF.")
    private String cpf;

    public CuidadorDTO() {}

    public CuidadorDTO(String nome, String cpf, String telefone) {
        this.nome = nome;
        this.cpf = cpf;
        this.telefone = telefone;
    }

    public String getTelefone() {
        return telefone;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }
}
