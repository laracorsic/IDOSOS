package com.example.demo.service;

import com.example.demo.dto.AuthResponseDTO;
import com.example.demo.dto.FamiliarDTO;
import com.example.demo.entity.Familiar;
import com.example.demo.entity.Idoso;
import com.example.demo.repository.FamiliarRepository;
import com.example.demo.repository.IdosoRepository;
import com.example.demo.util.JwtUtil;
import com.example.demo.util.TelefoneJaCadastradoException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;

@Service
public class FamiliarService {
    @Autowired private FamiliarRepository repository;
    @Autowired private IdosoRepository idosoRepository;
    @Autowired private JwtUtil jwtUtil;

    @Transactional
    public AuthResponseDTO cadastrar(FamiliarDTO dto){
        String telefoneNormalizado = apenasNumeros(dto.getTelefone());
        boolean jaExiste = repository.findAll().stream()
                .anyMatch(f -> apenasNumeros(f.getTelefone()).equals(telefoneNormalizado));
        if (jaExiste) {
            throw new TelefoneJaCadastradoException(
                    "Este telefone já tem um cadastro de familiar. Toque em \"Entrar\" e use o telefone.");
        }
        return autenticar(repository.save(new Familiar(dto.getNome(), dto.getIdade(), dto.getTelefone())));
    }

    public AuthResponseDTO autenticar(Familiar familiar) {
        boolean vinculado = familiar.getIdosos() != null && !familiar.getIdosos().isEmpty();
        return new AuthResponseDTO(familiar.getId(), familiar.getNome(), familiar.getIdade(), familiar.getTelefone(), "familiar",
                vinculado, jwtUtil.gerarToken(familiar.getId(), "familiar"));
    }

    private String apenasNumeros(String valor) {
        return valor == null ? "" : valor.replaceAll("\\D", "");
    }

    @Transactional
    public void vincularIdoso(Long familiarId, String qrCodeContent) {
        Familiar familiar = repository.findById(familiarId).orElseThrow(() -> new RuntimeException("Familiar não encontrado"));
        Long idosoId = Long.parseLong(qrCodeContent);
        Idoso idoso = idosoRepository.findById(idosoId).orElseThrow(() -> new RuntimeException("Idoso não encontrado"));
        if (idoso.getFamiliares() == null) idoso.setFamiliares(new ArrayList<>());
        if (!idoso.getFamiliares().contains(familiar)) {
            idoso.getFamiliares().add(familiar);
            idosoRepository.save(idoso);
        }
    }

    public List<Familiar> listar(){ return repository.findAll(); }

    @Transactional
    public void atualizar(Long id, FamiliarDTO dto){
        Familiar u = repository.getReferenceById(id);
        u.setNome(dto.getNome()); u.setIdade(dto.getIdade()); u.setTelefone(dto.getTelefone());
    }

    @Transactional
    public void remover(Long id) { repository.deleteById(id); }
}
