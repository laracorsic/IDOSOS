package com.example.demo.controller;

import com.example.demo.dto.RemedioDTO;
import com.example.demo.entity.Remedio;
import com.example.demo.service.RemedioService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/remedios")
public class RemedioController {

    @Autowired
    private RemedioService service;

    @PostMapping
    public void cadastrar(@RequestBody RemedioDTO dto){

        service.cadastrar(dto);
    }

    @GetMapping
    public ResponseEntity<List<Remedio>> listar(){
        List<Remedio> lista = service.listar();
        return ResponseEntity.ok(lista);
    }

    @PutMapping("/{id}")
    public void atualizar(@PathVariable Long id, @RequestBody RemedioDTO dto){

        service.atualizar(id, dto);
    }

    @DeleteMapping("/{id}")
    public void remover(@PathVariable Long id){
        service.remover(id);
    }
}