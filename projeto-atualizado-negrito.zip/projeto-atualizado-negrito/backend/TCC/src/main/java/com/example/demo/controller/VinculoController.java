package com.example.demo.controller;

import com.example.demo.entity.Idoso;
import com.example.demo.service.IdosoService;
import com.example.demo.service.VinculoService;
import com.example.demo.util.AutenticacaoUtil;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/vinculo")
public class VinculoController {

    @Autowired
    private IdosoService idosoService;

    @Autowired
    private VinculoService vinculoService;

    // Usado pelo próprio idoso para exibir o QR na tela de vínculo — exige
    // um token válido (o JwtAuthFilter já garante isso para /api/vinculo/**).
    @GetMapping(value = "/qrcode/{idosoId}", produces = MediaType.IMAGE_PNG_VALUE)
    public ResponseEntity<byte[]> visualizarQrCode(@PathVariable Long idosoId) {
        Idoso idoso = idosoService.buscarPorId(idosoId);
        if (idoso != null && idoso.getQrCode() != null) {
            return ResponseEntity.ok().body(idoso.getQrCode());
        }
        return ResponseEntity.notFound().build();
    }

    // Só o próprio familiar (dono do token) pode vincular um idoso à sua
    // conta. Sem essa checagem, bastava editar "familiarId" na URL (ou o id
    // salvo no localStorage) para vincular idosos à conta de outra pessoa.
    @PostMapping("/vincular-automatico")
    public ResponseEntity<Idoso> vincularAutomatico(
            @RequestParam Long familiarId,
            @RequestBody String qrCodeContent,
            HttpServletRequest request) {

        AutenticacaoUtil.exigirDono(request, familiarId, "familiar");

        Idoso idoso = vinculoService.realizarVinculo(familiarId, qrCodeContent);
        return ResponseEntity.ok(idoso);
    }
}
