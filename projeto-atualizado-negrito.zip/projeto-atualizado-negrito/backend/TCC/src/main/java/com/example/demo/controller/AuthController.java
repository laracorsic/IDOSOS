package com.example.demo.controller;

import com.example.demo.dto.AuthResponseDTO;
import com.example.demo.dto.LoginDTO;
import com.example.demo.entity.Familiar;
import com.example.demo.entity.Idoso;
import com.example.demo.repository.FamiliarRepository;
import com.example.demo.repository.IdosoRepository;
import com.example.demo.util.JwtUtil;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;

import java.util.Locale;

@RestController
@RequestMapping("/auth")
public class AuthController {
    private final IdosoRepository idosoRepository;
    private final FamiliarRepository familiarRepository;
    private final JwtUtil jwtUtil;

    public AuthController(IdosoRepository idosoRepository, FamiliarRepository familiarRepository, JwtUtil jwtUtil) {
        this.idosoRepository = idosoRepository;
        this.familiarRepository = familiarRepository;
        this.jwtUtil = jwtUtil;
    }

    /**
     * Login sem token: entra só com o telefone, dentro da tabela do tipo
     * informado (idoso ou familiar). Um idoso nunca é encontrado na tabela
     * de familiar e vice-versa — são tabelas (entidades) distintas, sem
     * nenhum cruzamento entre elas.
     */
    @Transactional(readOnly = true)
    @PostMapping("/login")
    public ResponseEntity<?> login(@Valid @RequestBody LoginDTO dto) {
        String tipo = dto.getTipo() == null ? "" : dto.getTipo().trim().toLowerCase(Locale.ROOT);
        String telefone = apenasNumeros(dto.getTelefone());

        if ("idoso".equals(tipo)) {
            return idosoRepository.findAll().stream()
                    .filter(u -> apenasNumeros(u.getTelefone()).equals(telefone))
                    .findFirst()
                    .<ResponseEntity<?>>map(u -> ResponseEntity.ok(resposta(u)))
                    .orElseGet(this::erro);
        }
        if ("familiar".equals(tipo)) {
            return familiarRepository.findAll().stream()
                    .filter(u -> apenasNumeros(u.getTelefone()).equals(telefone))
                    .findFirst()
                    .<ResponseEntity<?>>map(u -> ResponseEntity.ok(resposta(u)))
                    .orElseGet(this::erro);
        }
        return erro();
    }

    private ResponseEntity<?> erro() {
        return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                .body(java.util.Map.of("erro", "Telefone não encontrado. Confira o número ou crie um cadastro."));
    }

    private AuthResponseDTO resposta(Idoso u) {
        boolean vinculado = u.getFamiliares() != null && !u.getFamiliares().isEmpty();
        return new AuthResponseDTO(u.getId(), u.getNome(), u.getIdade(), u.getTelefone(), "idoso", vinculado,
                jwtUtil.gerarToken(u.getId(), "idoso"));
    }

    private AuthResponseDTO resposta(Familiar u) {
        boolean vinculado = u.getIdosos() != null && !u.getIdosos().isEmpty();
        return new AuthResponseDTO(u.getId(), u.getNome(), u.getIdade(), u.getTelefone(), "familiar", vinculado,
                jwtUtil.gerarToken(u.getId(), "familiar"));
    }

    private String apenasNumeros(String valor) {
        return valor == null ? "" : valor.replaceAll("\\D", "");
    }
}
