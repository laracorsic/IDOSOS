package com.example.demo.controller;

import com.example.demo.dto.AuthResponseDTO;
import com.example.demo.dto.CuidadorDTO;
import com.example.demo.entity.Cuidador;
import com.example.demo.service.CuidadorService;
import com.example.demo.util.AutenticacaoUtil;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/cuidadores")
public class CuidadorController {

    @Autowired
    private CuidadorService service;

    @PostMapping
    public ResponseEntity<AuthResponseDTO> cadastrar(@Valid @RequestBody CuidadorDTO dto) {
        return ResponseEntity.ok(service.cadastrar(dto));
    }

    @GetMapping
    public ResponseEntity<List<Cuidador>> listar() {
        return ResponseEntity.ok(service.listar());
    }

    @PostMapping("/{id}/vincular")
    public ResponseEntity<String> vincularIdoso(@PathVariable Long id, @RequestBody String qrCodeContent,
                                                 HttpServletRequest request) {
        AutenticacaoUtil.exigirDono(request, id, "cuidador");
        try {
            service.vincularIdoso(id, qrCodeContent);
            return ResponseEntity.ok("Idoso vinculado com sucesso ao cuidador.");
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }
}
