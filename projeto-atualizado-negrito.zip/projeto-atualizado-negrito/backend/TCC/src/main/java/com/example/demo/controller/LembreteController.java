package com.example.demo.controller;

import com.example.demo.dto.LembreteDTO;
import com.example.demo.entity.Lembrete;
import com.example.demo.service.LembreteService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/lembretes")
public class LembreteController {

    @Autowired
    private LembreteService service;

    @PostMapping
    public void cadastrar(@RequestBody LembreteDTO dto){

        service.cadastrar(dto);
    }

    @GetMapping
    public ResponseEntity<List<Lembrete>> listar(){
        List<Lembrete> lista = service.listar();
        return ResponseEntity.ok(lista);
    }

    @PutMapping("/{id}")
    public void atualizar(@PathVariable Long id, @RequestBody LembreteDTO dto){

        service.atualizar(id, dto);
    }

    @DeleteMapping("/{id}")
    public void remover(@PathVariable Long id){
        service.remover(id);
    }
}