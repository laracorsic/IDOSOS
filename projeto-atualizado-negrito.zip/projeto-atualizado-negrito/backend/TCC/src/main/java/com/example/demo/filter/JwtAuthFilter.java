package com.example.demo.filter;

import com.example.demo.util.JwtUtil;
import io.jsonwebtoken.Claims;
import io.jsonwebtoken.JwtException;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.ServletRequest;
import jakarta.servlet.ServletResponse;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.web.filter.GenericFilterBean;

import java.io.IOException;

/**
 * Confere o token (JWT) em toda requisição para as rotas que expõem ou
 * alteram dados de usuário. As únicas rotas liberadas sem token são as de
 * PRIMEIRO CADASTRO (POST /idosos, /familiares, /cuidadores) — nesse
 * momento o usuário ainda não tem token nenhum.
 *
 * Quando o token é válido, o id e o tipo (idoso/familiar/cuidador) contidos
 * nele ficam disponíveis via request.getAttribute("authId") e
 * request.getAttribute("authTipo") para os controllers usarem em
 * AutenticacaoUtil.exigirDono(...).
 */
public class JwtAuthFilter extends GenericFilterBean {

    private final JwtUtil jwtUtil;

    public JwtAuthFilter(JwtUtil jwtUtil) {
        this.jwtUtil = jwtUtil;
    }

    @Override
    public void doFilter(ServletRequest req, ServletResponse res, FilterChain chain)
            throws IOException, ServletException {

        HttpServletRequest request = (HttpServletRequest) req;
        HttpServletResponse response = (HttpServletResponse) res;

        String metodo = request.getMethod();
        String caminho = request.getRequestURI();

        if ("OPTIONS".equalsIgnoreCase(metodo) || !precisaDeToken(metodo, caminho)) {
            chain.doFilter(req, res);
            return;
        }

        String cabecalho = request.getHeader("Authorization");
        if (cabecalho == null || !cabecalho.startsWith("Bearer ")) {
            responderNaoAutorizado(response, "Token ausente. É preciso se cadastrar para gerar um token de sessão.");
            return;
        }

        try {
            Claims claims = jwtUtil.validarEExtrair(cabecalho.substring("Bearer ".length()));
            request.setAttribute("authId", Long.valueOf(claims.getSubject()));
            request.setAttribute("authTipo", claims.get("tipo", String.class));
        } catch (JwtException | NumberFormatException e) {
            responderNaoAutorizado(response, "Token inválido ou expirado.");
            return;
        }

        chain.doFilter(req, res);
    }

    private boolean precisaDeToken(String metodo, String caminho) {
        boolean rotaDeCadastro = "POST".equalsIgnoreCase(metodo) &&
                (caminho.equals("/idosos") || caminho.equals("/familiares") || caminho.equals("/cuidadores"));
        if (rotaDeCadastro) {
            return false;
        }

        return caminho.startsWith("/idosos")
                || caminho.startsWith("/familiares")
                || caminho.startsWith("/cuidadores")
                || caminho.startsWith("/api/vinculo")
                || caminho.startsWith("/remedios")
                || caminho.startsWith("/lembretes");
    }

    private void responderNaoAutorizado(HttpServletResponse response, String mensagem) throws IOException {
        response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
        response.setContentType("application/json;charset=UTF-8");
        response.getWriter().write("{\"erro\":\"" + mensagem + "\"}");
    }
}
