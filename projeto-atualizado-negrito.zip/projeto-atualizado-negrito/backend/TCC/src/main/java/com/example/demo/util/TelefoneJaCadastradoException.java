package com.example.demo.util;

/**
 * Lançada quando já existe um cadastro (idoso ou familiar) com o mesmo
 * telefone naquela tabela. Como o login passou a ser feito só pelo
 * telefone, dois cadastros com o mesmo número na mesma tabela deixariam o
 * login ambíguo. Tratada pelo GlobalExceptionHandler e transformada em
 * HTTP 409 (Conflict).
 */
public class TelefoneJaCadastradoException extends RuntimeException {
    public TelefoneJaCadastradoException(String mensagem) {
        super(mensagem);
    }
}
