package com.example.demo.controller;

import com.example.demo.dto.AuthResponseDTO;
import com.example.demo.dto.FamiliarDTO;
import com.example.demo.entity.Familiar;
import com.example.demo.service.FamiliarService;
import com.example.demo.util.AutenticacaoUtil;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/familiares")
public class FamiliarController {

    @Autowired
    private FamiliarService service;

    // Cadastro: única rota liberada sem token. A resposta já traz o token
    // que o front-end deve guardar e reenviar em toda chamada seguinte.
    @PostMapping
    public ResponseEntity<AuthResponseDTO> cadastrar(@Valid @RequestBody FamiliarDTO dto) {
        AuthResponseDTO resposta = service.cadastrar(dto);
        return ResponseEntity.ok(resposta);
    }

    @GetMapping
    public ResponseEntity<List<Familiar>> listar() {
        List<Familiar> lista = service.listar();
        return ResponseEntity.ok(lista);
    }

    @PutMapping("/{id}")
    public void atualizar(@PathVariable Long id, @Valid @RequestBody FamiliarDTO dto, HttpServletRequest request) {
        AutenticacaoUtil.exigirDono(request, id, "familiar");
        service.atualizar(id, dto);
    }

    @DeleteMapping("/{id}")
    public void remover(@PathVariable Long id, HttpServletRequest request) {
        AutenticacaoUtil.exigirDono(request, id, "familiar");
        service.remover(id);
    }

    // Só o próprio familiar (dono do token) pode vincular um idoso à sua
    // conta — sem isso, bastaria editar o id no localStorage para vincular
    // idosos à conta de outra pessoa.
    @PostMapping("/{id}/vincular")
    public ResponseEntity<String> vincularIdoso(@PathVariable Long id, @RequestBody String qrCodeContent,
                                                 HttpServletRequest request) {
        AutenticacaoUtil.exigirDono(request, id, "familiar");
        try {
            service.vincularIdoso(id, qrCodeContent);
            return ResponseEntity.ok("Idoso vinculado com sucesso ao familiar.");
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }
}
