package com.example.demo.dto;

/**
 * Resposta devolvida quando o usuário se cadastra ou entra: os dados dele +
 * o token de sessão. O front-end deve guardar isso no localStorage e
 * reenviar o campo "token" em toda chamada seguinte, no cabeçalho:
 *   Authorization: Bearer <token>
 *
 * O campo "vinculado" diz se esse idoso já tem familiar(es) vinculado(s)
 * (ou, no caso do familiar, se ele já está vinculado a algum idoso). O
 * front-end usa isso para decidir a próxima tela: se já está vinculado, vai
 * direto para a página inicial; senão, é levado para a tela de vínculo por
 * QR Code.
 *
 * Importante: o "id" aqui é só para exibição/roteamento no front-end. Para
 * qualquer operação sensível (ver, editar, apagar, vincular), o servidor
 * NUNCA confia no id que veio do front — ele extrai o id de verdade de
 * dentro do token assinado. Ver JwtAuthFilter.
 */
public class AuthResponseDTO {
    private Long id;
    private String nome;
    private int idade;
    private String telefone;
    private String tipo;
    private boolean vinculado;
    private String token;

    public AuthResponseDTO() {}

    public AuthResponseDTO(Long id, String nome, int idade, String telefone, String tipo, boolean vinculado, String token) {
        this.id = id;
        this.nome = nome;
        this.idade = idade;
        this.telefone = telefone;
        this.tipo = tipo;
        this.vinculado = vinculado;
        this.token = token;
    }

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getNome() { return nome; }
    public void setNome(String nome) { this.nome = nome; }

    public int getIdade() { return idade; }
    public void setIdade(int idade) { this.idade = idade; }

    public String getTelefone() { return telefone; }
    public void setTelefone(String telefone) { this.telefone = telefone; }

    public String getTipo() { return tipo; }
    public void setTipo(String tipo) { this.tipo = tipo; }

    public boolean isVinculado() { return vinculado; }
    public void setVinculado(boolean vinculado) { this.vinculado = vinculado; }

    public String getToken() { return token; }
    public void setToken(String token) { this.token = token; }
}
