package com.example.demo.util;

import jakarta.servlet.http.HttpServletRequest;

/**
 * Lê o id/tipo que o JwtAuthFilter já validou e guardou na requisição, e
 * concentra a checagem "isso é realmente seu?" usada pelos controllers.
 *
 * Nunca confie no {id} que vem da URL ou do corpo da requisição sozinho —
 * sempre confirme contra o que está no token (que o cliente não consegue
 * forjar).
 */
public final class AutenticacaoUtil {

    private AutenticacaoUtil() {}

    public static Long idAutenticado(HttpServletRequest request) {
        return (Long) request.getAttribute("authId");
    }

    public static String tipoAutenticado(HttpServletRequest request) {
        return (String) request.getAttribute("authTipo");
    }

    /**
     * Garante que o token da requisição pertence ao próprio recurso sendo
     * acessado (mesmo id e mesmo tipo). Lança AcessoNegadoException (-> 403)
     * caso contrário — inclusive se alguém adulterou o id no localStorage
     * para tentar mexer no cadastro de outra pessoa.
     */
    public static void exigirDono(HttpServletRequest request, Long idDoRecurso, String tipoEsperado) {
        Long idToken = idAutenticado(request);
        String tipoToken = tipoAutenticado(request);

        if (idToken == null || !idToken.equals(idDoRecurso) || !tipoEsperado.equals(tipoToken)) {
            throw new AcessoNegadoException(
                    "Este token não tem permissão para acessar este cadastro de " + tipoEsperado + ".");
        }
    }
}
