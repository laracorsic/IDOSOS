package com.example.demo.util;

/**
 * Lançada quando o token é válido, mas pertence a outra pessoa — por
 * exemplo, um familiar tentando editar o cadastro de outro familiar. Tratada
 * pelo GlobalExceptionHandler e transformada em HTTP 403.
 */
public class AcessoNegadoException extends RuntimeException {
    public AcessoNegadoException(String mensagem) {
        super(mensagem);
    }
}
