package com.example.demo.dto;

import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;

public class IdosoDTO {
    @NotBlank(message = "Informe o nome.")
    private String nome;

    @Min(value = 0, message = "Idade inválida.")
    @Max(value = 130, message = "Idade inválida.")
    private int idade;

    @NotBlank(message = "Informe o telefone.")
    private String telefone;

    public IdosoDTO() {}

    public IdosoDTO(String nome, int idade, String telefone) {
        this.nome = nome;
        this.idade = idade;
        this.telefone = telefone;
    }

    public String getTelefone() {
        return telefone;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public int getIdade() {
        return idade;
    }

    public void setIdade(int idade) {
        this.idade = idade;
    }
}


