package com.example.demo.controller;

import com.example.demo.dto.AuthResponseDTO;
import com.example.demo.dto.IdosoDTO;
import com.example.demo.entity.Idoso;
import com.example.demo.service.IdosoService;
import com.example.demo.util.AutenticacaoUtil;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/idosos")
public class IdosoController {

    @Autowired
    private IdosoService service;

    // Cadastro: única rota liberada sem token (o usuário ainda não tem um).
    // A resposta já inclui o token que o front-end deve guardar e reenviar
    // em toda chamada seguinte.
    @PostMapping
    public ResponseEntity<AuthResponseDTO> cadastrar(@Valid @RequestBody IdosoDTO dto) {
        AuthResponseDTO resposta = service.cadastrar(dto);
        return ResponseEntity.ok(resposta);
    }

    // Sem uso pelo front-end hoje; mantido só para depuração local, mas já
    // exige um token válido (o JwtAuthFilter cuida disso) em vez de ficar
    // aberto para qualquer um listar todo mundo.
    @GetMapping
    public ResponseEntity<List<Idoso>> listar() {
        List<Idoso> lista = service.listar();
        return ResponseEntity.ok(lista);
    }

    @PutMapping("/{id}")
    public void atualizar(@PathVariable Long id, @Valid @RequestBody IdosoDTO dto, HttpServletRequest request) {
        AutenticacaoUtil.exigirDono(request, id, "idoso");
        service.atualizar(id, dto);
    }

    @DeleteMapping("/{id}")
    public void remover(@PathVariable Long id, HttpServletRequest request) {
        AutenticacaoUtil.exigirDono(request, id, "idoso");
        service.remover(id);
    }

    // Consultado pelo familiar logo após ler o QR Code físico do idoso (o
    // próprio QR já contém id/nome/idade/telefone). Exige apenas um token
    // válido (idoso ou familiar), não necessariamente "ser o dono", pois é
    // assim que o fluxo de vínculo funciona.
    @GetMapping("/{id}")
    public ResponseEntity<Idoso> buscarPorId(@PathVariable Long id) {
        Idoso idoso = service.buscarPorId(id);
        if (idoso != null) {
            return ResponseEntity.ok(idoso);
        }
        return ResponseEntity.notFound().build();
    }

    @GetMapping("/{id}/qrcode")
    public ResponseEntity<byte[]> obterQrCode(@PathVariable Long id) {
        Idoso idoso = service.buscarPorId(id);
        if (idoso != null && idoso.getQrCode() != null) {
            return ResponseEntity.ok().contentType(MediaType.IMAGE_PNG).body(idoso.getQrCode());
        }
        return ResponseEntity.notFound().build();
    }
}
