package com.example.demo.config;

import com.example.demo.filter.JwtAuthFilter;
import com.example.demo.util.JwtUtil;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;
import org.springframework.web.filter.CorsFilter;

import java.util.Arrays;

/**
 * Registra, nesta ordem:
 *  1) CorsFilter  — decide QUAIS SITES podem chamar a API (substitui os
 *     antigos @CrossOrigin(origins = "*") espalhados pelos controllers, que
 *     liberavam qualquer site da internet).
 *  2) JwtAuthFilter — decide QUEM (com token válido) pode chamar as rotas
 *     que expõem dados de usuário.
 */
@Configuration
public class FilterConfig {

    @Value("${app.cors.allowed-origins}")
    private String origensPermitidas;

    @Bean
    public FilterRegistrationBean<CorsFilter> corsFilter() {
        UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
        CorsConfiguration config = new CorsConfiguration();
        config.setAllowedOrigins(Arrays.asList(origensPermitidas.split(",")));
        config.setAllowedMethods(Arrays.asList("GET", "POST", "PUT", "DELETE", "OPTIONS"));
        config.setAllowedHeaders(Arrays.asList("Authorization", "Content-Type"));
        config.setAllowCredentials(true);
        source.registerCorsConfiguration("/**", config);

        FilterRegistrationBean<CorsFilter> registration = new FilterRegistrationBean<>(new CorsFilter(source));
        registration.setOrder(0);
        return registration;
    }

    @Bean
    public FilterRegistrationBean<JwtAuthFilter> jwtAuthFilter(JwtUtil jwtUtil) {
        FilterRegistrationBean<JwtAuthFilter> registration = new FilterRegistrationBean<>(new JwtAuthFilter(jwtUtil));
        registration.addUrlPatterns("/*");
        registration.setOrder(1);
        return registration;
    }
}
