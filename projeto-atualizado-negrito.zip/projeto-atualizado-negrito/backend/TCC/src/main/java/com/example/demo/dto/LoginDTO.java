package com.example.demo.dto;

import jakarta.validation.constraints.NotBlank;

/**
 * Dados usados para entrar em outro celular/computador. O login é feito
 * somente pelo telefone (dentro da tabela do tipo informado — idoso ou
 * familiar), então não pedimos mais nome nem idade nesta tela.
 */
public class LoginDTO {
    @NotBlank(message = "Informe o telefone.")
    private String telefone;

    @NotBlank(message = "Informe o tipo de usuário.")
    private String tipo;

    public LoginDTO() {}

    public String getTelefone() { return telefone; }
    public void setTelefone(String telefone) { this.telefone = telefone; }
    public String getTipo() { return tipo; }
    public void setTipo(String tipo) { this.tipo = tipo; }
}
