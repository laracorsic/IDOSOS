package com.example.demo.util;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.JwtException;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.security.Keys;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import javax.crypto.SecretKey;
import java.nio.charset.StandardCharsets;
import java.util.Date;

/**
 * Gera e valida os tokens (JWT) que substituem o login por senha.
 *
 * Como o público-alvo (idosos) esquece senha com facilidade, o app não pede
 * senha: ao se cadastrar, o usuário recebe um token assinado pelo servidor.
 * Esse token fica salvo no localStorage do navegador e é enviado em toda
 * requisição seguinte (cabeçalho "Authorization: Bearer <token>").
 *
 * A segurança NÃO depende do token ficar escondido no navegador (ele não
 * fica — qualquer um pode ver o localStorage). Ela depende de que só o
 * servidor conhece a chave secreta usada para assinar. Se alguém editar o
 * token, ou tentar montar um token "na mão" com outro id, a assinatura não
 * vai bater e o servidor rejeita a requisição (401), então adulterar o
 * localStorage deixa de funcionar em vez de virar uma forma de se passar por
 * outro usuário.
 */
@Component
public class JwtUtil {

    private final SecretKey chave;
    private final long validadeEmMillis;

    public JwtUtil(
            @Value("${app.jwt.secret}") String segredo,
            @Value("${app.jwt.expiracao-dias}") long validadeEmDias
    ) {
        this.chave = Keys.hmacShaKeyFor(segredo.getBytes(StandardCharsets.UTF_8));
        this.validadeEmMillis = validadeEmDias * 24L * 60L * 60L * 1000L;
    }

    /** Gera um token novo logo após o cadastro do usuário. */
    public String gerarToken(Long id, String tipo) {
        Date agora = new Date();
        Date expiracao = new Date(agora.getTime() + validadeEmMillis);

        return Jwts.builder()
                .subject(String.valueOf(id))
                .claim("tipo", tipo)
                .issuedAt(agora)
                .expiration(expiracao)
                .signWith(chave)
                .compact();
    }

    /**
     * Confere a assinatura e a validade do token e devolve os dados nele
     * contidos. Lança JwtException se o token foi adulterado, é inválido ou
     * expirou.
     */
    public Claims validarEExtrair(String token) {
        try {
            return Jwts.parser()
                    .verifyWith(chave)
                    .build()
                    .parseSignedClaims(token)
                    .getPayload();
        } catch (JwtException | IllegalArgumentException e) {
            throw new JwtException("Token inválido ou expirado", e);
        }
    }
}
